//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-_iI8Zmr1.js
var manifest = {
	"0b2a4a73a18967b2f279bfdd79b8d55ad8313d34abf4fed19ad0f8a4cb4ece29": {
		functionName: "saveBotMessages_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"0bb5c03475528a4837b1f5888a4d86d332c8ca653d03b2280b8e103b65026bc1": {
		functionName: "broadcastAnnouncement_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"3ea81bdb10d8daa89adec9f438db664083b90185a95c973e8a227b000c8faf40": {
		functionName: "getBotStatus_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"440161562212790cf894ba6a603b6d216fa6e7efe73cb171171343ef5a451583": {
		functionName: "assignDiscordRole_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"4e85a1fb146ae1c6a476cf5547d5ad332a719fe3f9e5120e7b2525d00f260b08": {
		functionName: "syncDiscordUser_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"6491a536c6ba64dbbebed1b5dacad628803e97897e068070b157a1b938ae1f12": {
		functionName: "reviewRecruitmentForm_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"897c4d2530eaaac2a8002cefc8383f11f2d3405806b6f28f45f77cedf806c697": {
		functionName: "signDocumentUrl_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"9825a52e9ac7853994f3d71b9c094a3c5a03879ad044a7bf64262c76fa6635c3": {
		functionName: "sendDiscordDm_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"b3b1fd758dd706bc39ac482e43b0dfdd798b72dbe39d4b854338a89975bd0a49": {
		functionName: "reviewPayment_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"bdad539c038fa8a258655db007a4f09fbbf05552fcdd3656211f84d57a7e6b20": {
		functionName: "testBotConnection_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"d45e34cbcdf5255df7f5745857b8c2202722bb3f9a4491d0e4ec61fd8bfacf0a": {
		functionName: "removeDiscordRole_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"de2bfbc9e956b5d60cf4a81ba49771634e6130159987ed4e963ab5dfee479bb3": {
		functionName: "saveBotSettings_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"df214865c14ed63350120065d183dfda7d86b049cd9c5c73e227fb3f98dceda5": {
		functionName: "logDocumentAccess_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"dffc5147cd0f268233a36906aab72955709a30946831d8e6da103683c9c4fb4c": {
		functionName: "reviewTransfer_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	},
	"f18bd1d51f1e614f713933a7ed1986360314ddea0345f56d924e895dcb0f1073": {
		functionName: "saveRoleMap_createServerFn_handler",
		importer: () => import("./_ssr/discordBot.functions-CD5cXVoX.mjs")
	},
	"f37d7629dc3c8e04501501644a8d365c527c7b7c8631796cd881d52d137bd694": {
		functionName: "sendTransfer_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-CR1zg8ZV.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
