import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { a as createServerRpc, n as botOnEvent } from "./discordBot.server-B3C0n2G3.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DZO41X7i.mjs";
import { a as numberType, o as objectType, r as enumType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-CR1zg8ZV.js
/**
* Server-side audit log for sensitive document access. actor_id is derived
* from the authenticated bearer token — the client cannot forge it.
*/
var logDocumentAccess_createServerFn_handler = createServerRpc({
	id: "df214865c14ed63350120065d183dfda7d86b049cd9c5c73e227fb3f98dceda5",
	name: "logDocumentAccess",
	filename: "src/lib/admin.functions.ts"
}, (opts) => logDocumentAccess.__executeServer(opts));
var logDocumentAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	file_path: stringType().min(1).max(1024),
	file_name: stringType().min(1).max(512),
	viewed_user_id: stringType().uuid().optional(),
	viewed_user_name: stringType().max(256).optional()
}).parse(data)).handler(logDocumentAccess_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isStaff } = await supabase.rpc("is_staff", { _user_id: userId });
	if (!isStaff) throw new Error("Forbidden");
	const { error } = await supabase.from("audit_log").insert({
		actor_id: userId,
		action: "document.view",
		entity: "recruitment_documents",
		entity_id: data.file_path,
		metadata: {
			file_name: data.file_name,
			viewed_user_id: data.viewed_user_id ?? null,
			viewed_user_name: data.viewed_user_name ?? null
		}
	});
	if (error) throw new Error(error.message);
	return { ok: true };
});
var signDocumentUrl_createServerFn_handler = createServerRpc({
	id: "897c4d2530eaaac2a8002cefc8383f11f2d3405806b6f28f45f77cedf806c697",
	name: "signDocumentUrl",
	filename: "src/lib/admin.functions.ts"
}, (opts) => signDocumentUrl.__executeServer(opts));
var signDocumentUrl = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	file_path: stringType().min(1).max(1024),
	ttl: numberType().int().min(30).max(300).optional()
}).parse(data)).handler(signDocumentUrl_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isStaff } = await supabase.rpc("is_staff", { _user_id: userId });
	if (!isStaff) throw new Error("Forbidden");
	const { data: signed, error } = await supabase.storage.from("documents").createSignedUrl(data.file_path, data.ttl ?? 60);
	if (error) throw new Error(error.message);
	return { url: signed.signedUrl };
});
var broadcastAnnouncement_createServerFn_handler = createServerRpc({
	id: "0bb5c03475528a4837b1f5888a4d86d332c8ca653d03b2280b8e103b65026bc1",
	name: "broadcastAnnouncement",
	filename: "src/lib/admin.functions.ts"
}, (opts) => broadcastAnnouncement.__executeServer(opts));
var broadcastAnnouncement = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ announcement_id: stringType().uuid() }).parse(data)).handler(broadcastAnnouncement_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isStaff } = await supabase.rpc("is_staff", { _user_id: userId });
	if (!isStaff) throw new Error("Forbidden");
	const { data: ann, error: annErr } = await supabase.from("announcements").select("id, title, body, audience").eq("id", data.announcement_id).maybeSingle();
	if (annErr) throw new Error(annErr.message);
	if (!ann) throw new Error("Anúncio não encontrado");
	let targetsQ = supabase.from("profiles").select("id");
	if (ann.audience === "members") targetsQ = targetsQ.eq("status", "approved");
	const { data: profs, error: profErr } = await targetsQ;
	if (profErr) throw new Error(profErr.message);
	let targets = (profs ?? []).map((p) => p.id);
	if (ann.audience === "staff") {
		const { data: roles } = await supabase.from("user_roles").select("user_id").in("role", ["admin", "owner"]);
		const set = new Set((roles ?? []).map((r) => r.user_id));
		targets = targets.filter((id) => set.has(id));
	}
	if (!targets.length) return { count: 0 };
	const rows = targets.map((user_id) => ({
		user_id,
		type: "announcement",
		title: `📣 ${ann.title}`,
		body: ann.body,
		link: "/dashboard/avisos"
	}));
	const chunk = 500;
	for (let i = 0; i < rows.length; i += chunk) {
		const slice = rows.slice(i, i + chunk);
		const { error } = await supabase.from("notifications").insert(slice);
		if (error) throw new Error(error.message);
	}
	return { count: rows.length };
});
var reviewRecruitmentForm_createServerFn_handler = createServerRpc({
	id: "6491a536c6ba64dbbebed1b5dacad628803e97897e068070b157a1b938ae1f12",
	name: "reviewRecruitmentForm",
	filename: "src/lib/admin.functions.ts"
}, (opts) => reviewRecruitmentForm.__executeServer(opts));
var reviewRecruitmentForm = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	form_id: stringType().uuid(),
	user_id: stringType().uuid(),
	status: enumType(["approved", "rejected"]),
	notes: stringType().max(2e3).optional()
}).parse(data)).handler(reviewRecruitmentForm_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isStaff } = await supabase.rpc("is_staff", { _user_id: userId });
	if (!isStaff) throw new Error("Forbidden");
	const { data: fdata, error: fErr } = await supabase.from("recruitment_forms").update({
		status: data.status,
		reviewed_at: (/* @__PURE__ */ new Date()).toISOString(),
		review_notes: data.notes ?? null
	}).eq("id", data.form_id).select("cargo_desejado_id").maybeSingle();
	if (fErr) throw new Error(fErr.message);
	if (!fdata) throw new Error("Formulário não encontrado");
	if (data.status === "approved" && fdata.cargo_desejado_id) {
		const { data: formDetails } = await supabase.from("recruitment_forms").select("*").eq("id", data.form_id).single();
		const { data: cargoData } = await supabase.from("cargos").select("*").eq("id", fdata.cargo_desejado_id).maybeSingle();
		const parts = (formDetails?.full_name || "").trim().split(/\s+/).filter(Boolean);
		const firstName = parts[0] || null;
		const lastName = parts.length > 1 ? parts.slice(1).join(" ") : null;
		const { data: currentProfile } = await supabase.from("profiles").select("avatar_url, first_name, last_name").eq("id", data.user_id).maybeSingle();
		const { error: pErr } = await supabase.from("profiles").update({
			cargo_id: fdata.cargo_desejado_id,
			recruited_by: userId,
			form_status: "approved",
			status: "approved",
			first_name: firstName && !currentProfile?.first_name ? firstName : currentProfile?.first_name ?? firstName,
			last_name: lastName && !currentProfile?.last_name ? lastName : currentProfile?.last_name ?? lastName,
			avatar_url: currentProfile?.avatar_url || formDetails?.discord_avatar_url || null
		}).eq("id", data.user_id);
		if (pErr) throw new Error(pErr.message);
		const slug = (cargoData?.slug ?? "").toLowerCase();
		const isStaffCargo = slug.includes("rec") || slug.includes("adm");
		await supabase.from("user_roles").upsert({
			user_id: data.user_id,
			role: isStaffCargo ? "admin" : "member"
		}, { onConflict: "user_id,role" });
		try {
			await supabase.rpc("ensure_current_payment", { _user_id: data.user_id });
		} catch (e) {
			console.warn("ensure_current_payment falhou", e);
		}
		await supabase.from("payments").update({ recruiter_admin_id: userId }).eq("user_id", data.user_id).is("recruiter_admin_id", null);
	} else if (data.status === "rejected") await supabase.from("profiles").update({
		form_status: "rejected",
		status: "pending"
	}).eq("id", data.user_id);
	await supabase.from("audit_log").insert({
		actor_id: userId,
		action: `form.${data.status}`,
		entity: "recruitment_forms",
		entity_id: data.form_id,
		metadata: {
			notes: data.notes ?? null,
			user_id: data.user_id
		}
	});
	await supabase.from("notifications").insert({
		user_id: data.user_id,
		type: "form",
		title: data.status === "approved" ? "Formulário aprovado!" : "Formulário recusado",
		body: data.status === "approved" ? "Você agora tem acesso completo ao painel." : data.notes ?? "Sem observações",
		link: "/dashboard/formulario"
	});
	if (data.status === "approved") await botOnEvent(supabase, userId, "form_approved", data.user_id);
	return { ok: true };
});
var reviewPayment_createServerFn_handler = createServerRpc({
	id: "b3b1fd758dd706bc39ac482e43b0dfdd798b72dbe39d4b854338a89975bd0a49",
	name: "reviewPayment",
	filename: "src/lib/admin.functions.ts"
}, (opts) => reviewPayment.__executeServer(opts));
var reviewPayment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	payment_id: stringType().uuid(),
	status: enumType(["approved", "pending"])
}).parse(data)).handler(reviewPayment_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isStaff } = await supabase.rpc("is_staff", { _user_id: userId });
	if (!isStaff) throw new Error("Forbidden");
	const { data: pay } = await supabase.from("payments").select("id, user_id, recruiter_admin_id").eq("id", data.payment_id).maybeSingle();
	if (!pay) throw new Error("Pagamento não encontrado");
	const { error } = await supabase.from("payments").update({
		status: data.status,
		approved_at: data.status === "approved" ? (/* @__PURE__ */ new Date()).toISOString() : null
	}).eq("id", data.payment_id);
	if (error) throw new Error(error.message);
	await supabase.from("audit_log").insert({
		actor_id: userId,
		action: `payment.${data.status}`,
		entity: "payments",
		entity_id: data.payment_id,
		metadata: {
			user_id: pay.user_id,
			recruiter_admin_id: pay.recruiter_admin_id
		}
	});
	await supabase.from("notifications").insert({
		user_id: pay.user_id,
		type: "payment",
		title: data.status === "approved" ? "Pagamento aprovado!" : "Pagamento marcado como pendente",
		link: "/dashboard/pagamentos"
	});
	if (data.status === "approved") await botOnEvent(supabase, userId, "payment_approved", pay.user_id);
	return { ok: true };
});
var sendTransfer_createServerFn_handler = createServerRpc({
	id: "f37d7629dc3c8e04501501644a8d365c527c7b7c8631796cd881d52d137bd694",
	name: "sendTransfer",
	filename: "src/lib/admin.functions.ts"
}, (opts) => sendTransfer.__executeServer(opts));
var sendTransfer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ payment_id: stringType().uuid() }).parse(data)).handler(sendTransfer_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: pay } = await supabase.from("payments").select("id, recruiter_admin_id, status").eq("id", data.payment_id).maybeSingle();
	if (!pay) throw new Error("Pagamento não encontrado");
	if (pay.recruiter_admin_id !== userId) {
		const { data: isOwner } = await supabase.rpc("has_role", {
			_user_id: userId,
			_role: "owner"
		});
		if (!isOwner) throw new Error("Forbidden");
	}
	if (pay.status !== "approved") throw new Error("Pagamento não está aprovado.");
	const { error } = await supabase.from("payments").update({ transfer_status: "pending" }).eq("id", data.payment_id);
	if (error) throw new Error(error.message);
	await supabase.from("audit_log").insert({
		actor_id: userId,
		action: "payment.transfer_sent",
		entity: "payments",
		entity_id: data.payment_id,
		metadata: {}
	});
	return { ok: true };
});
var reviewTransfer_createServerFn_handler = createServerRpc({
	id: "dffc5147cd0f268233a36906aab72955709a30946831d8e6da103683c9c4fb4c",
	name: "reviewTransfer",
	filename: "src/lib/admin.functions.ts"
}, (opts) => reviewTransfer.__executeServer(opts));
var reviewTransfer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	payment_id: stringType().uuid(),
	status: enumType([
		"confirmed",
		"rejected",
		"none"
	])
}).parse(data)).handler(reviewTransfer_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isOwner } = await supabase.rpc("has_role", {
		_user_id: userId,
		_role: "owner"
	});
	if (!isOwner) throw new Error("Forbidden: somente o dono confere repasses.");
	const { error } = await supabase.from("payments").update({ transfer_status: data.status }).eq("id", data.payment_id);
	if (error) throw new Error(error.message);
	await supabase.from("audit_log").insert({
		actor_id: userId,
		action: `payment.transfer_${data.status}`,
		entity: "payments",
		entity_id: data.payment_id,
		metadata: {}
	});
	return { ok: true };
});
//#endregion
export { broadcastAnnouncement_createServerFn_handler, logDocumentAccess_createServerFn_handler, reviewPayment_createServerFn_handler, reviewRecruitmentForm_createServerFn_handler, reviewTransfer_createServerFn_handler, sendTransfer_createServerFn_handler, signDocumentUrl_createServerFn_handler };
