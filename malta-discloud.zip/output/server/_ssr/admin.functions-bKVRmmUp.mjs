import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DZO41X7i.mjs";
import { a as numberType, o as objectType, r as enumType, s as stringType } from "../_libs/zod.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C5a7Rlz-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-bKVRmmUp.js
/**
* Server-side audit log for sensitive document access. actor_id is derived
* from the authenticated bearer token — the client cannot forge it.
*/
var logDocumentAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	file_path: stringType().min(1).max(1024),
	file_name: stringType().min(1).max(512),
	viewed_user_id: stringType().uuid().optional(),
	viewed_user_name: stringType().max(256).optional()
}).parse(data)).handler(createSsrRpc("df214865c14ed63350120065d183dfda7d86b049cd9c5c73e227fb3f98dceda5"));
/**
* Signs a short-lived URL for a private document — but only after verifying
* that the caller is staff. Prevents non-staff bearer tokens from calling
* storage.createSignedUrl directly.
*/
var signDocumentUrl = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	file_path: stringType().min(1).max(1024),
	ttl: numberType().int().min(30).max(300).optional()
}).parse(data)).handler(createSsrRpc("897c4d2530eaaac2a8002cefc8383f11f2d3405806b6f28f45f77cedf806c697"));
/**
* Fan-out an announcement to the appropriate audience server-side. The list
* of recipient IDs never touches the client — the admin only sees success/count.
*/
var broadcastAnnouncement = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ announcement_id: stringType().uuid() }).parse(data)).handler(createSsrRpc("0bb5c03475528a4837b1f5888a4d86d332c8ca653d03b2280b8e103b65026bc1"));
/**
* Approve or reject a recruitment form on the server. The caller must be
* staff (admin/owner) — verified via is_staff() using their bearer token.
* Handles: form status, profile sync, role assignment, initial payment
* generation, audit log and notification — atomically from the server's
* point of view, so the client cannot forge or partially skip steps.
*/
var reviewRecruitmentForm = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	form_id: stringType().uuid(),
	user_id: stringType().uuid(),
	status: enumType(["approved", "rejected"]),
	notes: stringType().max(2e3).optional()
}).parse(data)).handler(createSsrRpc("6491a536c6ba64dbbebed1b5dacad628803e97897e068070b157a1b938ae1f12"));
/**
* Approve / revert a weekly payment. Only the recruiter that owns the
* charge or an owner can approve — enforced via is_staff + row check.
*/
var reviewPayment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	payment_id: stringType().uuid(),
	status: enumType(["approved", "pending"])
}).parse(data)).handler(createSsrRpc("b3b1fd758dd706bc39ac482e43b0dfdd798b72dbe39d4b854338a89975bd0a49"));
createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ payment_id: stringType().uuid() }).parse(data)).handler(createSsrRpc("f37d7629dc3c8e04501501644a8d365c527c7b7c8631796cd881d52d137bd694"));
createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	payment_id: stringType().uuid(),
	status: enumType([
		"confirmed",
		"rejected",
		"none"
	])
}).parse(data)).handler(createSsrRpc("dffc5147cd0f268233a36906aab72955709a30946831d8e6da103683c9c4fb4c"));
//#endregion
export { signDocumentUrl as a, reviewRecruitmentForm as i, logDocumentAccess as n, reviewPayment as r, broadcastAnnouncement as t };
