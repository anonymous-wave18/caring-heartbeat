import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as objectType, r as enumType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-Bhx_TPJP.js
var $$splitComponentImporter = () => import("./auth-DUXWgToc.mjs");
var searchSchema = objectType({ mode: enumType(["login", "signup"]).catch("login") });
var Route = createFileRoute("/auth")({
	validateSearch: searchSchema,
	head: () => ({ meta: [
		{ title: "Acesso — Malta Manager" },
		{
			name: "description",
			content: "Entre ou cadastre-se no Malta Manager."
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
