import { i as __toESM } from "../_runtime.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as booleanType, o as objectType, s as stringType } from "../_libs/zod.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Route } from "./auth-Bhx_TPJP.mjs";
import { t as malta_fox_default } from "./malta-fox-DqjZc_D7.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, wt as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DUXWgToc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const { mode } = Route.useSearch();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => {
			if (data.session) navigate({
				to: "/dashboard",
				replace: true
			});
		});
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid min-h-screen max-w-7xl grid-cols-1 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "relative hidden overflow-hidden border-r border-border bg-surface/40 lg:flex lg:flex-col lg:justify-between lg:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Voltar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-10 -z-10 rounded-full bg-primary/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: malta_fox_default,
							alt: "Malta",
							className: "mx-auto size-72 object-contain"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-5 items-center justify-center rounded-sm bg-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-background" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: "Malta Manager"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-[36ch] text-sm text-muted-foreground",
							children: "A infraestrutura digital da Organização Malta."
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex items-center justify-center px-6 py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "inline-flex items-center gap-2 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Voltar"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 rounded-lg bg-surface p-1 ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								search: { mode: "login" },
								className: `flex-1 rounded-md py-2 text-center text-sm font-medium transition-colors ${mode === "login" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
								children: "Entrar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								search: { mode: "signup" },
								className: `flex-1 rounded-md py-2 text-center text-sm font-medium transition-colors ${mode === "signup" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
								children: "Cadastrar"
							})]
						}),
						mode === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginForm, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignupForm, {})
					]
				})
			})]
		})
	});
}
var loginSchema = objectType({
	email: stringType().trim().email("E-mail inválido").max(255),
	password: stringType().min(6, "Mínimo de 6 caracteres").max(72)
});
function LoginForm() {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		email: "",
		password: ""
	});
	async function onSubmit(e) {
		e.preventDefault();
		const parsed = loginSchema.safeParse(form);
		if (!parsed.success) {
			toast.error(parsed.error.issues[0].message);
			return;
		}
		setLoading(true);
		const { error } = await supabase.auth.signInWithPassword(parsed.data);
		setLoading(false);
		if (error) {
			toast.error(error.message === "Invalid login credentials" ? "Credenciais inválidas" : error.message);
			return;
		}
		toast.success("Bem-vindo de volta");
		navigate({
			to: "/dashboard",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Entrar na Malta"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Acesse o painel com seus dados de membro."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "E-mail",
						name: "email",
						type: "email",
						value: form.email,
						onChange: (v) => setForm({
							...form,
							email: v
						}),
						autoComplete: "email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Senha",
						name: "password",
						type: "password",
						value: form.password,
						onChange: (v) => setForm({
							...form,
							password: v
						}),
						autoComplete: "current-password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmitButton, {
						loading,
						children: "Entrar"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: [
					"Não tem conta?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						search: { mode: "signup" },
						className: "font-medium text-primary hover:underline",
						children: "Cadastre-se"
					})
				]
			})
		]
	});
}
var signupSchema = objectType({
	firstName: stringType().trim().min(1, "Nome obrigatório").max(60),
	lastName: stringType().trim().min(1, "Sobrenome obrigatório").max(60),
	email: stringType().trim().email("E-mail inválido").max(255),
	password: stringType().min(6, "Mínimo de 6 caracteres").max(72),
	confirmPassword: stringType(),
	discordId: stringType().trim().min(1, "Discord ID obrigatório").max(40),
	discordUsername: stringType().trim().min(1, "Usuário do Discord obrigatório").max(60),
	phone: stringType().trim().min(1, "Telefone obrigatório").max(30),
	city: stringType().trim().min(1, "Cidade obrigatória").max(80),
	state: stringType().trim().min(2, "UF obrigatória").max(2),
	accept: booleanType()
}).refine((d) => d.password === d.confirmPassword, {
	message: "As senhas não coincidem",
	path: ["confirmPassword"]
}).refine((d) => d.accept, {
	message: "Você precisa aceitar os termos",
	path: ["accept"]
});
function SignupForm() {
	const navigate = useNavigate();
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		firstName: "",
		lastName: "",
		email: "",
		password: "",
		confirmPassword: "",
		discordId: "",
		discordUsername: "",
		phone: "",
		city: "",
		state: "",
		accept: false
	});
	async function onSubmit(e) {
		e.preventDefault();
		const parsed = signupSchema.safeParse(form);
		if (!parsed.success) {
			toast.error(parsed.error.issues[0].message);
			return;
		}
		setLoading(true);
		const { error } = await supabase.auth.signUp({
			email: parsed.data.email,
			password: parsed.data.password,
			options: {
				emailRedirectTo: `${window.location.origin}/dashboard`,
				data: {
					first_name: parsed.data.firstName,
					last_name: parsed.data.lastName,
					discord_id: parsed.data.discordId,
					discord_username: parsed.data.discordUsername,
					phone: parsed.data.phone,
					city: parsed.data.city,
					state: parsed.data.state.toUpperCase()
				}
			}
		});
		setLoading(false);
		if (error) {
			toast.error(error.message.includes("already registered") ? "E-mail já cadastrado" : error.message);
			return;
		}
		toast.success("Cadastro enviado! Aguarde a aprovação do administrador.");
		navigate({
			to: "/dashboard",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Solicitar cadastro"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Seus dados serão revisados por um administrador antes do acesso."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nome",
						name: "firstName",
						value: form.firstName,
						onChange: (v) => setForm({
							...form,
							firstName: v
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Sobrenome",
						name: "lastName",
						value: form.lastName,
						onChange: (v) => setForm({
							...form,
							lastName: v
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "E-mail",
					name: "email",
					type: "email",
					value: form.email,
					onChange: (v) => setForm({
						...form,
						email: v
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Senha",
						name: "password",
						type: "password",
						value: form.password,
						onChange: (v) => setForm({
							...form,
							password: v
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Confirmar senha",
						name: "confirmPassword",
						type: "password",
						value: form.confirmPassword,
						onChange: (v) => setForm({
							...form,
							confirmPassword: v
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Discord ID",
						name: "discordId",
						value: form.discordId,
						onChange: (v) => setForm({
							...form,
							discordId: v
						}),
						placeholder: "123456789012345678"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Usuário Discord",
						name: "discordUsername",
						value: form.discordUsername,
						onChange: (v) => setForm({
							...form,
							discordUsername: v
						}),
						placeholder: "@usuario"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Telefone",
					name: "phone",
					value: form.phone,
					onChange: (v) => setForm({
						...form,
						phone: v
					}),
					placeholder: "(11) 90000-0000"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_100px] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cidade",
						name: "city",
						value: form.city,
						onChange: (v) => setForm({
							...form,
							city: v
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "UF",
						name: "state",
						value: form.state,
						onChange: (v) => setForm({
							...form,
							state: v.toUpperCase()
						}),
						maxLength: 2
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-2 pt-1 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: form.accept,
						onChange: (e) => setForm({
							...form,
							accept: e.target.checked
						}),
						className: "mt-0.5 size-4 rounded border-border bg-surface accent-primary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Aceito os termos e regras internas da Organização Malta." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubmitButton, {
					loading,
					children: "Solicitar cadastro"
				})
			]
		})]
	});
}
function Field({ label, name, value, onChange, type = "text", placeholder, autoComplete, maxLength }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: name,
			className: "block text-xs font-medium uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id: name,
			name,
			type,
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder,
			autoComplete,
			maxLength,
			className: "w-full rounded-md border border-border bg-surface px-3 py-2.5 text-sm text-foreground outline-none ring-primary/30 transition-all placeholder:text-muted-foreground focus:border-primary/60 focus:ring-2"
		})]
	});
}
function SubmitButton({ loading, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "submit",
		disabled: loading,
		className: "mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground ring-1 ring-primary/60 transition-all hover:bg-primary-glow disabled:opacity-60",
		children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), children]
	});
}
//#endregion
export { AuthPage as component };
