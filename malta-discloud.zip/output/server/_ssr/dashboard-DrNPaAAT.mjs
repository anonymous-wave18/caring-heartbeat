import { i as __toESM } from "../_runtime.mjs";
import { _ as useNavigate, f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { B as LogOut, H as LoaderCircle, L as Menu, P as MessageSquare, Q as FileText, R as Megaphone, U as LayoutDashboard, X as Globe, _ as ShieldCheck, at as Crown, dt as CircleUser, n as X, ot as CreditCard, p as Sparkles, r as Users, xt as Bell } from "../_libs/lucide-react.mjs";
import { t as Route } from "./dashboard-CWL6q7Nv.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useRoles, t as computeRoleFlags } from "./useRoles-Cu15KWfN.mjs";
import { t as useAvatarUrl } from "./useAvatarUrl-BybYyeJz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DrNPaAAT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DashboardLayout() {
	const { user } = Route.useRouteContext();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setSidebarOpen(false);
	}, [pathname]);
	const profileQuery = useQuery({
		queryKey: ["profile", user.id],
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).single();
			if (error) throw error;
			return data;
		},
		staleTime: 6e4
	});
	const { isStaff, isOwner, primary } = computeRoleFlags(useRoles(user.id).data);
	const profile = profileQuery.data;
	const avatarUrl = useAvatarUrl(profile?.avatar_url ?? null);
	const [avatarFailed, setAvatarFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setAvatarFailed(false), [avatarUrl, profile?.avatar_url]);
	const unreadNotifQuery = useQuery({
		queryKey: ["notif-unread", user.id],
		queryFn: async () => {
			const { count } = await supabase.from("notifications").select("id", {
				count: "exact",
				head: true
			}).eq("user_id", user.id).is("read_at", null);
			return count ?? 0;
		},
		refetchInterval: 6e4,
		staleTime: 3e4
	});
	async function handleSignOut() {
		await queryClient.cancelQueries();
		queryClient.clear();
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			search: { mode: "login" },
			replace: true
		});
	}
	if (profileQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
	});
	const canPay = profile?.form_status === "approved";
	const memberNav = [
		{
			to: "/dashboard",
			label: "Início",
			icon: LayoutDashboard,
			exact: true
		},
		{
			to: "/dashboard/perfil",
			label: "Perfil",
			icon: CircleUser,
			exact: false
		},
		{
			to: "/dashboard/formulario",
			label: "Formulário",
			icon: FileText,
			exact: false
		},
		...canPay ? [{
			to: "/dashboard/pagamentos",
			label: "Pagamentos",
			icon: CreditCard,
			exact: false
		}] : [],
		{
			to: "/dashboard/chat",
			label: "Chat",
			icon: MessageSquare,
			exact: false
		},
		{
			to: "/dashboard/social",
			label: "Rede",
			icon: Sparkles,
			exact: false
		},
		{
			to: "/dashboard/avisos",
			label: "Avisos",
			icon: Megaphone,
			exact: false
		}
	];
	const adminNav = isStaff ? [{
		to: "/dashboard/admin",
		label: "Admin",
		icon: Users,
		exact: false
	}] : [];
	const ownerNav = isOwner ? [{
		to: "/dashboard/dono",
		label: "Dono",
		icon: Crown,
		exact: false
	}] : [];
	const masterNav = isOwner && ["candinofpx@gmail.com", "cry498434@gmail.com"].includes(profile?.email || "") ? [{
		to: "/dashboard/master",
		label: "Master (SaaS)",
		icon: Globe,
		exact: false
	}] : [];
	const nav = [
		...memberNav,
		...adminNav,
		...ownerNav,
		...masterNav
	];
	const approved = profile?.form_status === "approved" && profile?.status === "approved" || isStaff || isOwner;
	const initial = (profile?.first_name ?? "?").charAt(0).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background lg:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border bg-surface/80 px-4 backdrop-blur lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSidebarOpen(true),
						className: "inline-flex size-9 items-center justify-center rounded-md ring-1 ring-border hover:bg-surface-muted",
						"aria-label": "Abrir menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-6 items-center justify-center rounded bg-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2.5 rounded-full bg-background" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tracking-tight",
							children: "Malta Manager"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard/avisos",
						className: "relative inline-flex size-9 items-center justify-center rounded-md ring-1 ring-border hover:bg-surface-muted",
						"aria-label": "Notificações",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), (unreadNotifQuery.data ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -right-1 -top-1 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground",
							children: unreadNotifQuery.data
						})]
					})
				]
			}),
			sidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 bg-black/60 lg:hidden",
				onClick: () => setSidebarOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-border bg-surface transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:w-64 lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-16 shrink-0 items-center justify-between border-b border-border px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-7 shrink-0 items-center justify-center rounded-md bg-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-3 rounded-full bg-background" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-base font-semibold tracking-tight",
								children: "Malta Manager"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSidebarOpen(false),
							className: "inline-flex size-8 items-center justify-center rounded-md ring-1 ring-border hover:bg-surface-muted lg:hidden",
							"aria-label": "Fechar menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b border-border px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 shrink-0 overflow-hidden rounded-full bg-surface-muted ring-1 ring-border",
							children: avatarUrl && !avatarFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: avatarUrl,
								alt: "",
								className: "size-full object-cover",
								loading: "lazy",
								onError: () => setAvatarFailed(true)
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-full items-center justify-center text-sm font-semibold text-muted-foreground",
								children: initial
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "truncate text-sm font-medium",
								children: [
									profile?.first_name,
									" ",
									profile?.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-0.5 flex items-center gap-1.5",
								children: isOwner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] font-medium text-primary ring-1 ring-primary/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "size-2.5" }), " Dono"]
								}) : isStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary ring-1 ring-primary/30",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-2.5" }), " Admin"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground",
									children: primary
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex-1 overflow-y-auto no-scrollbar px-3 py-4",
						children: approved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1",
							children: nav.map((item) => {
								const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: `flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors ${active ? "bg-primary/15 text-primary ring-1 ring-primary/30" : "text-muted-foreground hover:bg-surface-muted hover:text-foreground"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: item.label
									})]
								}) }, item.to);
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-md bg-surface-muted px-3 py-3 text-xs text-muted-foreground",
							children: "Aguardando aprovação da conta."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 space-y-2 border-t border-border p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/dashboard/avisos",
							className: "relative hidden items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground ring-1 ring-border hover:bg-surface-muted hover:text-foreground lg:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }),
								"Notificações",
								(unreadNotifQuery.data ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto grid min-w-5 place-items-center rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground",
									children: unreadNotifQuery.data
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: handleSignOut,
							className: "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground ring-1 ring-border transition-colors hover:bg-surface-muted hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Sair"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-w-0 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl px-3 py-4 sm:px-6 sm:py-8 lg:px-10 lg:py-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})
			})
		]
	});
}
//#endregion
export { DashboardLayout as component };
