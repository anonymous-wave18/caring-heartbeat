import { f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { P as MessageSquare, Q as FileText, R as Megaphone, Z as FolderLock, b as Settings2, ot as CreditCard, r as Users, s as UserCog, yt as Briefcase } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin-DX5JtE7O.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/dashboard/admin",
		label: "Cadastros",
		icon: Users,
		exact: true
	},
	{
		to: "/dashboard/admin/formularios",
		label: "Formulários",
		icon: FileText,
		exact: false
	},
	{
		to: "/dashboard/admin/pagamentos",
		label: "Pagamentos",
		icon: CreditCard,
		exact: false
	},
	{
		to: "/dashboard/admin/documentos",
		label: "Documentos",
		icon: FolderLock,
		exact: false
	},
	{
		to: "/dashboard/admin/avisos",
		label: "Avisos",
		icon: Megaphone,
		exact: false
	},
	{
		to: "/dashboard/admin/membros",
		label: "Membros",
		icon: UserCog,
		exact: false
	},
	{
		to: "/dashboard/admin/cargos",
		label: "Cargos",
		icon: Briefcase,
		exact: false
	},
	{
		to: "/dashboard/admin/form-editor",
		label: "Editor de Formulário",
		icon: Settings2,
		exact: false
	},
	{
		to: "/dashboard/admin/feedback",
		label: "Feedback",
		icon: MessageSquare,
		exact: false
	}
];
function AdminLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight sm:text-3xl",
				children: "Administração"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground sm:text-sm",
				children: "Gerenciamento completo da Malta."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 ring-1 ring-border sm:mx-0 sm:flex-wrap",
				children: TABS.map((t) => {
					const active = t.exact ? pathname === t.to : pathname.startsWith(t.to);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: t.to,
						className: `inline-flex shrink-0 items-center gap-2 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${active ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-3.5" }), t.label]
					}, t.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		]
	});
}
//#endregion
export { AdminLayout as component };
