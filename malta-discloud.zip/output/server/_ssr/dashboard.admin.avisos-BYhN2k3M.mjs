import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Pin, H as LoaderCircle, O as Plus, d as Trash2 } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as broadcastAnnouncement } from "./admin.functions-bKVRmmUp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.avisos-BYhN2k3M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminAvisos() {
	const qc = useQueryClient();
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [audience, setAudience] = (0, import_react.useState)("all");
	const [pinned, setPinned] = (0, import_react.useState)(false);
	const [notify, setNotify] = (0, import_react.useState)(true);
	const annQ = useQuery({
		queryKey: ["announcements"],
		queryFn: async () => (await supabase.from("announcements").select("*").order("created_at", { ascending: false })).data ?? []
	});
	const createMut = useMutation({
		mutationFn: async () => {
			const { data: u } = await supabase.auth.getUser();
			const { data: ann, error } = await supabase.from("announcements").insert({
				title,
				body,
				audience,
				pinned,
				author_id: u.user.id
			}).select().single();
			if (error) throw error;
			if (notify) await broadcastAnnouncement({ data: { announcement_id: ann.id } });
		},
		onSuccess: () => {
			toast.success("Anúncio publicado.");
			setTitle("");
			setBody("");
			setPinned(false);
			qc.invalidateQueries({ queryKey: ["announcements"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const delMut = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("announcements").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Removido.");
			qc.invalidateQueries({ queryKey: ["announcements"] });
		}
	});
	const pinMut = useMutation({
		mutationFn: async (a) => {
			const { error } = await supabase.from("announcements").update({ pinned: !a.pinned }).eq("id", a.id);
			if (error) throw error;
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["announcements"] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[420px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "Novo anúncio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "Título",
					className: "input"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 5,
					value: body,
					onChange: (e) => setBody(e.target.value),
					placeholder: "Conteúdo",
					className: "input"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: audience,
						onChange: (e) => setAudience(e.target.value),
						className: "input",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "Todos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "members",
								children: "Membros aprovados"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "staff",
								children: "Staff (admins)"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: pinned,
							onChange: (e) => setPinned(e.target.checked)
						}), " Fixar"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: notify,
						onChange: (e) => setNotify(e.target.checked)
					}), " Notificar via sistema"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => createMut.mutate(),
					disabled: !title.trim() || !body.trim() || createMut.isPending,
					className: "inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
					children: [createMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Publicar"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-medium",
				children: "Publicados"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [(annQ.data ?? []).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-surface p-4 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: a.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								a.audience,
								" · ",
								new Date(a.created_at).toLocaleString("pt-BR")
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => pinMut.mutate({
									id: a.id,
									pinned: a.pinned
								}),
								className: `rounded-md p-1.5 ring-1 ring-border ${a.pinned ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`,
								title: "Fixar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => delMut.mutate(a.id),
								className: "rounded-md p-1.5 ring-1 ring-border text-muted-foreground hover:text-destructive",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 whitespace-pre-wrap text-sm text-muted-foreground",
						children: a.body
					})]
				}, a.id)), annQ.data && annQ.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted-foreground",
					children: "Nenhum anúncio ainda."
				})]
			})]
		})]
	});
}
//#endregion
export { AdminAvisos as component };
