import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, Q as FileText, S as Search, i as User, nt as Download } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as signDocumentUrl, n as logDocumentAccess } from "./admin.functions-bKVRmmUp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.documentos-DgZSv1Mn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminDocumentos() {
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const docsQ = useQuery({
		queryKey: ["all-docs"],
		queryFn: async () => {
			const { data: docs, error } = await supabase.from("recruitment_documents").select("id, user_id, file_path, file_name, kind, created_at").order("created_at", { ascending: false });
			if (error) {
				console.error("Erro ao buscar documentos:", error);
				return [];
			}
			const userIds = Array.from(new Set((docs ?? []).map((d) => d.user_id).filter(Boolean)));
			let profilesById = /* @__PURE__ */ new Map();
			if (userIds.length) {
				const { data: profs } = await supabase.from("profiles").select("id, first_name, last_name, email").in("id", userIds);
				for (const p of profs ?? []) profilesById.set(p.id, p);
			}
			return (docs ?? []).map((d) => ({
				...d,
				profiles: profilesById.get(d.user_id) ?? null
			}));
		}
	});
	const byUser = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const d of docsQ.data ?? []) {
			const key = d.user_id;
			const name = `${d.profiles?.first_name ?? ""} ${d.profiles?.last_name ?? ""}`.trim() || d.profiles?.email || key;
			if (!map.has(key)) map.set(key, {
				name,
				email: d.profiles?.email ?? "",
				docs: []
			});
			map.get(key).docs.push(d);
		}
		const arr = Array.from(map.entries()).map(([id, v]) => ({
			id,
			...v
		}));
		return q ? arr.filter((u) => `${u.name} ${u.email}`.toLowerCase().includes(q.toLowerCase())) : arr;
	}, [docsQ.data, q]);
	async function download(path, name) {
		try {
			const docOwner = byUser.find((u) => u.docs.some((d) => d.file_path === path));
			logDocumentAccess({ data: {
				file_path: path,
				file_name: name,
				viewed_user_id: docOwner?.id,
				viewed_user_name: docOwner?.name
			} }).catch((err) => console.error("audit log failed", err));
			const { url } = await signDocumentUrl({ data: {
				file_path: path,
				ttl: 60
			} });
			const a = document.createElement("a");
			a.href = url;
			a.download = name;
			a.target = "_blank";
			a.rel = "noopener noreferrer";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
		} catch (e) {
			const msg = e instanceof Error ? e.message : "Falha ao baixar documento";
			toast.error(msg);
		}
	}
	async function downloadAllForUser(userId) {
		const docs = byUser.find((u) => u.id === userId)?.docs ?? [];
		for (const d of docs) await download(d.file_path, d.file_name);
	}
	const openUser = byUser.find((u) => u.id === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[280px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-lg bg-surface ring-1 ring-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Buscar membro",
						className: "input pl-8"
					})]
				})
			}), docsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border max-h-[70vh] overflow-y-auto",
				children: [byUser.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setSelected(u.id),
					className: `flex w-full items-start gap-2 px-3 py-2.5 text-left text-sm ${selected === u.id ? "bg-primary/10" : "hover:bg-surface-muted"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "mt-0.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate",
							children: u.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block truncate text-xs text-muted-foreground",
							children: [u.docs.length, " arquivo(s)"]
						})]
					})]
				}) }, u.id)), byUser.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "p-4 text-sm text-muted-foreground",
					children: "Nenhum membro com documentos."
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-lg bg-surface ring-1 ring-border",
			children: openUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-medium",
					children: openUser.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: openUser.email
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => downloadAllForUser(openUser.id),
					className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Exportar todos"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: openUser.docs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-muted-foreground" }), d.file_name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground uppercase ml-6",
							children: d.kind
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => download(d.file_path, d.file_name),
						className: "inline-flex items-center gap-1 text-primary hover:underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " baixar"]
					})]
				}, d.id))
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-full min-h-[300px] place-items-center text-sm text-muted-foreground",
				children: "Selecione um membro para ver os documentos."
			})
		})]
	});
}
//#endregion
export { AdminDocumentos as component };
