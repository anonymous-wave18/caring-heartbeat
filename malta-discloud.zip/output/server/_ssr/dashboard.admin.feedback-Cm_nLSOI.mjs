import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, P as MessageSquare, d as Trash2, ft as CircleCheck, ut as CircleX } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.feedback-Cm_nLSOI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORY_LABEL = {
	geral: "Geral",
	general: "Geral",
	bug: "Bug",
	ideia: "Ideia",
	reclamacao: "Reclamação"
};
var STATUS_LABEL = {
	open: "Aberto",
	resolved: "Resolvido",
	dismissed: "Descartado"
};
function FeedbackAdmin() {
	const qc = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("open");
	const listQ = useQuery({
		queryKey: ["admin-feedback", filter],
		queryFn: async () => {
			let q = supabase.from("feedback").select("id, user_id, category, message, status, created_at").order("created_at", { ascending: false });
			if (filter !== "all") q = q.eq("status", filter);
			const { data, error } = await q;
			if (error) throw error;
			const rows = data ?? [];
			const ids = Array.from(new Set(rows.map((r) => r.user_id).filter(Boolean)));
			const profMap = /* @__PURE__ */ new Map();
			if (ids.length) {
				const { data: profs } = await supabase.from("profiles").select("id, first_name, last_name, email, discord_username, avatar_url").in("id", ids);
				for (const p of profs ?? []) profMap.set(p.id, p);
			}
			return rows.map((r) => ({
				...r,
				profile: profMap.get(r.user_id)
			}));
		}
	});
	const statusMut = useMutation({
		mutationFn: async ({ id, status }) => {
			const { error } = await supabase.from("feedback").update({ status }).eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Atualizado");
			qc.invalidateQueries({ queryKey: ["admin-feedback"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const delMut = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("feedback").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Removido");
			qc.invalidateQueries({ queryKey: ["admin-feedback"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const rows = listQ.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "inline-flex items-center gap-2 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-4 text-primary" }), " Feedbacks"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ml-auto flex flex-wrap gap-1 rounded-lg bg-surface p-1 ring-1 ring-border",
				children: [
					"open",
					"resolved",
					"dismissed",
					"all"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFilter(f),
					className: `rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${filter === f ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
					children: f === "all" ? "Todos" : STATUS_LABEL[f]
				}, f))
			})]
		}), listQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center py-10 text-muted-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" })
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-lg bg-surface p-8 text-center text-sm text-muted-foreground ring-1 ring-border",
			children: "Nenhum feedback nesta categoria."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: rows.map((r) => {
				const p = r.profile;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-surface p-4 ring-1 ring-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium text-foreground",
								children: `${p?.first_name ?? ""} ${p?.last_name ?? ""}`.trim() || p?.discord_username || (p?.email ? String(p.email).split("@")[0] : "") || "Usuário"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted-foreground",
								children: [
									p?.email ?? "sem email",
									" · ",
									new Date(r.created_at).toLocaleString("pt-BR")
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary ring-1 ring-primary/30",
									children: CATEGORY_LABEL[r.category] ?? r.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ring-1 ${r.status === "open" ? "bg-amber-500/10 text-amber-500 ring-amber-500/30" : r.status === "resolved" ? "bg-emerald-500/10 text-emerald-500 ring-emerald-500/30" : "bg-muted text-muted-foreground ring-border"}`,
									children: STATUS_LABEL[r.status] ?? r.status
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 whitespace-pre-wrap break-words text-sm text-foreground/90",
							children: r.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-2",
							children: [
								r.status !== "resolved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => statusMut.mutate({
										id: r.id,
										status: "resolved"
									}),
									className: "inline-flex items-center gap-1 rounded-md bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-500 ring-1 ring-emerald-500/30 hover:bg-emerald-500/20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Marcar resolvido"]
								}),
								r.status !== "dismissed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => statusMut.mutate({
										id: r.id,
										status: "dismissed"
									}),
									className: "inline-flex items-center gap-1 rounded-md bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground ring-1 ring-border hover:bg-surface-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5" }), " Descartar"]
								}),
								r.status !== "open" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => statusMut.mutate({
										id: r.id,
										status: "open"
									}),
									className: "inline-flex items-center gap-1 rounded-md bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-500 ring-1 ring-amber-500/30 hover:bg-amber-500/20",
									children: "Reabrir"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										if (confirm("Remover este feedback definitivamente?")) delMut.mutate(r.id);
									},
									className: "ml-auto inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Apagar"]
								})
							]
						})
					]
				}, r.id);
			})
		})]
	});
}
//#endregion
export { FeedbackAdmin as component };
