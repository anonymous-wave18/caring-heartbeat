import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, O as Plus, Y as GripVertical, d as Trash2, w as Save } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as DEFAULT_FORM_CONFIG, r as mergeFormConfig, t as DEFAULT_FIELD_LABELS } from "./formConfig-6DIhtxEt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.form-editor-DMgpgwYd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FormEditor() {
	const qc = useQueryClient();
	const cfgQ = useQuery({
		queryKey: ["form_config", "editor"],
		queryFn: async () => {
			const { data } = await supabase.from("site_settings").select("form_config").eq("id", 1).maybeSingle();
			return mergeFormConfig(data?.form_config);
		}
	});
	const [cfg, setCfg] = (0, import_react.useState)(DEFAULT_FORM_CONFIG);
	(0, import_react.useEffect)(() => {
		if (cfgQ.data) setCfg(cfgQ.data);
	}, [cfgQ.data]);
	const saveMut = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("site_settings").update({ form_config: cfg }).eq("id", 1);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Formulário atualizado.");
			qc.invalidateQueries({ queryKey: ["form_config"] });
		},
		onError: (e) => toast.error(e.message)
	});
	if (cfgQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	const fieldKeys = Object.keys(DEFAULT_FIELD_LABELS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-medium",
					children: "Editor do formulário"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Renomeie campos, defina obrigatoriedade, oculte itens e adicione perguntas personalizadas."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => saveMut.mutate(),
					disabled: saveMut.isPending,
					className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
					children: [saveMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Salvar alterações"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-5 ring-1 ring-border space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Cabeçalho"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Título"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "input",
							value: cfg.title,
							onChange: (e) => setCfg({
								...cfg,
								title: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Subtítulo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "input",
							value: cfg.subtitle,
							onChange: (e) => setCfg({
								...cfg,
								subtitle: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Aviso de rodapé"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 3,
							className: "input",
							value: cfg.warning,
							onChange: (e) => setCfg({
								...cfg,
								warning: e.target.value
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-5 ring-1 ring-border space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Campos fixos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Não é possível remover campos padrão, mas você pode renomear, ocultar ou tornar opcionais."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-border rounded-md ring-1 ring-border overflow-hidden",
						children: fieldKeys.map((k) => {
							const f = cfg.fields[k];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-12 items-center gap-2 p-2 text-sm bg-background/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "col-span-4 text-xs text-muted-foreground truncate",
										title: k,
										children: k
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "input col-span-4",
										value: f.label,
										onChange: (e) => setCfg({
											...cfg,
											fields: {
												...cfg.fields,
												[k]: {
													...f,
													label: e.target.value
												}
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "col-span-2 inline-flex items-center gap-1 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: f.required,
											onChange: (e) => setCfg({
												...cfg,
												fields: {
													...cfg.fields,
													[k]: {
														...f,
														required: e.target.checked
													}
												}
											})
										}), "Obrigatório"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "col-span-2 inline-flex items-center gap-1 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: f.hidden,
											onChange: (e) => setCfg({
												...cfg,
												fields: {
													...cfg.fields,
													[k]: {
														...f,
														hidden: e.target.checked
													}
												}
											})
										}), "Ocultar"]
									})
								]
							}, k);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-5 ring-1 ring-border space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Documentos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setCfg({
							...cfg,
							docs: [...cfg.docs, {
								key: `doc_${Date.now()}`,
								label: "Novo documento",
								accept: "*",
								required: false
							}]
						}),
						className: "inline-flex items-center gap-1 rounded-md bg-primary/10 px-2 py-1 text-xs text-primary ring-1 ring-primary/30 hover:bg-primary/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Adicionar"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: cfg.docs.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocRow, {
						doc: d,
						onChange: (nd) => {
							const arr = [...cfg.docs];
							arr[i] = nd;
							setCfg({
								...cfg,
								docs: arr
							});
						},
						onDelete: () => setCfg({
							...cfg,
							docs: cfg.docs.filter((_, j) => j !== i)
						}),
						onMove: (dir) => {
							const arr = [...cfg.docs];
							const j = i + dir;
							if (j < 0 || j >= arr.length) return;
							[arr[i], arr[j]] = [arr[j], arr[i]];
							setCfg({
								...cfg,
								docs: arr
							});
						}
					}, d.key + i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-5 ring-1 ring-border space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Perguntas personalizadas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setCfg({
							...cfg,
							customQuestions: [...cfg.customQuestions, {
								id: `q_${Date.now()}`,
								label: "Nova pergunta",
								type: "text",
								required: false
							}]
						}),
						className: "inline-flex items-center gap-1 rounded-md bg-primary/10 px-2 py-1 text-xs text-primary ring-1 ring-primary/30 hover:bg-primary/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Adicionar"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [cfg.customQuestions.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionRow, {
						q,
						onChange: (nq) => {
							const arr = [...cfg.customQuestions];
							arr[i] = nq;
							setCfg({
								...cfg,
								customQuestions: arr
							});
						},
						onDelete: () => setCfg({
							...cfg,
							customQuestions: cfg.customQuestions.filter((_, j) => j !== i)
						}),
						onMove: (dir) => {
							const arr = [...cfg.customQuestions];
							const j = i + dir;
							if (j < 0 || j >= arr.length) return;
							[arr[i], arr[j]] = [arr[j], arr[i]];
							setCfg({
								...cfg,
								customQuestions: arr
							});
						}
					}, q.id)), cfg.customQuestions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-md border border-dashed border-border p-4 text-center text-xs text-muted-foreground",
						children: "Nenhuma pergunta personalizada."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => saveMut.mutate(),
					disabled: saveMut.isPending,
					className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
					children: [saveMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Salvar alterações"]
				})
			})
		]
	});
}
function DocRow({ doc, onChange, onDelete, onMove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-background/40 p-3 ring-1 ring-border space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => onMove(-1),
							className: "text-muted-foreground hover:text-foreground text-xs",
							children: "▲"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => onMove(1),
							className: "text-muted-foreground hover:text-foreground text-xs",
							children: "▼"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-4 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input flex-1",
						value: doc.label,
						onChange: (e) => onChange({
							...doc,
							label: e.target.value
						}),
						placeholder: "Rótulo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onDelete,
						className: "text-muted-foreground hover:text-destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Chave (identificador)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "input",
							value: doc.key,
							onChange: (e) => onChange({
								...doc,
								key: e.target.value.replace(/[^\w-]+/g, "_")
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Tipos aceitos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "input",
							value: doc.accept,
							onChange: (e) => onChange({
								...doc,
								accept: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "image/*",
									children: "Imagens"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "video/*",
									children: "Vídeos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "application/pdf",
									children: "PDF"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "*",
									children: "Todos"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs inline-flex items-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: doc.required,
							onChange: (e) => onChange({
								...doc,
								required: e.target.checked
							})
						}), "Obrigatório"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs space-y-1 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Dica (opcional)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input",
					value: doc.hint ?? "",
					onChange: (e) => onChange({
						...doc,
						hint: e.target.value
					})
				})]
			})
		]
	});
}
function QuestionRow({ q, onChange, onDelete, onMove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-background/40 p-3 ring-1 ring-border space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => onMove(-1),
							className: "text-muted-foreground hover:text-foreground text-xs",
							children: "▲"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => onMove(1),
							className: "text-muted-foreground hover:text-foreground text-xs",
							children: "▼"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input flex-1",
						value: q.label,
						onChange: (e) => onChange({
							...q,
							label: e.target.value
						}),
						placeholder: "Pergunta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onDelete,
						className: "text-muted-foreground hover:text-destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Tipo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "input",
							value: q.type,
							onChange: (e) => onChange({
								...q,
								type: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "text",
									children: "Texto curto"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "textarea",
									children: "Texto longo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "number",
									children: "Número"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "select",
									children: "Seleção"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs inline-flex items-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: q.required,
							onChange: (e) => onChange({
								...q,
								required: e.target.checked
							})
						}), "Obrigatório"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs inline-flex items-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: q.hidden ?? false,
							onChange: (e) => onChange({
								...q,
								hidden: e.target.checked
							})
						}), "Ocultar"]
					})
				]
			}),
			q.type === "select" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-xs space-y-1 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Opções (uma por linha)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 3,
					className: "input",
					value: (q.options ?? []).join("\n"),
					onChange: (e) => onChange({
						...q,
						options: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean)
					})
				})]
			})
		]
	});
}
//#endregion
export { FormEditor as component };
