import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, Q as FileText, et as Eye, gt as Check, n as X, nt as Download } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as reviewRecruitmentForm } from "./admin.functions-bKVRmmUp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.formularios-PDvEG_8M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminFormularios() {
	const qc = useQueryClient();
	useQuery({
		queryKey: ["auth-user"],
		queryFn: async () => (await supabase.auth.getUser()).data.user
	});
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const formsQ = useQuery({
		queryKey: ["admin-forms", filter],
		queryFn: async () => {
			let q = supabase.from("recruitment_forms").select("*");
			if (filter !== "all") q = q.eq("status", filter);
			const { data, error } = await q.order("submitted_at", { ascending: false });
			if (error) throw error;
			const rows = data ?? [];
			const ids = Array.from(new Set(rows.map((r) => r.user_id)));
			if (ids.length === 0) return rows.map((r) => ({
				...r,
				profiles: null
			}));
			const { data: profs } = await supabase.from("profiles").select("id,first_name,last_name,email").in("id", ids);
			const byId = new Map((profs ?? []).map((p) => [p.id, p]));
			return rows.map((r) => ({
				...r,
				profiles: byId.get(r.user_id) ?? null
			}));
		}
	});
	const countsQ = useQuery({
		queryKey: ["admin-forms-counts"],
		queryFn: async () => {
			const { data } = await supabase.from("recruitment_forms").select("status");
			const c = {
				submitted: 0,
				approved: 0,
				rejected: 0,
				all: 0,
				not_submitted: 0
			};
			(data ?? []).forEach((r) => {
				c[r.status] = (c[r.status] ?? 0) + 1;
				c.all += 1;
			});
			return c;
		},
		refetchInterval: 15e3
	});
	const reviewMut = useMutation({
		mutationFn: async (args) => {
			await reviewRecruitmentForm({ data: {
				form_id: args.id,
				user_id: args.user_id,
				status: args.status,
				notes: args.notes
			} });
		},
		onSuccess: (_d, v) => {
			toast.success(v.status === "approved" ? "Aprovado." : "Recusado.");
			qc.invalidateQueries({ queryKey: ["admin-forms"] });
			setOpenId(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const open = formsQ.data?.find((f) => f.id === openId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 flex gap-2 overflow-x-auto px-1 sm:flex-wrap",
				children: [
					"submitted",
					"approved",
					"rejected",
					"all"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setFilter(f),
					className: `shrink-0 rounded-full px-3 py-1 text-xs font-medium ring-1 ${filter === f ? "bg-primary text-primary-foreground ring-primary" : "bg-surface ring-border hover:bg-surface-muted"}`,
					children: [f === "submitted" ? "Aguardando" : f === "approved" ? "Aprovados" : f === "rejected" ? "Recusados" : "Todos", countsQ.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1.5 rounded-full bg-black/10 px-1.5 py-0.5 text-[10px]",
						children: countsQ.data[f] ?? 0
					})]
				}, f))
			}),
			formsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg bg-surface ring-1 ring-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Membro"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Discord"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Enviado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y divide-border",
						children: [(formsQ.data ?? []).map((f) => {
							const p = f.profiles;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-surface-muted/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-2.5",
										children: [
											p?.first_name,
											" ",
											p?.last_name,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: p?.email
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: f.discord_contact ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: f.submitted_at ? new Date(f.submitted_at).toLocaleDateString("pt-BR") : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: f.status
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setOpenId(f.id),
											className: "text-primary hover:underline",
											children: "Ver"
										})
									})
								]
							}, f.id);
						}), formsQ.data && formsQ.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-8 text-center text-muted-foreground",
							children: "Sem registros."
						}) })]
					})]
				})
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormDetail, {
				form: open,
				onClose: () => setOpenId(null),
				onApprove: () => reviewMut.mutate({
					id: open.id,
					user_id: open.user_id,
					status: "approved"
				}),
				onReject: (notes) => reviewMut.mutate({
					id: open.id,
					user_id: open.user_id,
					status: "rejected",
					notes
				})
			})
		]
	});
}
function FormDetail({ form, onClose, onApprove, onReject }) {
	const [notes, setNotes] = (0, import_react.useState)("");
	const docsQ = useQuery({
		queryKey: ["admin-form-docs", form.id],
		queryFn: async () => {
			const { data } = await supabase.from("recruitment_documents").select("*").eq("user_id", form.user_id);
			return data ?? [];
		}
	});
	const cargoName = useQuery({
		queryKey: ["cargos"],
		queryFn: async () => (await supabase.from("cargos").select("id,name")).data ?? []
	}).data?.find((c) => c.id === form.cargo_desejado_id)?.name ?? "—";
	async function download(path, name) {
		const { data } = await supabase.storage.from("documents").createSignedUrl(path, 60);
		if (data?.signedUrl) {
			const a = document.createElement("a");
			a.href = data.signedUrl;
			a.download = name;
			a.target = "_blank";
			a.click();
		}
	}
	const [preview, setPreview] = (0, import_react.useState)(null);
	async function openPreview(path, name) {
		const { data } = await supabase.storage.from("documents").createSignedUrl(path, 300);
		if (!data?.signedUrl) return;
		const ext = name.split(".").pop()?.toLowerCase() ?? "";
		const type = [
			"png",
			"jpg",
			"jpeg",
			"gif",
			"webp",
			"bmp",
			"svg"
		].includes(ext) ? "image" : ext === "pdf" ? "pdf" : "other";
		setPreview({
			url: data.signedUrl,
			name,
			type
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-black/60 p-4",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-2xl rounded-lg bg-card p-4 ring-1 ring-border max-h-[90vh] overflow-y-auto sm:p-6",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "min-w-0 break-words text-base font-medium sm:text-lg",
						children: [
							"Formulário — ",
							form.profiles?.first_name,
							" ",
							form.profiles?.last_name
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						"aria-label": "Fechar",
						className: "shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Vaga desejada",
							value: cargoName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Nome completo",
							value: form.full_name ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Data de nascimento",
							value: form.birth_date ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "CPF",
							value: form.cpf ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Banco",
							value: form.bank_name ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Titular do banco",
							value: form.bank_holder ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Discord",
							value: form.discord_contact ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted-foreground",
							children: "Foto Discord"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1",
							children: form.discord_avatar_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: form.discord_avatar_url,
								alt: "Discord",
								className: "size-12 rounded-full ring-1 ring-border"
							}) : "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Telefone",
							value: form.phone_self ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Telefone pai",
							value: form.phone_father ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Telefone mãe",
							value: form.phone_mother ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Localização",
							value: form.location_lat && form.location_lng ? `${form.location_lat}, ${form.location_lng} (${form.location_captured_at ? new Date(form.location_captured_at).toLocaleString("pt-BR") : ""})` : "—",
							full: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Disponibilidade",
							value: form.availability ?? "—",
							full: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Experiência",
							value: form.experience ?? "—",
							full: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Motivação",
							value: form.motivation ?? "—",
							full: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Indicado por",
							value: form.referred_by ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info$1, {
							label: "Comprovante Residência",
							value: form.address_proof ?? "—"
						})
					]
				}),
				form.location_lat && form.location_lng && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					target: "_blank",
					rel: "noreferrer",
					href: `https://www.google.com/maps?q=${form.location_lat},${form.location_lng}`,
					className: "mt-2 inline-block text-sm text-primary hover:underline",
					children: "Abrir localização no mapa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 text-sm font-medium",
						children: "Documentos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "divide-y divide-border rounded-md bg-surface ring-1 ring-border",
						children: [(docsQ.data ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between p-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-muted-foreground" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary ring-1 ring-primary/30",
										children: d.kind ?? "other"
									}),
									d.file_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => openPreview(d.file_path, d.file_name),
									className: "inline-flex items-center gap-1 text-primary hover:underline",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), " ver"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => download(d.file_path, d.file_name),
									className: "inline-flex items-center gap-1 text-primary hover:underline",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " baixar"]
								})]
							})]
						}, d.id)), docsQ.data && docsQ.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "p-3 text-sm text-muted-foreground",
							children: "Nenhum documento."
						})]
					})]
				}),
				preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-[60] grid place-items-center bg-black/80 p-4",
					onClick: () => setPreview(null),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-3xl rounded-lg bg-card p-3 ring-1 ring-border max-h-[90vh] flex flex-col",
						onClick: (e) => e.stopPropagation(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: preview.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setPreview(null),
								className: "p-1 rounded hover:bg-surface-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 min-h-0 overflow-auto grid place-items-center bg-black/40 rounded",
							children: preview.type === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: preview.url,
								alt: preview.name,
								className: "max-h-full max-w-full object-contain"
							}) : preview.type === "pdf" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
								src: preview.url,
								title: preview.name,
								className: "h-[75vh] w-full bg-white rounded"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6 text-sm text-muted-foreground",
								children: ["Pré-visualização não disponível para este tipo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: preview.url,
									target: "_blank",
									rel: "noreferrer",
									className: "ml-2 text-primary hover:underline",
									children: "Abrir em nova aba"
								})]
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						placeholder: "Observações (obrigatório para recusar)",
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						className: "input"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => onReject(notes),
							disabled: !notes.trim(),
							className: "inline-flex items-center gap-1 rounded-md bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive ring-1 ring-destructive/30 hover:bg-destructive/20 disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), " Recusar"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: onApprove,
							className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Aprovar"]
						})]
					})]
				})
			]
		})
	});
}
function Info$1({ label, value, full }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: full ? "col-span-2" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 whitespace-pre-wrap",
			children: value
		})]
	});
}
//#endregion
export { AdminFormularios as component };
