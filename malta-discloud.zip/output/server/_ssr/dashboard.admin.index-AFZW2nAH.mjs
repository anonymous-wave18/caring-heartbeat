import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime, a as Overlay2, c as Title2, i as Description2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as FileCheck, H as LoaderCircle, S as Search, _t as ChartColumn, d as Trash2, gt as Check, n as X, nt as Download, r as Users, u as TrendingUp } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as DialogFooter, c as buttonVariants, i as DialogDescription, l as cn, n as Dialog, o as DialogHeader, r as DialogContent, s as DialogTitle } from "./dialog-DIpv9Fb1.mjs";
import { a as Line, c as Cell, d as Legend, i as XAxis, l as ResponsiveContainer, n as LineChart, o as CartesianGrid, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.index-AFZW2nAH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function AdminPage() {
	const queryClient = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("pending");
	const [search, setSearch] = (0, import_react.useState)("");
	const [approveTarget, setApproveTarget] = (0, import_react.useState)(null);
	const [rejectTarget, setRejectTarget] = (0, import_react.useState)(null);
	const [rejectReason, setRejectReason] = (0, import_react.useState)("");
	const [removeTarget, setRemoveTarget] = (0, import_react.useState)(null);
	const membersQuery = useQuery({
		queryKey: ["admin-members"],
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const decide = useMutation({
		mutationFn: async ({ id, status }) => {
			const { error } = await supabase.from("profiles").update({ status }).eq("id", id);
			if (error) throw error;
			await supabase.from("audit_log").insert({
				action: `member.${status}`,
				entity: "profiles",
				entity_id: id,
				metadata: {}
			});
		},
		onSuccess: (_d, v) => {
			toast.success(v.status === "approved" ? "Membro aprovado" : v.status === "rejected" ? "Cadastro rejeitado" : "Status revertido");
			queryClient.invalidateQueries({ queryKey: ["admin-members"] });
			queryClient.invalidateQueries({ queryKey: ["pending-count"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("profiles").delete().eq("id", id);
			if (error) throw error;
			await supabase.from("audit_log").insert({
				action: "member.deleted",
				entity: "profiles",
				entity_id: id,
				metadata: {}
			});
		},
		onSuccess: () => {
			toast.success("Membro removido");
			queryClient.invalidateQueries({ queryKey: ["admin-members"] });
			queryClient.invalidateQueries({ queryKey: ["pending-count"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const all = membersQuery.data ?? [];
	const filtered = all.filter((p) => {
		if (filter !== "all" && p.status !== filter) return false;
		const searchVal = search.toLowerCase().trim();
		if (!searchVal) return true;
		const fullName = `${p.first_name || ""} ${p.last_name || ""}`.toLowerCase();
		const email = (p.email || "").toLowerCase();
		const discord = (p.discord_username || "").toLowerCase();
		return fullName.includes(searchVal) || email.includes(searchVal) || discord.includes(searchVal);
	});
	const counts = {
		all: all.length,
		pending: all.filter((p) => p.status === "pending").length,
		approved: all.filter((p) => p.status === "approved").length,
		rejected: all.filter((p) => p.status === "rejected").length
	};
	const chartData = (0, import_react.useMemo)(() => {
		return [
			{
				name: "Pendentes",
				value: counts.pending,
				color: "#f59e0b"
			},
			{
				name: "Aprovados",
				value: counts.approved,
				color: "#10b981"
			},
			{
				name: "Rejeitados",
				value: counts.rejected,
				color: "#ef4444"
			}
		];
	}, [counts]);
	const growthData = (0, import_react.useMemo)(() => {
		const groups = {};
		all.forEach((p) => {
			const month = new Date(p.created_at).toLocaleDateString("pt-BR", { month: "short" });
			groups[month] = (groups[month] || 0) + 1;
		});
		return Object.entries(groups).map(([name, total]) => ({
			name,
			total
		}));
	}, [all]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
						label: "Membros Ativos",
						value: counts.approved,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
						label: "Pendentes",
						value: counts.pending,
						trend: "ação requerida",
						highlight: true,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
						label: "Taxa de Aprovação",
						value: `${all.length ? Math.round(counts.approved / all.length * 100) : 0}%`,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
						label: "Total Cadastros",
						value: all.length,
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-6 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-6 text-sm font-medium text-muted-foreground uppercase tracking-wider",
						children: "Status de Recrutamento"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[250px] w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
									data: chartData,
									innerRadius: 60,
									outerRadius: 80,
									paddingAngle: 5,
									dataKey: "value",
									children: chartData.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.color }, `cell-${index}`))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									contentStyle: {
										backgroundColor: "#18181b",
										border: "1px solid #27272a",
										borderRadius: "8px"
									},
									itemStyle: { color: "#fff" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
									verticalAlign: "bottom",
									height: 36
								})
							] })
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-6 ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-6 text-sm font-medium text-muted-foreground uppercase tracking-wider",
						children: "Crescimento Mensal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[250px] w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
								data: growthData,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										stroke: "#27272a"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										stroke: "#71717a",
										fontSize: 12,
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										stroke: "#71717a",
										fontSize: 12,
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											backgroundColor: "#18181b",
											border: "1px solid #27272a",
											borderRadius: "8px"
										},
										itemStyle: { color: "#fff" }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
										type: "monotone",
										dataKey: "total",
										stroke: "#3b82f6",
										strokeWidth: 2,
										dot: { fill: "#3b82f6" }
									})
								]
							})
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-medium tracking-tight",
					children: "Cadastros"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Gerencie cadastros, aprovações e membros da Malta."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "-mx-1 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 ring-1 ring-border sm:mx-0 sm:flex-wrap",
					children: [
						"pending",
						"approved",
						"rejected",
						"all"
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setFilter(f),
						className: `inline-flex shrink-0 items-center gap-2 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${filter === f ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: [labelFor(f), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface-muted px-1.5 py-0.5 text-[10px] tabular-nums",
							children: counts[f]
						})]
					}, f))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							const csv = "ID,Nome,Email,Status,Formulario,PIX_Chave,PIX_Tipo,PIX_Beneficiario\n" + filtered.map((m) => {
								return [
									m.id,
									`${m.first_name ?? ""} ${m.last_name ?? ""}`.trim(),
									m.email,
									m.status,
									m.form_status,
									m.pix_key ?? "",
									m.pix_key_type ?? "",
									m.pix_beneficiary ?? ""
								].map((v) => `"${String(v).replace(/"/g, "\"\"")}"`).join(",");
							}).join("\n");
							const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;" });
							const url = window.URL.createObjectURL(blob);
							const a = document.createElement("a");
							a.setAttribute("href", url);
							a.setAttribute("download", `membros_malta_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`);
							document.body.appendChild(a);
							a.click();
							document.body.removeChild(a);
						},
						className: "inline-flex shrink-0 items-center gap-1 rounded-md bg-surface-muted px-3 py-2 text-xs font-medium text-muted-foreground ring-1 ring-border transition-colors hover:text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Exportar CSV"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full min-w-0 sm:max-w-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: search,
							onChange: (e) => setSearch(e.target.value),
							placeholder: "Buscar por nome, e-mail, Discord…",
							className: "w-full rounded-md border border-border bg-surface py-2 pl-9 pr-3 text-sm outline-none ring-primary/30 placeholder:text-muted-foreground focus:border-primary/60 focus:ring-2"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-surface ring-1 ring-border",
				children: membersQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-center p-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin text-muted-foreground" })
				}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-16 text-center text-sm text-muted-foreground",
					children: "Nenhum membro encontrado."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-border",
					children: filtered.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 px-6 py-4 sm:grid-cols-[1fr_auto_auto] sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "truncate font-medium",
										children: [
											p.first_name,
											" ",
											p.last_name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: p.status })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-0.5 truncate text-xs text-muted-foreground",
									children: [
										p.email,
										" · ",
										p.discord_username ?? "sem Discord",
										" · ",
										p.city ?? "—",
										"/",
										p.state ?? "—"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground uppercase tracking-tight",
									children: "Formulário:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-0.5 text-[10px] font-medium uppercase ring-1 ${p.form_status === "approved" ? "bg-success/10 text-success ring-success/30" : p.form_status === "submitted" ? "bg-warning/10 text-warning ring-warning/30" : p.form_status === "rejected" ? "bg-destructive/10 text-destructive ring-destructive/30" : "bg-surface-muted text-muted-foreground ring-border"}`,
									children: p.form_status === "not_submitted" ? "Não enviado" : p.form_status === "submitted" ? "Em análise" : p.form_status === "approved" ? "Aprovado" : "Recusado"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									p.status !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApproveTarget(p),
										disabled: decide.isPending,
										className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground ring-1 ring-primary/60 transition-colors hover:bg-primary-glow disabled:opacity-60",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Aprovar"]
									}),
									p.status !== "rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											setRejectReason("");
											setRejectTarget(p);
										},
										disabled: decide.isPending,
										className: "inline-flex items-center gap-1 rounded-md bg-surface-muted px-3 py-1.5 text-xs font-medium text-muted-foreground ring-1 ring-border transition-colors hover:text-destructive",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), " Rejeitar"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setRemoveTarget(p),
										disabled: remove.isPending,
										className: "inline-flex items-center justify-center rounded-md bg-surface-muted p-1.5 text-muted-foreground ring-1 ring-border transition-colors hover:text-destructive",
										title: "Excluir",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
									})
								]
							})
						]
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!approveTarget,
				onOpenChange: (o) => !o && setApproveTarget(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Aprovar cadastro?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: approveTarget ? `${approveTarget.first_name ?? ""} ${approveTarget.last_name ?? ""} (${approveTarget.email}) será marcado como aprovado.` : "" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => {
						if (approveTarget) decide.mutate({
							id: approveTarget.id,
							status: "approved"
						});
						setApproveTarget(null);
					},
					children: "Aprovar"
				})] })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!rejectTarget,
				onOpenChange: (o) => !o && setRejectTarget(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Rejeitar cadastro" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: rejectTarget ? `${rejectTarget.first_name ?? rejectTarget.email}` : "" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: rejectReason,
						onChange: (e) => setRejectReason(e.target.value),
						placeholder: "Motivo da rejeição (opcional)",
						rows: 4,
						className: "w-full rounded-md border border-border bg-surface p-2 text-sm outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setRejectTarget(null),
						className: "rounded-md bg-surface-muted px-3 py-1.5 text-xs font-medium text-muted-foreground ring-1 ring-border",
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							if (rejectTarget) decide.mutate({
								id: rejectTarget.id,
								status: "rejected"
							});
							setRejectTarget(null);
						},
						className: "rounded-md bg-destructive px-3 py-1.5 text-xs font-medium text-destructive-foreground",
						children: "Confirmar rejeição"
					})] })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!removeTarget,
				onOpenChange: (o) => !o && setRemoveTarget(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Excluir membro?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					"Essa ação é irreversível e apaga o perfil de",
					" ",
					removeTarget ? `${removeTarget.first_name ?? removeTarget.email}` : "",
					"."
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => {
						if (removeTarget) remove.mutate(removeTarget.id);
						setRemoveTarget(null);
					},
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					children: "Excluir"
				})] })] })
			})
		]
	});
}
function MetricCard({ label, value, trend, highlight, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl p-5 ring-1 ${highlight ? "bg-primary/5 ring-primary/20" : "bg-surface ring-border"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold uppercase tracking-widest text-primary/80",
				children: label
			}), icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-primary/40",
				children: icon
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex items-baseline gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-3xl font-bold tracking-tight",
				children: value
			}), trend && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-[10px] font-medium ${highlight ? "text-primary" : "text-success"}`,
				children: trend
			})]
		})]
	});
}
function labelFor(f) {
	return f === "all" ? "Todos" : f === "pending" ? "Pendentes" : f === "approved" ? "Aprovados" : "Rejeitados";
}
function StatusBadge({ status }) {
	const map = {
		pending: {
			text: "Pendente",
			cls: "bg-warning/10 text-warning ring-warning/30"
		},
		approved: {
			text: "Aprovado",
			cls: "bg-success/10 text-success ring-success/30"
		},
		rejected: {
			text: "Rejeitado",
			cls: "bg-destructive/10 text-destructive ring-destructive/30"
		}
	}[status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ring-1 ${map.cls}`,
		children: map.text
	});
}
//#endregion
export { AdminPage as component };
