import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, P as MessageSquare, S as Search } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.membros-DKXfJ7eW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminMembros() {
	const qc = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const [cargoFilter, setCargoFilter] = (0, import_react.useState)("all");
	const cargosQ = useQuery({
		queryKey: ["cargos"],
		queryFn: async () => (await supabase.from("cargos").select("*").order("sort_order").order("name")).data ?? []
	});
	const membersQ = useQuery({
		queryKey: ["all-profiles-and-roles"],
		queryFn: async () => {
			const { data: profs } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
			const { data: roles } = await supabase.from("user_roles").select("user_id, role");
			const byUser = /* @__PURE__ */ new Map();
			(roles ?? []).forEach((r) => {
				byUser.set(r.user_id, [...byUser.get(r.user_id) ?? [], r.role]);
			});
			return (profs ?? []).map((p) => ({
				...p,
				roles: byUser.get(p.id) ?? []
			}));
		}
	});
	const setCargoMut = useMutation({
		mutationFn: async ({ userId, cargoId }) => {
			const { error } = await supabase.from("profiles").update({ cargo_id: cargoId }).eq("id", userId);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Cargo atualizado.");
			qc.invalidateQueries({ queryKey: ["all-profiles-and-roles"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const list = (membersQ.data ?? []).filter((m) => {
		if (cargoFilter !== "all") {
			if (cargoFilter === "none" ? m.cargo_id : m.cargo_id !== cargoFilter) return false;
		}
		if (!q) return true;
		const t = q.toLowerCase();
		return `${m.first_name ?? ""} ${m.last_name ?? ""} ${m.email}`.toLowerCase().includes(t);
	});
	const groups = /* @__PURE__ */ new Map();
	const cargoById = new Map((cargosQ.data ?? []).map((c) => [c.id, c]));
	for (const m of list) {
		const key = m.cargo_id ?? "__none";
		if (!groups.has(key)) groups.set(key, []);
		groups.get(key).push(m);
	}
	const orderedKeys = [...(cargosQ.data ?? []).map((c) => c.id).filter((id) => groups.has(id)), ...groups.has("__none") ? ["__none"] : []];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex-1 min-w-[220px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar por nome ou email",
					className: "input pl-9"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "input max-w-[220px]",
				value: cargoFilter,
				onChange: (e) => setCargoFilter(e.target.value),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "Todos os cargos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "none",
						children: "Sem cargo"
					}),
					(cargosQ.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: c.id,
						children: c.name
					}, c.id))
				]
			})]
		}), membersQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [orderedKeys.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-surface p-8 text-center text-sm text-muted-foreground ring-1 ring-border",
				children: "Nenhum membro."
			}), orderedKeys.map((key) => {
				const cargo = key === "__none" ? null : cargoById.get(key);
				const rows = groups.get(key);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-surface ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between border-b border-border px-4 py-2.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-block size-3 rounded-full ring-1 ring-border",
									style: { background: cargo?.color ?? "#64748b" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: cargo?.name ?? "Sem cargo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-background/60 px-2 py-0.5 text-[10px] text-muted-foreground ring-1 ring-border",
									children: rows.length
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-2.5",
										children: "Membro"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-2.5",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-2.5",
										children: "Formulário"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-2.5",
										children: "Cargo"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-2.5",
										children: "Papéis"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-2.5" })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-border",
								children: rows.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-surface-muted/50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-2.5",
											children: [
												m.first_name,
												" ",
												m.last_name,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: m.email
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2.5",
											children: m.status
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2.5",
											children: m.form_status
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												className: "input py-1 text-xs",
												value: m.cargo_id ?? "",
												onChange: (e) => setCargoMut.mutate({
													userId: m.id,
													cargoId: e.target.value || null
												}),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "— sem cargo —"
												}), (cargosQ.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: c.id,
													children: c.name
												}, c.id))]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex gap-1",
												children: m.roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-primary/10 px-2 py-0.5 text-[10px] text-primary ring-1 ring-primary/30",
													children: r
												}, r))
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2.5 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/dashboard/chat",
												search: { thread_id: `dm:${m.id}` },
												className: "inline-flex items-center gap-1 text-primary hover:underline",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-3.5" }), " chat"]
											})
										})
									]
								}, m.id))
							})]
						})
					})]
				}, key);
			})]
		})]
	});
}
//#endregion
export { AdminMembros as component };
