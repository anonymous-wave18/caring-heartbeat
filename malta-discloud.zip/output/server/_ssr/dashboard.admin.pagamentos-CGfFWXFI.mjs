import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, S as Search, gt as Check, n as X, nt as Download } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { r as reviewPayment } from "./admin.functions-bKVRmmUp.mjs";
import { t as formatBRL } from "./useSiteSettings-Do6dVqgS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.admin.pagamentos-CGfFWXFI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPagamentos() {
	const qc = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [scope, setScope] = (0, import_react.useState)("mine");
	const myId = useQuery({
		queryKey: ["auth-user"],
		queryFn: async () => (await supabase.auth.getUser()).data.user
	}).data?.id;
	const paymentsQ = useQuery({
		queryKey: [
			"admin-payments",
			filter,
			scope,
			myId
		],
		enabled: !!myId,
		queryFn: async () => {
			let query = supabase.from("payments").select("*");
			if (filter !== "all") query = query.eq("status", filter);
			const { data, error } = await query.order("week_start", { ascending: false });
			if (error) throw error;
			const payments = data ?? [];
			if (payments.length === 0) return [];
			const userIds = Array.from(new Set(payments.map((p) => p.user_id).filter(Boolean)));
			const paymentIds = payments.map((p) => p.id).filter(Boolean);
			const [{ data: profiles, error: profilesError }, { data: proofs, error: proofsError }] = await Promise.all([userIds.length ? supabase.from("profiles").select("id, first_name, last_name, email, recruited_by").in("id", userIds) : Promise.resolve({
				data: [],
				error: null
			}), paymentIds.length ? supabase.from("payment_proofs").select("id,payment_id,file_path,file_name,created_at").in("payment_id", paymentIds) : Promise.resolve({
				data: [],
				error: null
			})]);
			if (profilesError) throw profilesError;
			if (proofsError) throw proofsError;
			const profilesById = new Map((profiles ?? []).map((p) => [p.id, p]));
			const proofsByPayment = /* @__PURE__ */ new Map();
			for (const proof of proofs ?? []) {
				const list = proofsByPayment.get(proof.payment_id) ?? [];
				list.push(proof);
				proofsByPayment.set(proof.payment_id, list);
			}
			let rows = payments.map((p) => ({
				...p,
				profiles: profilesById.get(p.user_id) ?? null,
				payment_proofs: proofsByPayment.get(p.id) ?? []
			}));
			if (scope === "mine" && myId) rows = rows.filter((r) => r.profiles?.recruited_by === myId || r.recruiter_admin_id === myId);
			return rows;
		}
	});
	const reviewMut = useMutation({
		mutationFn: async (args) => {
			await reviewPayment({ data: {
				payment_id: args.id,
				status: args.status
			} });
		},
		onSuccess: () => {
			toast.success("Atualizado.");
			qc.invalidateQueries({ queryKey: ["admin-payments"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const generateAll = useMutation({
		mutationFn: async () => {
			const { data, error } = await supabase.rpc("generate_weekly_payments_all");
			if (error) throw error;
			return data ?? 0;
		},
		onSuccess: (n) => {
			toast.success(`Cobranças geradas para ${n} membro(s) aprovado(s).`);
			qc.invalidateQueries({ queryKey: ["admin-payments"] });
		},
		onError: (e) => {
			console.error("generate_weekly_payments_all failed:", e);
			toast.error(`Falha: ${e?.message ?? e?.hint ?? "erro desconhecido"}`);
		}
	});
	async function downloadProof(path, name) {
		const { data } = await supabase.storage.from("payment-proofs").createSignedUrl(path, 60);
		if (data?.signedUrl) {
			const a = document.createElement("a");
			a.href = data.signedUrl;
			a.download = name;
			a.target = "_blank";
			a.click();
		}
	}
	const filtered = (paymentsQ.data ?? []).filter((p) => {
		if (!q) return true;
		const t = q.toLowerCase();
		return `${p.profiles?.first_name ?? ""} ${p.profiles?.last_name ?? ""} ${p.profiles?.email ?? ""}`.toLowerCase().includes(t);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						["mine", "all"].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setScope(s),
							className: `rounded-full px-3 py-1 text-xs font-medium ring-1 transition-all ${scope === s ? "bg-primary text-primary-foreground ring-primary" : "bg-surface ring-border hover:bg-surface-muted"}`,
							children: s === "mine" ? "Meus recrutados" : "Todos"
						}, s)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-1 text-muted-foreground",
							children: "•"
						}),
						[
							"submitted",
							"pending",
							"approved",
							"overdue",
							"all"
						].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFilter(f),
							className: `rounded-full px-3 py-1 text-xs font-medium ring-1 transition-all ${filter === f ? "bg-primary text-primary-foreground ring-primary" : "bg-surface ring-border hover:bg-surface-muted"}`,
							children: f === "submitted" ? "Aguardando aprovação" : f === "pending" ? "Pendentes" : f === "approved" ? "Aprovados" : f === "overdue" ? "Vencidos" : "Todos"
						}, f))
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							const header = [
								"Membro",
								"Email",
								"Semana",
								"Vencimento",
								"Valor",
								"Status"
							].join(",");
							const csvRows = filtered.map((p) => [
								`"${p.profiles?.first_name || ""} ${p.profiles?.last_name || ""}"`.trim(),
								`"${p.profiles?.email || ""}"`,
								`"${p.week_start || ""}"`,
								`"${p.due_date || ""}"`,
								`"${p.amount || 0}"`,
								`"${p.status || ""}"`
							].join(","));
							const csv = header + "\n" + csvRows.join("\n");
							const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;" });
							const url = URL.createObjectURL(blob);
							const a = document.createElement("a");
							a.href = url;
							a.download = `pagamentos_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`;
							a.click();
						},
						className: "inline-flex items-center gap-1 rounded-md bg-surface px-3 py-2 text-sm font-medium ring-1 ring-border hover:bg-surface-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Exportar CSV"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => generateAll.mutate(),
						disabled: generateAll.isPending,
						className: "rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
						children: "Gerar cobrança da semana"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar membro",
					className: "input pl-9"
				})]
			}),
			paymentsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg bg-surface ring-1 ring-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Membro"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Semana"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Vencimento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Valor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Comprovante"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y divide-border",
						children: [filtered.map((p) => {
							const proof = p.payment_proofs?.[0];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-surface-muted/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-2.5",
										children: [
											p.profiles?.first_name,
											" ",
											p.profiles?.last_name,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: p.profiles?.email
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: p.week_start
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: p.due_date
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: formatBRL(p.amount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: p.status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5",
										children: proof ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => downloadProof(proof.file_path, proof.file_name),
											className: "inline-flex items-center gap-1 text-primary hover:underline",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " baixar"]
										}) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-end gap-1",
											children: [p.status !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												title: "Confirmar recebimento",
												onClick: () => reviewMut.mutate({
													id: p.id,
													user_id: p.user_id,
													status: "approved"
												}),
												className: "rounded-md bg-primary/10 p-1.5 text-primary hover:bg-primary/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
											}), p.status === "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												title: "Marcar como pendente",
												onClick: () => reviewMut.mutate({
													id: p.id,
													user_id: p.user_id,
													status: "pending"
												}),
												className: "rounded-md bg-destructive/10 p-1.5 text-destructive hover:bg-destructive/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
											})]
										})
									})
								]
							}, p.id);
						}), filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 7,
							className: "px-4 py-8 text-center text-muted-foreground",
							children: "Sem registros."
						}) })]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminPagamentos as component };
