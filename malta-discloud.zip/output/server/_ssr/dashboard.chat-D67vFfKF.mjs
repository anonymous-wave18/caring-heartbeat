import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.chat-D67vFfKF.js
var $$splitComponentImporter = () => import("./dashboard.chat-D_qKab-9.mjs");
var Route = createFileRoute("/_authenticated/dashboard/chat")({
	validateSearch: (search) => objectType({ thread_id: stringType().optional() }).parse(search),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
