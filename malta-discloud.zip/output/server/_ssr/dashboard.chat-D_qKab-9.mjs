import { i as __toESM } from "../_runtime.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { F as MessageSquarePlus, H as LoaderCircle, J as Hash, L as Menu, N as Mic, T as Reply, d as Trash2, f as Square, m as Shield, n as X, wt as ArrowLeft, x as Send } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useRoles, t as computeRoleFlags } from "./useRoles-Cu15KWfN.mjs";
import { t as useAvatarUrl } from "./useAvatarUrl-BybYyeJz.mjs";
import { t as Route } from "./dashboard.chat-D67vFfKF.mjs";
import { n as fetchPublicProfiles } from "./publicProfiles-RuvJBJ7q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.chat-D_qKab-9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function initials(p) {
	return (((p?.first_name ?? "").trim()[0] ?? "") + ((p?.last_name ?? "").trim()[0] ?? "")).toUpperCase() || "?";
}
function displayName(p) {
	return `${p?.first_name ?? ""} ${p?.last_name ?? ""}`.trim() || p?.discord_username || p?.email?.split("@")[0] || "Usuário";
}
function parseDmTargetId(title) {
	return title?.startsWith("dm:") ? title.slice(3) : null;
}
function useProfilesBasic(ids) {
	const key = (0, import_react.useMemo)(() => Array.from(new Set(ids)).sort(), [ids]);
	return useQuery({
		queryKey: ["profiles-basic", key],
		enabled: key.length > 0,
		staleTime: 6e4,
		queryFn: async () => {
			return await fetchPublicProfiles(key);
		}
	});
}
function ChatPage() {
	const qc = useQueryClient();
	const userId = useQuery({
		queryKey: ["auth-user"],
		queryFn: async () => (await supabase.auth.getUser()).data.user
	}).data?.id;
	const rolesQ = useRoles(userId);
	const { isStaff } = computeRoleFlags(rolesQ.data);
	const threadsQ = useQuery({
		queryKey: [
			"threads",
			userId,
			isStaff
		],
		enabled: !!userId && !rolesQ.isLoading,
		queryFn: async () => {
			let q = supabase.from("chat_threads").select("*");
			if (!isStaff) q = q.or(`member_id.eq.${userId},kind.eq.general`);
			const { data } = await q.order("kind").order("updated_at", { ascending: false });
			const rows = data ?? [];
			if (!isStaff || rows.length === 0) return rows;
			const directIds = rows.filter((t) => t.kind === "direct").map((t) => t.id);
			if (directIds.length === 0) return rows;
			const { data: msgs } = await supabase.from("chat_messages").select("thread_id").in("thread_id", directIds).limit(1e3);
			const withMsgs = new Set((msgs ?? []).map((m) => m.thread_id));
			return rows.filter((t) => t.kind !== "direct" || withMsgs.has(t.id));
		}
	});
	(0, import_react.useEffect)(() => {
		if (!isStaff) return;
		if (threadsQ.data && !threadsQ.data.find((t) => t.kind === "general")) supabase.from("chat_threads").insert({
			kind: "general",
			title: "geral"
		}).then(() => {
			qc.invalidateQueries({ queryKey: ["threads"] });
		});
	}, [
		isStaff,
		threadsQ.data,
		qc
	]);
	(0, import_react.useEffect)(() => {
		if (!userId || isStaff) return;
		if (threadsQ.data && threadsQ.data.length > 0) return;
		if (threadsQ.data && threadsQ.data.length === 0) supabase.from("chat_threads").insert({
			kind: "direct",
			member_id: userId,
			title: "Suporte"
		}).then(() => {
			qc.invalidateQueries({ queryKey: ["threads"] });
		});
	}, [
		userId,
		isStaff,
		threadsQ.data,
		qc
	]);
	const { thread_id: threadFromUrl } = Route.useSearch();
	const navigate = useNavigate();
	const [selected, setSelected] = (0, import_react.useState)(threadFromUrl && !threadFromUrl.startsWith("dm:") ? threadFromUrl : null);
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		async function resolveThread() {
			if (threadFromUrl?.startsWith("dm:")) {
				const targetId = threadFromUrl.split(":")[1];
				if (!targetId || !userId) return;
				const { data: targetRoles } = await supabase.from("user_roles").select("role").eq("user_id", targetId);
				const targetIsStaff = (targetRoles ?? []).some((r) => r.role === "admin" || r.role === "owner");
				const memberId = isStaff ? targetId : userId;
				const title = targetIsStaff || targetId === userId ? `dm:${targetId}` : `dm:${targetId}`;
				const existing = threadsQ.data?.find((t) => {
					if (t.kind !== "direct" || t.member_id !== memberId) return false;
					return parseDmTargetId(t.title) === targetId;
				});
				if (existing) {
					if (existing.title !== title) {
						await supabase.from("chat_threads").update({ title }).eq("id", existing.id);
						qc.invalidateQueries({ queryKey: ["threads"] });
					}
					setSelected(existing.id);
					navigate({
						to: "/dashboard/chat",
						search: {},
						replace: true
					});
					return;
				}
				const { data, error } = await supabase.from("chat_threads").insert({
					kind: "direct",
					member_id: memberId,
					title
				}).select().single();
				if (error) {
					if (error.code === "23505") {
						const { data: found } = await supabase.from("chat_threads").select("*").eq("kind", "direct").eq("member_id", memberId).eq("title", title).maybeSingle();
						if (found) {
							qc.invalidateQueries({ queryKey: ["threads"] });
							setSelected(found.id);
							navigate({
								to: "/dashboard/chat",
								search: {},
								replace: true
							});
							return;
						}
					}
					console.error("[chat] resolveThread insert error", error);
					toast.error("Não foi possível abrir esta conversa: " + error.message);
					navigate({
						to: "/dashboard/chat",
						search: {},
						replace: true
					});
					return;
				}
				qc.invalidateQueries({ queryKey: ["threads"] });
				setSelected(data.id);
				navigate({
					to: "/dashboard/chat",
					search: {},
					replace: true
				});
			} else if (!selected && threadsQ.data && threadsQ.data.length > 0) setSelected(threadsQ.data[0].id);
		}
		if (threadsQ.data) resolveThread();
	}, [
		threadsQ.data,
		selected,
		threadFromUrl,
		isStaff,
		userId,
		qc,
		navigate
	]);
	const memberIds = (threadsQ.data ?? []).map((t) => t.member_id).filter(Boolean);
	const dmTargetIds = (threadsQ.data ?? []).map((t) => parseDmTargetId(t.title)).filter(Boolean);
	const sidebarProfilesQ = useProfilesBasic([
		...userId ? [userId] : [],
		...memberIds,
		...dmTargetIds
	]);
	const selectedThread = selected ? threadsQ.data?.find((t) => t.id === selected) : null;
	function otherPartyId(t) {
		if (!t) return null;
		const targetId = parseDmTargetId(t.title);
		if (t.member_id && t.member_id !== userId) return t.member_id;
		if (targetId && targetId !== userId) return targetId;
		return t.member_id ?? targetId ?? null;
	}
	const selectedOtherId = otherPartyId(selectedThread);
	const selectedOtherProfile = selectedOtherId ? sidebarProfilesQ.data?.get(selectedOtherId) : null;
	const selectedLabel = selectedThread?.kind === "general" ? "Geral" : selectedOtherProfile ? displayName(selectedOtherProfile) : "Conversa";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-[calc(100dvh-140px)] md:h-[calc(100dvh-160px)] min-h-0 gap-3 sm:gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `
        ${sidebarOpen ? "fixed inset-y-0 left-0 z-40 w-[80vw] max-w-xs translate-x-0" : "fixed inset-y-0 left-0 z-40 w-[80vw] max-w-xs -translate-x-full"}
        md:relative md:z-auto md:w-64 md:translate-x-0 md:shrink-0
        rounded-none md:rounded-lg bg-surface ring-1 ring-border overflow-hidden transition-transform
      `,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-4 py-3 text-sm font-medium",
					children: ["Conversas", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedbackButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "md:hidden rounded-md p-1 hover:bg-surface-muted",
							onClick: () => setSidebarOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "divide-y divide-border overflow-y-auto no-scrollbar max-h-[calc(100dvh-180px)]",
					children: [(threadsQ.data ?? []).map((t) => {
						const otherId = otherPartyId(t);
						const directProf = otherId ? sidebarProfilesQ.data?.get(otherId) : null;
						let label = t.title ?? "Conversa";
						if (t.kind === "general") label = "Geral";
						else if (t.kind === "direct") if (directProf) label = displayName(directProf);
						else if (!isStaff) label = "Suporte Malta";
						else label = "Aguardando Contato";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setSelected(t.id);
								setSidebarOpen(false);
							},
							className: `w-full px-4 py-2.5 text-left text-sm flex items-center gap-3 ${selected === t.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-surface-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-8 shrink-0 overflow-hidden rounded-full bg-surface-muted ring-1 ring-border grid place-items-center text-[10px]",
								children: t.kind === "general" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage, {
									path: directProf?.avatar_url,
									fallback: initials(directProf)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 min-w-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate",
									children: label
								})
							})]
						}) }, t.id);
					}), threadsQ.data && threadsQ.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-4 py-3 text-sm text-muted-foreground text-center",
						children: "Nenhuma conversa encontrada."
					})]
				})]
			}),
			sidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 bg-black/50 md:hidden",
				onClick: () => setSidebarOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0 min-h-0 rounded-lg bg-surface ring-1 ring-border overflow-hidden flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 border-b border-border px-3 py-2 md:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "rounded-md p-1.5 hover:bg-surface-muted",
							onClick: () => setSidebarOpen(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium truncate flex-1",
							children: selected ? selectedLabel : "Conversas"
						}),
						selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "rounded-md p-1.5 hover:bg-surface-muted",
							onClick: () => setSelected(null),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
						})
					]
				}), selected && !selected.startsWith("dm:") && userId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadView, {
					threadId: selected,
					userId
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-full place-items-center text-sm text-muted-foreground",
					children: "Selecione uma conversa."
				})]
			})
		]
	});
}
function ThreadView({ threadId, userId }) {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const msgsQ = useQuery({
		queryKey: ["messages", threadId],
		queryFn: async () => {
			const { data } = await supabase.from("chat_messages").select("*").eq("thread_id", threadId).order("created_at");
			return data ?? [];
		}
	});
	const [text, setText] = (0, import_react.useState)("");
	const scrollRef = (0, import_react.useRef)(null);
	const [isTyping, setIsTyping] = (0, import_react.useState)(false);
	const typingTimeoutRef = (0, import_react.useRef)(null);
	const [typingUsers, setTypingUsers] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [replyingTo, setReplyingTo] = (0, import_react.useState)(null);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const mediaRecRef = (0, import_react.useRef)(null);
	const chunksRef = (0, import_react.useRef)([]);
	const recordStartRef = (0, import_react.useRef)(0);
	const senderIds = (msgsQ.data ?? []).map((m) => m.sender_id);
	const profsQ = useProfilesBasic(Array.from(new Set(senderIds)));
	const msgsById = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(msgsQ.data ?? []).forEach((x) => m.set(x.id, x));
		return m;
	}, [msgsQ.data]);
	(0, import_react.useEffect)(() => {
		scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
	}, [msgsQ.data]);
	(0, import_react.useEffect)(() => {
		const ch = supabase.channel(`msg-${threadId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "chat_messages",
			filter: `thread_id=eq.${threadId}`
		}, () => qc.invalidateQueries({ queryKey: ["messages", threadId] })).on("presence", { event: "sync" }, () => {
			const state = ch.presenceState();
			const typing = /* @__PURE__ */ new Set();
			Object.values(state).forEach((presences) => {
				presences.forEach((p) => {
					if (p.isTyping && p.userId !== userId) typing.add(p.userId);
				});
			});
			setTypingUsers(typing);
		}).subscribe(async (status) => {
			if (status === "SUBSCRIBED") await ch.track({
				userId,
				isTyping
			});
		});
		return () => {
			supabase.removeChannel(ch);
		};
	}, [
		threadId,
		qc,
		userId,
		isTyping
	]);
	function handleTyping() {
		if (!isTyping) setIsTyping(true);
		if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
		typingTimeoutRef.current = setTimeout(() => setIsTyping(false), 3e3);
	}
	const sendMut = useMutation({
		mutationFn: async (payload) => {
			const body = (payload?.body ?? text).trim();
			if (!body && !payload?.attachment_url) return;
			const insert = {
				thread_id: threadId,
				sender_id: userId,
				body: body || null,
				reply_to_id: replyingTo?.id ?? null
			};
			if (payload?.attachment_url) {
				insert.attachment_url = payload.attachment_url;
				insert.attachment_type = payload.attachment_type;
				insert.duration_ms = payload.duration_ms ?? null;
			}
			const { error } = await supabase.from("chat_messages").insert(insert);
			if (error) throw error;
			setText("");
			setReplyingTo(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const deleteMut = useMutation({
		mutationFn: async (id) => {
			const { data, error } = await supabase.from("chat_messages").update({
				deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
				body: null
			}).eq("id", id).select("id");
			if (error) throw error;
			if (!data || data.length === 0) throw new Error("Sem permissão para apagar esta mensagem (RLS).");
		},
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["messages", threadId] });
			toast.success("Mensagem apagada");
		},
		onError: (e) => toast.error(e.message)
	});
	async function startRecording() {
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mr = new MediaRecorder(stream);
			chunksRef.current = [];
			recordStartRef.current = Date.now();
			mr.ondataavailable = (e) => {
				if (e.data.size) chunksRef.current.push(e.data);
			};
			mr.onstop = async () => {
				const dur = Date.now() - recordStartRef.current;
				stream.getTracks().forEach((t) => t.stop());
				const blob = new Blob(chunksRef.current, { type: "audio/webm" });
				const path = `${userId}/${threadId}/${Date.now()}.webm`;
				const up = await supabase.storage.from("chat-attachments").upload(path, blob, { contentType: "audio/webm" });
				if (up.error) {
					toast.error(up.error.message);
					return;
				}
				const { data: pub } = supabase.storage.from("chat-attachments").getPublicUrl(path);
				await sendMut.mutateAsync({
					attachment_url: pub.publicUrl,
					attachment_type: "audio",
					duration_ms: dur
				});
			};
			mediaRecRef.current = mr;
			mr.start();
			setRecording(true);
		} catch (e) {
			toast.error("Permissão de microfone negada");
		}
	}
	function stopRecording() {
		if (mediaRecRef.current && recording) {
			mediaRecRef.current.stop();
			setRecording(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scrollRef,
				className: "flex-1 min-h-0 overflow-y-auto no-scrollbar p-3 sm:p-4 space-y-3",
				children: [
					msgsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : (msgsQ.data ?? []).map((m) => {
						const isMe = m.sender_id === userId;
						const p = profsQ.data?.get(m.sender_id);
						const replied = m.reply_to_id ? msgsById.get(m.reply_to_id) : null;
						const repliedP = replied ? profsQ.data?.get(replied.sender_id) : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwipeableRow, {
							onSwipeReply: () => setReplyingTo(m),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex items-end gap-2 group ${isMe ? "justify-end" : "justify-start"}`,
								children: [
									!isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => navigate({
											to: "/dashboard/perfil",
											search: { view_id: m.sender_id }
										}),
										className: "size-8 shrink-0 overflow-hidden rounded-full bg-surface-muted ring-1 ring-border grid place-items-center text-[11px] font-medium text-muted-foreground hover:ring-primary/50 transition-all",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage, {
											path: p?.avatar_url,
											fallback: initials(p)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative group/msg max-w-[85%] sm:max-w-[75%]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `rounded-2xl px-3 py-2 text-sm shadow-sm ${isMe ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-surface-muted text-foreground rounded-bl-sm"}`,
											children: [
												!isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mb-0.5 flex items-center gap-1.5 text-[11px] font-medium",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-foreground/80 hover:text-primary cursor-pointer",
														onClick: () => navigate({
															to: "/dashboard/perfil",
															search: { view_id: m.sender_id }
														}),
														children: displayName(p)
													}), p?.is_staff && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-0.5 rounded-full bg-primary/15 px-1.5 py-0.5 text-[9px] font-semibold text-primary ring-1 ring-primary/30",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-2.5" }), " ADM"]
													})]
												}),
												replied && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `mb-1 rounded-md border-l-2 px-2 py-1 text-[11px] ${isMe ? "border-primary-foreground/40 bg-primary-foreground/10" : "border-primary/40 bg-background/50"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-medium opacity-80",
														children: displayName(repliedP)
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "truncate opacity-70",
														children: replied.body || (replied.attachment_type === "audio" ? "🎤 Áudio" : "Anexo")
													})]
												}),
												m.deleted_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "italic opacity-60",
													children: "Mensagem apagada"
												}) : m.attachment_type === "audio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
													controls: true,
													src: m.attachment_url,
													className: "max-w-[240px]"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "whitespace-pre-wrap break-words",
													children: m.body
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `mt-0.5 flex items-center justify-between gap-2 text-[10px] ${isMe ? "text-primary-foreground/70" : "text-muted-foreground"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(m.created_at).toLocaleTimeString("pt-BR", {
														hour: "2-digit",
														minute: "2-digit"
													}) })
												})
											]
										}), !m.deleted_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `absolute top-0 ${isMe ? "-left-12" : "-right-12"} hidden group-hover/msg:flex items-center gap-1 p-1`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "p-1.5 hover:bg-surface-muted rounded-full text-muted-foreground",
												title: "Responder",
												onClick: () => setReplyingTo(m),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reply, { className: "size-3.5" })
											}), isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "p-1.5 hover:bg-destructive/10 hover:text-destructive rounded-full text-muted-foreground",
												title: "Apagar",
												onClick: () => {
													if (confirm("Deseja apagar esta mensagem?")) deleteMut.mutate(m.id);
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
											})]
										})]
									}),
									isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => navigate({
											to: "/dashboard/perfil",
											search: {}
										}),
										className: "size-8 shrink-0 overflow-hidden rounded-full bg-primary/20 ring-1 ring-primary/40 grid place-items-center text-[11px] font-medium text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarImage, {
											path: p?.avatar_url,
											fallback: initials(p)
										})
									})
								]
							})
						}, m.id);
					}),
					typingUsers.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-[11px] text-muted-foreground animate-pulse",
						children: [Array.from(typingUsers).map((id) => displayName(profsQ.data?.get(id))).join(", "), " está digitando..."]
					}),
					msgsQ.data && msgsQ.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center text-sm text-muted-foreground",
						children: "Sem mensagens ainda."
					})
				]
			}),
			replyingTo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-t border-border bg-primary/5 px-3 py-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reply, { className: "size-3.5 text-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium text-primary",
							children: ["Respondendo a ", displayName(profsQ.data?.get(replyingTo.sender_id))]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-muted-foreground",
							children: replyingTo.body || "Anexo"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setReplyingTo(null),
						className: "p-1 rounded hover:bg-surface-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					sendMut.mutate(void 0);
				},
				className: "shrink-0 flex items-center gap-2 border-t border-border p-2 sm:p-3 bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `p-2 rounded-full transition-colors ${recording ? "bg-destructive text-white animate-pulse" : "text-muted-foreground hover:text-primary hover:bg-primary/5"}`,
						title: recording ? "Parar" : "Gravar áudio",
						onClick: recording ? stopRecording : startRecording,
						children: recording ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: text,
						onChange: (e) => {
							setText(e.target.value);
							handleTyping();
						},
						placeholder: "Digite uma mensagem…",
						className: "input flex-1 min-w-0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: !text.trim() || sendMut.isPending,
						className: "inline-flex items-center rounded-full bg-primary p-2 text-primary-foreground hover:bg-primary/90 disabled:opacity-50 shadow-lg shadow-primary/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-5" })
					})
				]
			})
		]
	});
}
function SwipeableRow({ children, onSwipeReply }) {
	const [dx, setDx] = (0, import_react.useState)(0);
	const startX = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		onTouchStart: (e) => {
			startX.current = e.touches[0].clientX;
		},
		onTouchMove: (e) => {
			if (startX.current == null) return;
			const d = e.touches[0].clientX - startX.current;
			if (d > 0 && d < 100) setDx(d);
		},
		onTouchEnd: () => {
			if (dx > 60) onSwipeReply();
			setDx(0);
			startX.current = null;
		},
		style: {
			transform: `translateX(${dx}px)`,
			transition: dx === 0 ? "transform 0.2s" : "none"
		},
		className: "relative",
		children: [dx > 20 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reply, { className: "absolute left-2 top-1/2 -translate-y-1/2 size-4 text-primary" }), children]
	});
}
function AvatarImage({ path, fallback }) {
	const url = useAvatarUrl(path ?? null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setFailed(false), [url, path]);
	if (url && !failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt: "",
		className: "size-full object-cover",
		onError: () => setFailed(true)
	});
	if (path && !failed && (path.startsWith("http") || path.startsWith("blob:"))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: path,
		alt: "",
		className: "size-full object-cover",
		onError: () => setFailed(true)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback });
}
function FeedbackButton() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("geral");
	const [sending, setSending] = (0, import_react.useState)(false);
	async function send() {
		if (!msg.trim()) return;
		setSending(true);
		try {
			const { data: u } = await supabase.auth.getUser();
			if (!u.user?.id) throw new Error("Sessão expirada. Faça login novamente.");
			const { error } = await supabase.from("feedback").insert({
				user_id: u.user.id,
				category: cat,
				message: msg.trim()
			}).select().single();
			if (error) throw error;
			toast.success("Feedback enviado. Obrigado!");
			setMsg("");
			setOpen(false);
		} catch (e) {
			console.error("[feedback] insert error", e);
			toast.error(e?.message || "Erro ao enviar feedback");
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		title: "Enviar Feedback",
		className: "rounded-md p-1 hover:bg-primary/10 text-primary",
		onClick: () => setOpen(true),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquarePlus, { className: "size-4" })
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-black/50 p-4",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl bg-surface p-5 ring-1 ring-border",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-medium mb-3",
					children: "Enviar Feedback"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: cat,
					onChange: (e) => setCat(e.target.value),
					className: "input w-full mb-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "geral",
							children: "Geral"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "bug",
							children: "Bug"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ideia",
							children: "Ideia"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "reclamacao",
							children: "Reclamação"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: msg,
					onChange: (e) => setMsg(e.target.value),
					rows: 4,
					placeholder: "Descreva…",
					className: "input w-full mb-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setOpen(false),
						className: "px-3 py-1.5 text-sm rounded-md hover:bg-surface-muted",
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: send,
						disabled: sending || !msg.trim(),
						className: "px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground disabled:opacity-50",
						children: sending ? "Enviando…" : "Enviar"
					})]
				})
			]
		})
	})] });
}
//#endregion
export { ChatPage as component };
