import { f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as ScrollText, _ as ShieldCheck, at as Crown, bt as Bot, it as Database, r as Users, y as Settings } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono-Bvty062r.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/dashboard/dono",
		label: "Configurações",
		icon: Settings,
		exact: true
	},
	{
		to: "/dashboard/dono/permissoes",
		label: "Permissões",
		icon: ShieldCheck,
		exact: false
	},
	{
		to: "/dashboard/dono/repasses",
		label: "Recrutadores",
		icon: Users,
		exact: false
	},
	{
		to: "/dashboard/dono/discord-bot",
		label: "Bot Discord",
		icon: Bot,
		exact: false
	},
	{
		to: "/dashboard/dono/auditoria",
		label: "Auditoria",
		icon: ScrollText,
		exact: false
	},
	{
		to: "/dashboard/dono/database",
		label: "Banco de Dados",
		icon: Database,
		exact: false
	}
];
function OwnerLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-9 shrink-0 place-items-center rounded-lg bg-primary/15 ring-1 ring-primary/30 sm:size-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "size-5 text-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-2xl font-medium tracking-tight sm:text-3xl",
						children: "Painel Desenvolvedor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground sm:text-sm",
						children: "Controle owner."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 ring-1 ring-border sm:mx-0 sm:flex-wrap",
				children: TABS.map((t) => {
					const active = t.exact ? pathname === t.to : pathname.startsWith(t.to);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: t.to,
						className: `inline-flex shrink-0 items-center gap-2 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${active ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-3.5" }), t.label]
					}, t.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		]
	});
}
//#endregion
export { OwnerLayout as component };
