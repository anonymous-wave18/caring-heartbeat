import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { B as LogOut, H as LoaderCircle, M as Pencil, S as Search, Tt as Activity, V as LogIn, _ as ShieldCheck, a as UserPlus, ct as Clock, d as Trash2, et as Eye, ft as CircleCheck, ht as ChevronDown, nt as Download, o as UserMinus, pt as CircleAlert, rt as DollarSign, ut as CircleX, x as Send, y as Settings } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.auditoria-CKdVa1gE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ACTION_MAP = {
	"form.approved": {
		label: "Formulário aprovado",
		icon: CircleCheck,
		tone: "success",
		describe: (l, a) => `${a} aprovou o formulário de recrutamento.`
	},
	"form.rejected": {
		label: "Formulário rejeitado",
		icon: CircleX,
		tone: "danger",
		describe: (l, a) => `${a} rejeitou um formulário.`
	},
	"form.submitted": {
		label: "Formulário enviado",
		icon: Send,
		tone: "info",
		describe: (l, a) => `${a} enviou um formulário de recrutamento.`
	},
	"member.added": {
		label: "Membro adicionado",
		icon: UserPlus,
		tone: "success",
		describe: (l, a) => `${a} adicionou um novo membro.`
	},
	"member.removed": {
		label: "Membro removido",
		icon: UserMinus,
		tone: "danger",
		describe: (l, a) => `${a} removeu um membro.`
	},
	"role.granted": {
		label: "Cargo concedido",
		icon: ShieldCheck,
		tone: "success",
		describe: (l, a) => `${a} concedeu o cargo ${l.metadata?.role ?? ""}.`.trim()
	},
	"role.revoked": {
		label: "Cargo revogado",
		icon: ShieldCheck,
		tone: "warning",
		describe: (l, a) => `${a} revogou um cargo.`
	},
	"role.grant": {
		label: "Cargo concedido",
		icon: ShieldCheck,
		tone: "success",
		describe: (l, a) => `${a} concedeu o cargo ${l.metadata?.role ?? ""}.`.trim()
	},
	"role.revoke": {
		label: "Cargo revogado",
		icon: ShieldCheck,
		tone: "warning",
		describe: (l, a) => `${a} revogou um cargo${l.metadata?.role ? ` (${l.metadata.role})` : ""}.`
	},
	"payment.created": {
		label: "Cobrança gerada",
		icon: DollarSign,
		tone: "info",
		describe: (l, a) => `${a} gerou uma cobrança semanal.`
	},
	"payment.paid": {
		label: "Pagamento confirmado",
		icon: DollarSign,
		tone: "success",
		describe: (l, a) => `${a} confirmou um pagamento.`
	},
	"payment.rejected": {
		label: "Pagamento rejeitado",
		icon: CircleX,
		tone: "danger",
		describe: (l, a) => `${a} rejeitou um comprovante de pagamento.`
	},
	"document.viewed": {
		label: "Documento visualizado",
		icon: Eye,
		tone: "info",
		describe: (l, a) => `${a} visualizou um documento sensível.`
	},
	"document.deleted": {
		label: "Documento apagado",
		icon: Trash2,
		tone: "danger",
		describe: (l, a) => `${a} apagou um documento.`
	},
	"profile.updated": {
		label: "Perfil atualizado",
		icon: Pencil,
		tone: "neutral",
		describe: (l, a) => `${a} editou o próprio perfil.`
	},
	"settings.updated": {
		label: "Configurações alteradas",
		icon: Settings,
		tone: "warning",
		describe: (l, a) => `${a} alterou configurações do sistema.`
	},
	"settings.update": {
		label: "Configurações alteradas",
		icon: Settings,
		tone: "warning",
		describe: (l, a) => `${a} alterou configurações do sistema${l.metadata?.key ? ` (${l.metadata.key})` : ""}.`
	},
	"form.approve": {
		label: "Formulário aprovado",
		icon: CircleCheck,
		tone: "success",
		describe: (l, a) => `${a} aprovou um formulário de recrutamento.`
	},
	"form.reject": {
		label: "Formulário rejeitado",
		icon: CircleX,
		tone: "danger",
		describe: (l, a) => `${a} rejeitou um formulário.`
	},
	"payment.approve": {
		label: "Pagamento confirmado",
		icon: DollarSign,
		tone: "success",
		describe: (l, a) => `${a} confirmou um pagamento.`
	},
	"payment.reject": {
		label: "Pagamento rejeitado",
		icon: CircleX,
		tone: "danger",
		describe: (l, a) => `${a} rejeitou um comprovante.`
	},
	"auth.login": {
		label: "Login",
		icon: LogIn,
		tone: "neutral",
		describe: (l, a) => `${a} entrou na plataforma.`
	},
	"auth.logout": {
		label: "Logout",
		icon: LogOut,
		tone: "neutral",
		describe: (l, a) => `${a} saiu da plataforma.`
	}
};
function metaFor(action) {
	if (ACTION_MAP[action]) return ACTION_MAP[action];
	const human = action.replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
	return {
		label: human,
		icon: Activity,
		tone: "neutral",
		describe: (_l, a) => `${a} realizou "${human}".`
	};
}
var toneClasses = {
	success: "bg-emerald-500/10 text-emerald-600 ring-emerald-500/20",
	danger: "bg-red-500/10 text-red-600 ring-red-500/20",
	warning: "bg-amber-500/10 text-amber-600 ring-amber-500/20",
	info: "bg-primary/10 text-primary ring-primary/20",
	neutral: "bg-muted text-muted-foreground ring-border"
};
function actorName(l) {
	const p = l.profiles;
	return `${p?.first_name ?? ""} ${p?.last_name ?? ""}`.trim() || p?.email || "Sistema";
}
function timeAgo(iso) {
	const diff = Date.now() - new Date(iso).getTime();
	const s = Math.floor(diff / 1e3);
	if (s < 60) return "há poucos segundos";
	const m = Math.floor(s / 60);
	if (m < 60) return `há ${m} min`;
	const h = Math.floor(m / 60);
	if (h < 24) return `há ${h}h`;
	const d = Math.floor(h / 24);
	if (d < 30) return `há ${d}d`;
	return new Date(iso).toLocaleDateString("pt-BR");
}
function formatMetaEntry(key, value) {
	if (value === null || value === void 0 || value === "") return null;
	if (key === "ua" || key === "platform" || key === "user_id") return null;
	if (typeof value === "object") return `${key}: ${JSON.stringify(value)}`;
	return `${key}: ${value}`;
}
function OwnerAuditoria() {
	const [q, setQ] = (0, import_react.useState)("");
	const [actionFilter, setActionFilter] = (0, import_react.useState)("all");
	const [expanded, setExpanded] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const retentionQ = useQuery({
		queryKey: ["audit-retention"],
		queryFn: async () => {
			const { data, error } = await supabase.rpc("audit_retention_status");
			if (error) return null;
			return Array.isArray(data) ? data[0] : data;
		}
	});
	const logsQ = useQuery({
		queryKey: ["audit-log", actionFilter],
		queryFn: async () => {
			let query = supabase.from("audit_log").select("*").order("created_at", { ascending: false });
			if (actionFilter !== "all") query = query.eq("action", actionFilter);
			const { data: logs, error } = await query.limit(500);
			if (error) {
				console.error("[auditoria] audit_log error:", error);
				throw error;
			}
			const rows = logs ?? [];
			const actorIds = Array.from(new Set(rows.map((r) => r.actor_id).filter(Boolean)));
			let profileMap = /* @__PURE__ */ new Map();
			if (actorIds.length) {
				const { data: profs } = await supabase.from("profiles").select("id, first_name, last_name, email").in("id", actorIds);
				profileMap = new Map((profs ?? []).map((p) => [p.id, p]));
			}
			return rows.map((r) => ({
				...r,
				profiles: profileMap.get(r.actor_id) ?? null
			}));
		}
	});
	const filtered = (logsQ.data ?? []).filter((l) => {
		if (!q) return true;
		const search = q.toLowerCase();
		const meta = metaFor(l.action);
		return actorName(l).toLowerCase().includes(search) || l.action.toLowerCase().includes(search) || meta.label.toLowerCase().includes(search) || JSON.stringify(l.metadata ?? {}).toLowerCase().includes(search);
	});
	const uniqueActions = Array.from(new Set((logsQ.data ?? []).map((l) => l.action)));
	const toggle = (id) => {
		setExpanded((prev) => {
			const next = new Set(prev);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			return next;
		});
	};
	if (logsQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	const exportCSV = () => {
		const rows = filtered.map((l) => {
			const m = metaFor(l.action);
			return {
				data: new Date(l.created_at).toLocaleString("pt-BR"),
				acao: m.label,
				ator: actorName(l),
				email: l.profiles?.email ?? "",
				entidade: l.entity ?? "",
				entidade_id: l.entity_id ?? "",
				detalhes: JSON.stringify(l.metadata ?? {})
			};
		});
		const headers = Object.keys(rows[0] ?? {
			data: "",
			acao: "",
			ator: "",
			email: "",
			entidade: "",
			entidade_id: "",
			detalhes: ""
		});
		const escape = (v) => `"${String(v).replace(/"/g, "\"\"")}"`;
		const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h])).join(","))].join("\n");
		const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `auditoria_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	};
	const ret = retentionQ.data;
	const daysLeft = ret?.days_until_purge != null ? Number(ret.days_until_purge) : null;
	const showWarn = daysLeft != null && daysLeft <= 2 && ret?.total_rows > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-3 text-xs ring-1 ring-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
							"Retenção: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-foreground",
								children: "7 dias"
							}),
							". Logs mais antigos são apagados automaticamente todo dia às 03:00 UTC.",
							ret?.total_rows != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"· ",
								ret.total_rows,
								" evento",
								ret.total_rows === 1 ? "" : "s",
								" armazenado",
								ret.total_rows === 1 ? "" : "s"
							] })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: exportCSV,
						className: "btn btn-ghost inline-flex items-center gap-1.5 text-xs cursor-pointer transition-all duration-200 hover:scale-105 hover:bg-primary/10 hover:text-primary active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 transition-transform group-hover:-translate-y-0.5" }), " Exportar CSV"]
					})]
				}), showWarn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-start gap-2 rounded-md bg-amber-500/10 p-2 text-amber-700 ring-1 ring-amber-500/20 dark:text-amber-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Atenção:" }),
								" o log mais antigo tem ",
								Math.floor(Number(ret.oldest_age_days)),
								" dias e será apagado em ",
								Math.ceil(daysLeft),
								" dia",
								Math.ceil(daysLeft) === 1 ? "" : "s",
								". Exporte agora se quiser guardar um backup."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: exportCSV,
							className: "inline-flex shrink-0 items-center gap-1.5 rounded-md bg-amber-500 px-3 py-1.5 text-xs font-medium text-white shadow-sm cursor-pointer transition-all duration-200 hover:scale-105 hover:bg-amber-600 hover:shadow-md active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Exportar agora"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 items-center gap-2 max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Pesquisar por pessoa, ação ou detalhe...",
							className: "input pl-8"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: actionFilter,
						onChange: (e) => setActionFilter(e.target.value),
						className: "input w-40 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Todas ações"
						}), uniqueActions.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a,
							children: metaFor(a).label
						}, a))]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						filtered.length,
						" evento",
						filtered.length === 1 ? "" : "s"
					]
				})]
			}),
			filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-8 text-center text-sm text-muted-foreground ring-1 ring-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mx-auto mb-2 size-6 opacity-50" }), "Nenhum evento encontrado."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "relative space-y-3 border-l border-border pl-6",
				children: filtered.map((l) => {
					const meta = metaFor(l.action);
					const Icon = meta.icon;
					const actor = actorName(l);
					const isOpen = expanded.has(l.id);
					const metaEntries = Object.entries(l.metadata ?? {}).map(([k, v]) => formatMetaEntry(k, v)).filter(Boolean);
					const hasDetails = metaEntries.length > 0 || l.entity_id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `absolute -left-[34px] top-3 grid size-7 place-items-center rounded-full ring-2 ring-background ${toneClasses[meta.tone]}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-surface p-4 ring-1 ring-border transition hover:ring-primary/30",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium",
										children: meta.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 text-sm text-muted-foreground",
										children: meta.describe(l, actor)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										title: new Date(l.created_at).toLocaleString("pt-BR"),
										children: timeAgo(l.created_at)
									}), hasDetails && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => toggle(l.id),
										className: "inline-flex items-center gap-1 rounded-md px-2 py-1 hover:bg-surface-muted/60",
										children: ["Detalhes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-3 transition-transform ${isOpen ? "rotate-180" : ""}` })]
									})]
								})]
							}), isOpen && hasDetails && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 space-y-1 rounded-md bg-surface-muted/40 p-3 text-xs",
								children: [
									l.entity && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "Alvo: "
										}),
										l.entity,
										l.entity_id ? ` · ${l.entity_id}` : ""
									] }),
									metaEntries.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: e }, i)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-muted-foreground",
										children: [
											new Date(l.created_at).toLocaleString("pt-BR"),
											" · por ",
											actor,
											l.profiles?.email ? ` (${l.profiles.email})` : ""
										]
									})
								]
							})]
						})]
					}, l.id);
				})
			})
		]
	});
}
//#endregion
export { OwnerAuditoria as component };
