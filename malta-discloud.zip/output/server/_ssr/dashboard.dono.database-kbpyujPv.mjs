import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Info, it as Database, tt as ExternalLink } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.database-kbpyujPv.js
var import_jsx_runtime = require_jsx_runtime();
function OwnerDatabase() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-primary/5 p-4 text-sm ring-1 ring-primary/20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-primary",
							children: "Atenção: "
						}),
						"apenas o ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "CryAnd" }),
						" deve e pode mexer nessa aréa. Caso alguém mexa pode resultar ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "EM QUEDA  DO SISTEMA!!" })
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-medium",
							children: "Migrar para um Supabase próprio"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Se um dia você quiser mudar para uma conta Supabase criada por você (fora do Cloud), este é o passo a passo. É uma operação avançada e substitui o banco atual — só faça se realmente for necessário."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "space-y-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 1,
								title: "Criar o projeto no Supabase",
								children: [
									"Entre em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "text-primary underline",
										href: "https://supabase.com",
										target: "_blank",
										rel: "noreferrer",
										children: "supabase.com"
									}),
									", crie um novo projeto e anote o ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "Project URL" }),
									" e a ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "Publishable (anon) key" }),
									" em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Project Settings → API" }),
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 2,
								title: "Rodar as migrações",
								children: [
									"Todas as tabelas estão em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "supabase/migrations/" }),
									" deste repositório. Aplique-as com a CLI:",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-2 overflow-x-auto rounded-md bg-background/60 p-3 text-xs ring-1 ring-border",
										children: `npx supabase login
npx supabase link --project-ref SEU_PROJECT_REF
npx supabase db push`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 3,
								title: "Criar os buckets de arquivos",
								children: [
									"No painel do Supabase, em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Storage" }),
									", crie três buckets ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "privados" }),
									": ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "avatars" }),
									", ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "documents" }),
									" e ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "payment-proofs" }),
									". As políticas de acesso já vêm nas migrações."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 4,
								title: "Ativar o provedor de e-mail",
								children: [
									"Em ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Authentication → Providers → Email" }),
									", mantenha ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "Email" }),
									" ativo. Desative ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "Confirm email" }),
									" se quiser login imediato (não recomendado em produção)."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 5,
								title: "Atualizar as variáveis de ambiente",
								children: [
									"No repositório, edite o ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: ".env" }),
									":",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-2 overflow-x-auto rounded-md bg-background/60 p-3 text-xs ring-1 ring-border",
										children: `VITE_SUPABASE_URL=https://SEU_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
VITE_SUPABASE_PROJECT_ID=SEU_REF`
									}),
									"E republique o app para carregar as novas chaves. As chaves privadas (",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "SUPABASE_SERVICE_ROLE_KEY" }),
									") ficam apenas no lado do servidor."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
								n: 6,
								title: "Promover o Dono no novo banco",
								children: [
									"Assim que o e-mail ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "cry498434@gmail.com" }),
									" criar conta nesse novo banco, a trigger ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "handle_new_user" }),
									" já o promove a ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "owner" }),
									" automaticamente (isso está codado na migração). Se por algum motivo você quiser promover outro usuário depois, rode:",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-2 overflow-x-auto rounded-md bg-background/60 p-3 text-xs ring-1 ring-border",
										children: `INSERT INTO public.user_roles (user_id, role)
VALUES ('UUID_DO_USUARIO', 'owner');`
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://supabase.com/docs/guides/cli/local-development",
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-1.5 rounded-md bg-surface-muted px-3 py-2 text-xs font-medium ring-1 ring-border hover:bg-surface",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" }), " Docs Supabase CLI"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://supabase.com/docs/guides/database/postgres/row-level-security",
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-1.5 rounded-md bg-surface-muted px-3 py-2 text-xs font-medium ring-1 ring-border hover:bg-surface",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" }), " RLS explicado"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Recursos criados neste banco"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 text-sm sm:grid-cols-2",
						children: [
							"profiles",
							"user_roles (owner/admin/member)",
							"site_settings",
							"recruitment_forms + recruitment_documents",
							"payments + payment_proofs",
							"announcements",
							"notifications",
							"chat_threads + chat_messages",
							"audit_log"
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-md bg-background/50 px-3 py-2 ring-1 ring-border font-mono text-xs",
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Todas com RLS ativa. Somente (owner) enxerga esta página."
					})
				]
			})
		]
	});
}
function Step({ n, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-7 shrink-0 place-items-center rounded-full bg-primary/15 text-xs font-bold text-primary ring-1 ring-primary/30",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-muted-foreground",
				children
			})]
		})]
	});
}
//#endregion
export { OwnerDatabase as component };
