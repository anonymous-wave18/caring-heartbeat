import { i as __toESM } from "../_runtime.mjs";
import { O as isRedirect, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DZO41X7i.mjs";
import { a as numberType, c as unionType, i as literalType, n as booleanType, o as objectType, r as enumType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as RefreshCw, H as LoaderCircle, K as Inbox, S as Search, _ as ShieldCheck, bt as Bot, ft as CircleCheck, gt as Check, h as ShieldX, ht as ChevronDown, k as PlugZap, mt as ChevronUp, nt as Download, pt as CircleAlert, ut as CircleX, w as Save, x as Send } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C5a7Rlz-.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Root } from "../_libs/@radix-ui/react-label+[...].mjs";
import { a as DialogFooter, i as DialogDescription, l as cn, n as Dialog, o as DialogHeader, r as DialogContent, s as DialogTitle, t as Button } from "./dialog-DIpv9Fb1.mjs";
import { a as ItemText, c as Root2, d as Separator, f as Trigger, i as ItemIndicator, l as ScrollDownButton, m as Viewport, n as Icon, o as Label$1, p as Value, r as Item, s as Portal, t as Content2, u as ScrollUpButton } from "../_libs/@radix-ui/react-select+[...].mjs";
import { n as Thumb, t as Root$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.discord-bot-B8LXjFAr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var optionalSnowflake = unionType([stringType().regex(/^[0-9]{15,25}$/, "ID do Discord inválido (apenas números, 15-25 dígitos)."), literalType("")]).optional().nullable();
/** Status do bot: secrets presentes (booleano) + ping. Nunca devolve valores de segredo. */
var getBotStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("3ea81bdb10d8daa89adec9f438db664083b90185a95c973e8a227b000c8faf40"));
/** Teste manual de conectividade: faz ping real, grava no log e devolve latência/motivo. */
var testBotConnection = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("bdad539c038fa8a258655db007a4f09fbbf05552fcdd3656211f84d57a7e6b20"));
var saveBotSettings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	guild_id: optionalSnowflake,
	default_member_role_id: optionalSnowflake,
	overdue_role_id: optionalSnowflake,
	removal_after_days: numberType().int().min(1).max(90),
	enabled: booleanType()
}).parse(data)).handler(createSsrRpc("de2bfbc9e956b5d60cf4a81ba49771634e6130159987ed4e963ab5dfee479bb3"));
var saveRoleMap = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ entries: arrayType(objectType({
	cargo_id: stringType().uuid(),
	discord_role_id: stringType()
})).max(100) }).parse(data)).handler(createSsrRpc("f18bd1d51f1e614f713933a7ed1986360314ddea0345f56d924e895dcb0f1073"));
var saveBotMessages = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ messages: arrayType(objectType({
	key: enumType([
		"welcome",
		"payment_pending",
		"payment_overdue",
		"role_removed",
		"renewed"
	]),
	template: stringType().max(1800)
})).min(1).max(5) }).parse(data)).handler(createSsrRpc("0b2a4a73a18967b2f279bfdd79b8d55ad8313d34abf4fed19ad0f8a4cb4ece29"));
var assignDiscordRole = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	cargo_id: stringType().uuid()
}).parse(data)).handler(createSsrRpc("440161562212790cf894ba6a603b6d216fa6e7efe73cb171171343ef5a451583"));
var removeDiscordRole = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	cargo_id: stringType().uuid()
}).parse(data)).handler(createSsrRpc("d45e34cbcdf5255df7f5745857b8c2202722bb3f9a4491d0e4ec61fd8bfacf0a"));
var sendDiscordDm = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	message: stringType().trim().min(1).max(1800)
}).parse(data)).handler(createSsrRpc("9825a52e9ac7853994f3d71b9c094a3c5a03879ad044a7bf64262c76fa6635c3"));
var syncDiscordUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ user_id: stringType().uuid() }).parse(data)).handler(createSsrRpc("4e85a1fb146ae1c6a476cf5547d5ad332a719fe3f9e5120e7b2525d00f260b08"));
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Root$1.displayName;
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
var Select = Root2;
var SelectValue = Value;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = Trigger.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollUpButton, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = ScrollUpButton.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollDownButton, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = ScrollDownButton.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Content2, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = Content2.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", className),
	...props
}));
SelectLabel.displayName = Label$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemText, { children })]
}));
SelectItem.displayName = Item.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = Separator.displayName;
var MESSAGE_KEYS = [
	{
		key: "welcome",
		label: "Boas-vindas (formulário aprovado)"
	},
	{
		key: "payment_pending",
		label: "Pagamento pendente"
	},
	{
		key: "payment_overdue",
		label: "Pagamento atrasado"
	},
	{
		key: "role_removed",
		label: "Cargo removido por inadimplência"
	},
	{
		key: "renewed",
		label: "Renovação confirmada"
	}
];
var isSnowflake = (v) => /^[0-9]{15,25}$/.test(v);
var errMsg = (e) => e?.message?.replace(/^Error:\s*/, "") ?? "Algo deu errado. Tente novamente.";
function StateBlock({ loading, error, empty, onRetry, children, emptyLabel = "Nada por aqui ainda." }) {
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: [
			0,
			1,
			2
		].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full" }, i))
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-6 text-destructive" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: errMsg(error)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: onRetry,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "mr-2 size-3.5" }), "Tentar novamente"]
			})
		]
	});
	if (empty) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2 rounded-lg border border-dashed p-8 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "size-6 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: emptyLabel
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function DiscordBotPanel() {
	const [tab, setTab] = (0, import_react.useState)("config");
	const qcRoot = useQueryClient();
	const statusFn = useServerFn(getBotStatus);
	const status = useQuery({
		queryKey: ["bot-status"],
		queryFn: () => statusFn({ data: void 0 }),
		retry: false
	});
	const testFn = useServerFn(testBotConnection);
	const test = useMutation({
		mutationFn: async () => {
			return await testFn({ data: void 0 });
		},
		onSuccess: (res) => {
			if (res.ok) toast.success(`Bot respondeu em ${res.latencyMs}ms.`);
			else toast.error(res.error ?? "Bot não respondeu.");
			qcRoot.invalidateQueries({ queryKey: ["bot-status"] });
			qcRoot.invalidateQueries({ queryKey: ["bot-logs"] });
		},
		onError: (e) => toast.error(errMsg(e))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 place-items-center rounded-lg bg-primary/15 ring-1 ring-primary/30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-5 text-primary" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Bot do Discord"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Integração owner-only. Token vive apenas no servidor."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						status.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 size-3 animate-spin" }), "verificando"]
						}) : status.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "destructive",
							children: "erro ao verificar"
						}) : status.data?.online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "bg-emerald-600 hover:bg-emerald-600",
							children: "online"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "destructive",
							title: status.data?.error ?? "",
							children: "offline"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: status.data?.secrets?.sharedSecret ? "outline" : "destructive",
							children: ["secret ", status.data?.secrets?.sharedSecret ? "ok" : "ausente"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							disabled: test.isPending,
							onClick: () => {
								if (!test.isPending) test.mutate();
							},
							children: test.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }), "Testando…"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugZap, { className: "mr-2 size-3.5" }), "Testar conexão"] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => status.refetch(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" })
						})
					]
				})]
			}),
			test.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border bg-surface p-3 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Testando conectividade com o bot…"]
			}) : test.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "mt-0.5 size-4 shrink-0 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-destructive",
					children: "Falha ao executar o teste"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: errMsg(test.error)
				})] })]
			}) : test.data ? test.data.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 size-4 shrink-0 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						"Conexão OK — bot respondeu em ",
						test.data.latencyMs,
						"ms"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted-foreground",
					children: [
						"Testado às ",
						new Date(test.data.checkedAt).toLocaleString("pt-BR"),
						" · registrado nos logs"
					]
				})] })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "mt-0.5 size-4 shrink-0 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-destructive",
						children: "Conexão falhou"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: test.data.error ?? "Motivo não informado pelo bot."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"Testado às ",
							new Date(test.data.checkedAt).toLocaleString("pt-BR"),
							" · registrado nos logs"
						]
					})
				] })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-dashed p-3 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugZap, { className: "size-4" }), "Nenhum teste de conexão executado ainda."]
			}),
			!status.isLoading && !status.isError && !status.data?.secrets?.apiUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Defina ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "DISCORD_BOT_API_URL" }),
					" e ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "DISCORD_BOT_SHARED_SECRET" }),
					" nas variáveis de ambiente do servidor (Discloud). O token do bot fica só no host do bot."
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 ring-1 ring-border sm:mx-0",
				children: [
					["config", "Configuração"],
					["membros", "Membros"],
					["logs", "Logs"]
				].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(k),
					className: `shrink-0 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${tab === k ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
					children: label
				}, k))
			}),
			tab === "config" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigTab, {}),
			tab === "membros" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MembersTab, {}),
			tab === "logs" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogsTab, {})
		]
	});
}
function ConfigTab() {
	const qc = useQueryClient();
	const saveSettings = useServerFn(saveBotSettings);
	const saveMap = useServerFn(saveRoleMap);
	const saveMsgs = useServerFn(saveBotMessages);
	const cfg = useQuery({
		queryKey: ["bot-config"],
		retry: false,
		queryFn: async () => {
			const [s, c, m, msg] = await Promise.all([
				supabase.from("discord_bot_settings").select("*").eq("id", true).maybeSingle(),
				supabase.from("cargos").select("id, name, color, weekly_amount").order("sort_order"),
				supabase.from("discord_role_map").select("cargo_id, discord_role_id"),
				supabase.from("discord_bot_messages").select("key, template")
			]);
			if (s.error) throw new Error(s.error.message);
			if (c.error) throw new Error(c.error.message);
			return {
				settings: s.data,
				cargos: c.data ?? [],
				map: m.data ?? [],
				messages: msg.data ?? []
			};
		}
	});
	const [form, setForm] = (0, import_react.useState)({
		guild_id: "",
		default_member_role_id: "",
		overdue_role_id: "",
		removal_after_days: 7,
		enabled: false
	});
	const [roleMap, setRoleMap] = (0, import_react.useState)({});
	const [messages, setMessages] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (!cfg.data) return;
		const s = cfg.data.settings;
		setForm({
			guild_id: s?.guild_id ?? "",
			default_member_role_id: s?.default_member_role_id ?? "",
			overdue_role_id: s?.overdue_role_id ?? "",
			removal_after_days: s?.removal_after_days ?? 7,
			enabled: Boolean(s?.enabled)
		});
		setRoleMap(Object.fromEntries(cfg.data.map.map((r) => [r.cargo_id, r.discord_role_id])));
		setMessages(Object.fromEntries(cfg.data.messages.map((r) => [r.key, r.template])));
	}, [cfg.data]);
	const settingsErrors = (0, import_react.useMemo)(() => {
		const e = {};
		for (const k of [
			"guild_id",
			"default_member_role_id",
			"overdue_role_id"
		]) {
			const v = form[k];
			if (v && !isSnowflake(v)) e[k] = "Use apenas números (15 a 25 dígitos).";
		}
		if (form.enabled && !form.guild_id) e.guild_id = "Informe o Guild ID para ativar o bot.";
		if (form.removal_after_days < 1 || form.removal_after_days > 90) e.removal_after_days = "Entre 1 e 90 dias.";
		return e;
	}, [form]);
	const mSettings = useMutation({
		mutationFn: () => saveSettings({ data: form }),
		onSuccess: () => {
			toast.success("Configurações salvas.");
			qc.invalidateQueries({ queryKey: ["bot-config"] });
		},
		onError: (e) => toast.error(errMsg(e))
	});
	const mMap = useMutation({
		mutationFn: () => saveMap({ data: { entries: Object.entries(roleMap).map(([cargo_id, discord_role_id]) => ({
			cargo_id,
			discord_role_id: discord_role_id ?? ""
		})) } }),
		onSuccess: (r) => {
			toast.success(`Mapeamento salvo (${r?.mapped ?? 0} cargo(s)).`);
			qc.invalidateQueries({ queryKey: ["bot-config"] });
		},
		onError: (e) => toast.error(errMsg(e))
	});
	const mMsgs = useMutation({
		mutationFn: () => saveMsgs({ data: { messages: MESSAGE_KEYS.map((m) => ({
			key: m.key,
			template: messages[m.key] ?? ""
		})) } }),
		onSuccess: () => {
			toast.success("Mensagens salvas.");
			qc.invalidateQueries({ queryKey: ["bot-config"] });
		},
		onError: (e) => toast.error(errMsg(e))
	});
	const invalidMap = Object.values(roleMap).some((v) => v && !isSnowflake(v));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateBlock, {
		loading: cfg.isLoading,
		error: cfg.error,
		empty: false,
		onRetry: () => cfg.refetch(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 rounded-lg border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Servidor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Guild ID (servidor)",
									error: settingsErrors.guild_id,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "numeric",
										placeholder: "123456789012345678",
										value: form.guild_id,
										onChange: (e) => setForm({
											...form,
											guild_id: e.target.value.trim()
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Cargo padrão de membro (ID)",
									error: settingsErrors.default_member_role_id,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "numeric",
										placeholder: "opcional",
										value: form.default_member_role_id,
										onChange: (e) => setForm({
											...form,
											default_member_role_id: e.target.value.trim()
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Cargo de inadimplente (ID)",
									error: settingsErrors.overdue_role_id,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "numeric",
										placeholder: "opcional",
										value: form.overdue_role_id,
										onChange: (e) => setForm({
											...form,
											overdue_role_id: e.target.value.trim()
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Remover cargos após (dias de atraso)",
									error: settingsErrors.removal_after_days,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 1,
										max: 90,
										value: form.removal_after_days,
										onChange: (e) => setForm({
											...form,
											removal_after_days: Number(e.target.value) || 0
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: form.enabled,
								onCheckedChange: (v) => setForm({
									...form,
									enabled: v
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Automação ativa (cargos e DMs automáticos)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: Object.keys(settingsErrors).length > 0 || mSettings.isPending,
							onClick: () => mSettings.mutate(),
							children: [mSettings.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 size-3.5" }), "Salvar configurações"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 rounded-lg border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Mapeamento de cargos"
					}), cfg.data?.cargos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground",
						children: "Nenhum cargo cadastrado no SaaS ainda."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [cfg.data?.cargos.map((c) => {
							const v = roleMap[c.id] ?? "";
							const bad = v && !isSnowflake(v);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-[1fr_1.2fr] sm:items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-2 rounded-full",
										style: { background: c.color || "#888" }
									}), c.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "numeric",
									placeholder: "ID do cargo no Discord (vazio = remover)",
									value: v,
									onChange: (e) => setRoleMap({
										...roleMap,
										[c.id]: e.target.value.trim()
									})
								}), bad && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-destructive",
									children: "Use apenas números (15 a 25 dígitos)."
								})] })]
							}, c.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: invalidMap || mMap.isPending,
							onClick: () => mMap.mutate(),
							children: [mMap.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 size-3.5" }), "Salvar mapeamento"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4 rounded-lg border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Mensagens automáticas (DM)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Variáveis: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "{nome}" }),
								", ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "{valor}" }),
								", ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "{vencimento}" }),
								". Menções em massa são bloqueadas automaticamente."
							]
						}),
						MESSAGE_KEYS.map((m) => {
							const v = messages[m.key] ?? "";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs",
										children: m.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										rows: 2,
										maxLength: 1800,
										value: v,
										onChange: (e) => setMessages({
											...messages,
											[m.key]: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-right text-[11px] text-muted-foreground",
										children: [v.length, "/1800"]
									})
								]
							}, m.key);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: mMsgs.isPending,
							onClick: () => mMsgs.mutate(),
							children: [mMsgs.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 size-3.5" }), "Salvar mensagens"]
						})
					]
				})
			]
		})
	});
}
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs",
				children: label
			}),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function MembersTab() {
	const [q, setQ] = (0, import_react.useState)("");
	const [dm, setDm] = (0, import_react.useState)(null);
	const [dmText, setDmText] = (0, import_react.useState)("");
	const [roleDlg, setRoleDlg] = (0, import_react.useState)(null);
	const [roleCargo, setRoleCargo] = (0, import_react.useState)("");
	const assignFn = useServerFn(assignDiscordRole);
	const removeFn = useServerFn(removeDiscordRole);
	const dmFn = useServerFn(sendDiscordDm);
	const syncFn = useServerFn(syncDiscordUser);
	const members = useQuery({
		queryKey: ["bot-members"],
		retry: false,
		queryFn: async () => {
			const [{ data: profs, error }, { data: cargos }, { data: pays }] = await Promise.all([
				supabase.from("profiles").select("id, first_name, last_name, email, discord_id, discord_username, cargo_id, form_status").order("created_at", { ascending: false }).limit(500),
				supabase.from("cargos").select("id, name"),
				supabase.from("payments").select("user_id, status, due_date").order("due_date", { ascending: false })
			]);
			if (error) throw new Error(error.message);
			const cargoName = new Map((cargos ?? []).map((c) => [c.id, c.name]));
			const lastPay = /* @__PURE__ */ new Map();
			for (const p of pays ?? []) if (!lastPay.has(p.user_id)) lastPay.set(p.user_id, p.status);
			return (profs ?? []).map((p) => ({
				...p,
				cargo_name: p.cargo_id ? cargoName.get(p.cargo_id) ?? "—" : "—",
				payment_status: lastPay.get(p.id) ?? null
			}));
		}
	});
	const cargos = useQuery({
		queryKey: ["bot-cargos"],
		queryFn: async () => {
			const { data, error } = await supabase.from("cargos").select("id, name").order("sort_order");
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const filtered = (0, import_react.useMemo)(() => {
		const term = q.trim().toLowerCase();
		const list = members.data ?? [];
		if (!term) return list;
		return list.filter((m) => [
			m.first_name,
			m.last_name,
			m.email,
			m.discord_username,
			m.discord_id
		].filter(Boolean).join(" ").toLowerCase().includes(term));
	}, [members.data, q]);
	const mRole = useMutation({
		mutationFn: async () => {
			if (!roleDlg || !roleCargo) throw new Error("Escolha um cargo.");
			return (roleDlg.mode === "assign" ? assignFn : removeFn)({ data: {
				user_id: roleDlg.id,
				cargo_id: roleCargo
			} });
		},
		onSuccess: () => {
			toast.success("Ação enviada ao bot.");
			setRoleDlg(null);
			setRoleCargo("");
		},
		onError: (e) => toast.error(errMsg(e))
	});
	const mDm = useMutation({
		mutationFn: async () => {
			if (!dm) throw new Error("Membro inválido.");
			const text = dmText.trim();
			if (!text) throw new Error("Escreva uma mensagem.");
			return dmFn({ data: {
				user_id: dm.id,
				message: text
			} });
		},
		onSuccess: () => {
			toast.success("DM enviada.");
			setDm(null);
			setDmText("");
		},
		onError: (e) => toast.error(errMsg(e))
	});
	const mSync = useMutation({
		mutationFn: (id) => syncFn({ data: { user_id: id } }),
		onSuccess: () => toast.success("Sincronização solicitada."),
		onError: (e) => toast.error(errMsg(e))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-9",
					placeholder: "Buscar por nome, email ou Discord…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateBlock, {
				loading: members.isLoading,
				error: members.error,
				empty: filtered.length === 0,
				emptyLabel: q ? "Nenhum membro encontrado para essa busca." : "Nenhum membro cadastrado ainda.",
				onRetry: () => members.refetch(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-lg border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[820px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-surface text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Membro"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Discord"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Cargo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Formulário"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Pagamento"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-right",
									children: "Ações"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((m) => {
							const name = [m.first_name, m.last_name].filter(Boolean).join(" ") || m.email;
							const linked = Boolean(m.discord_id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium",
											children: name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: m.email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-xs",
										children: linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: m.discord_username ?? "—" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground",
											children: m.discord_id
										})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: "não vinculado"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: m.cargo_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: m.form_status
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: m.payment_status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: m.payment_status
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "—"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap justify-end gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "outline",
													disabled: !linked,
													onClick: () => {
														setRoleDlg({
															id: m.id,
															name,
															mode: "assign"
														});
														setRoleCargo(m.cargo_id ?? "");
													},
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "outline",
													disabled: !linked,
													onClick: () => {
														setRoleDlg({
															id: m.id,
															name,
															mode: "remove"
														});
														setRoleCargo(m.cargo_id ?? "");
													},
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldX, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "outline",
													disabled: !linked,
													onClick: () => {
														setDm({
															id: m.id,
															name
														});
														setDmText("");
													},
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "outline",
													disabled: !linked || mSync.isPending,
													onClick: () => mSync.mutate(m.id),
													children: mSync.isPending && mSync.variables === m.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" })
												})
											]
										})
									})
								]
							}, m.id);
						}) })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!roleDlg,
				onOpenChange: (o) => !o && setRoleDlg(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-[92vw] sm:max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: roleDlg?.mode === "assign" ? "Atribuir cargo" : "Remover cargo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: roleDlg?.name })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: roleCargo,
							onValueChange: setRoleCargo,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Escolha o cargo do SaaS" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (cargos.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c.id,
								children: c.name
							}, c.id)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setRoleDlg(null),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							disabled: !roleCargo || mRole.isPending,
							onClick: () => mRole.mutate(),
							children: [mRole.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }), "Confirmar"]
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!dm,
				onOpenChange: (o) => !o && setDm(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-[92vw] sm:max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Enviar DM" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: dm?.name })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 5,
							maxLength: 1800,
							value: dmText,
							onChange: (e) => setDmText(e.target.value),
							placeholder: "Mensagem…"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-right text-[11px] text-muted-foreground",
							children: [dmText.length, "/1800"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setDm(null),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							disabled: !dmText.trim() || mDm.isPending,
							onClick: () => mDm.mutate(),
							children: [mDm.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 size-3.5 animate-spin" }), "Enviar"]
						})] })
					]
				})
			})
		]
	});
}
function LogsTab() {
	const [action, setAction] = (0, import_react.useState)("all");
	const logs = useQuery({
		queryKey: ["bot-logs"],
		retry: false,
		queryFn: async () => {
			const { data, error } = await supabase.from("bot_activity_logs").select("*").order("created_at", { ascending: false }).limit(200);
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const actions = (0, import_react.useMemo)(() => Array.from(new Set((logs.data ?? []).map((l) => l.action))), [logs.data]);
	const rows = (0, import_react.useMemo)(() => (logs.data ?? []).filter((l) => action === "all" || l.action === action), [logs.data, action]);
	function exportCsv() {
		try {
			const head = "data,acao,status,discord_id,detalhe\n";
			const body = rows.map((l) => [
				new Date(l.created_at).toISOString(),
				l.action,
				l.status,
				l.discord_id ?? "",
				JSON.stringify(l.detail ?? {}).replace(/"/g, "'")
			].map((v) => `"${String(v)}"`).join(",")).join("\n");
			const url = URL.createObjectURL(new Blob([head + body], { type: "text/csv;charset=utf-8" }));
			const a = document.createElement("a");
			a.href = url;
			a.download = "bot_activity_logs.csv";
			a.click();
			URL.revokeObjectURL(url);
			toast.success("CSV exportado.");
		} catch (e) {
			toast.error(errMsg(e));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: action,
					onValueChange: setAction,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-56",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "all",
						children: "Todas as ações"
					}), actions.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: a,
						children: a
					}, a))] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => logs.refetch(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "mr-2 size-3.5" }), "Atualizar"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					disabled: rows.length === 0,
					onClick: exportCsv,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "mr-2 size-3.5" }), "CSV"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateBlock, {
			loading: logs.isLoading,
			error: logs.error,
			empty: rows.length === 0,
			emptyLabel: "Nenhuma atividade registrada ainda.",
			onRetry: () => logs.refetch(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: rows.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3 rounded-lg border bg-surface p-3",
					children: [
						l.status === "success" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 size-4 shrink-0 text-emerald-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "mt-0.5 size-4 shrink-0 text-destructive" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: l.action
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: [l.discord_id ? `Discord ${l.discord_id} · ` : "", l.detail?.error ?? l.detail?.preview ?? "—"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-[11px] text-muted-foreground",
							children: new Date(l.created_at).toLocaleString("pt-BR")
						})
					]
				}, l.id))
			})
		})]
	});
}
//#endregion
export { DiscordBotPanel as component };
