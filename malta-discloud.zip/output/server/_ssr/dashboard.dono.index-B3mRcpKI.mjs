import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as FileCheck, D as Receipt, H as LoaderCircle, r as Users, w as Save } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useSiteSettings } from "./useSiteSettings-Do6dVqgS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.index-B3mRcpKI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OwnerConfig() {
	const qc = useQueryClient();
	const settingsQ = useSiteSettings();
	const metricsQ = useQuery({
		queryKey: ["admin-metrics"],
		queryFn: async () => {
			const { count: users } = await supabase.from("profiles").select("*", {
				count: "exact",
				head: true
			}).eq("status", "approved");
			const { count: pendingForms } = await supabase.from("recruitment_forms").select("*", {
				count: "exact",
				head: true
			}).eq("status", "submitted");
			const { data: payments } = await supabase.from("payments").select("amount, status").eq("status", "approved");
			const totalRevenue = payments?.reduce((acc, p) => acc + (p.amount || 0), 0) ?? 0;
			return {
				users: users ?? 0,
				pendingForms: pendingForms ?? 0,
				totalRevenue
			};
		}
	});
	const [form, setForm] = (0, import_react.useState)({
		org_name: "",
		pix_key: "",
		pix_key_type: "cpf",
		pix_beneficiary: "",
		weekly_amount: "0",
		payment_due_day: "7",
		discord_webhook_url: ""
	});
	(0, import_react.useEffect)(() => {
		if (settingsQ.data) setForm({
			org_name: settingsQ.data.org_name ?? "",
			pix_key: settingsQ.data.pix_key ?? "",
			pix_key_type: settingsQ.data.pix_key_type ?? "cpf",
			pix_beneficiary: settingsQ.data.pix_beneficiary ?? "",
			weekly_amount: String(settingsQ.data.weekly_amount ?? 0),
			payment_due_day: String(settingsQ.data.payment_due_day ?? 7),
			discord_webhook_url: settingsQ.data.discord_webhook_url ?? ""
		});
	}, [settingsQ.data]);
	const saveMut = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("site_settings").update({
				org_name: form.org_name,
				pix_key: form.pix_key || null,
				pix_key_type: form.pix_key_type || null,
				pix_beneficiary: form.pix_beneficiary || null,
				weekly_amount: Number(form.weekly_amount || 0),
				payment_due_day: Number(form.payment_due_day || 7),
				discord_webhook_url: form.discord_webhook_url || null
			}).eq("id", 1);
			if (error) throw error;
			const { data: u } = await supabase.auth.getUser();
			await supabase.from("audit_log").insert({
				actor_id: u.user.id,
				action: "settings.update",
				entity: "site_settings",
				entity_id: "1"
			});
		},
		onSuccess: () => {
			toast.success("Configurações salvas.");
			qc.invalidateQueries({ queryKey: ["site_settings"] });
		},
		onError: (e) => toast.error(e.message)
	});
	if (settingsQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-4 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
					label: "Membros Ativos",
					value: metricsQ.data?.users ?? 0,
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-primary" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
					label: "Formulários Pendentes",
					value: metricsQ.data?.pendingForms ?? 0,
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-5 text-amber-500" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
					label: "Receita Total (Aprovada)",
					value: new Intl.NumberFormat("pt-BR", {
						style: "currency",
						currency: "BRL"
					}).format(metricsQ.data?.totalRevenue ?? 0),
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-5 text-green-500" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Identidade"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nome da organização",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: form.org_name,
							onChange: (e) => setForm({
								...form,
								org_name: e.target.value
							}),
							className: "input"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "PIX padrão do semanal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Tipo de chave",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: form.pix_key_type,
									onChange: (e) => setForm({
										...form,
										pix_key_type: e.target.value
									}),
									className: "input",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "cpf",
											children: "CPF"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "cnpj",
											children: "CNPJ"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "email",
											children: "E-mail"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "phone",
											children: "Telefone"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "random",
											children: "Aleatória"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Beneficiário",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: form.pix_beneficiary,
									onChange: (e) => setForm({
										...form,
										pix_beneficiary: e.target.value
									}),
									className: "input"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Chave PIX",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.pix_key,
										onChange: (e) => setForm({
											...form,
											pix_key: e.target.value
										}),
										className: "input font-mono"
									})
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "Financeiro"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Valor semanal (R$)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								step: "0.01",
								value: form.weekly_amount,
								onChange: (e) => setForm({
									...form,
									weekly_amount: e.target.value
								}),
								className: "input"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Dia de vencimento (1-28)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								max: 28,
								value: form.payment_due_day,
								onChange: (e) => setForm({
									...form,
									payment_due_day: e.target.value
								}),
								className: "input"
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-medium",
							children: "Integrações"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Webhook do Discord (opcional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								placeholder: "https://discord.com/api/webhooks/...",
								value: form.discord_webhook_url,
								onChange: (e) => setForm({
									...form,
									discord_webhook_url: e.target.value
								}),
								className: "input"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Anúncios podem ser espelhados no seu canal Discord (fase futura)."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-2 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => saveMut.mutate(),
						disabled: saveMut.isPending,
						className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
						children: [saveMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Salvar tudo"]
					})
				})
			]
		})]
	});
}
function MetricCard({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface p-4 ring-1 ring-border flex items-center gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-full bg-background p-2.5 ring-1 ring-border",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xl font-bold",
			children: value
		})] })]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		}), children]
	});
}
//#endregion
export { OwnerConfig as component };
