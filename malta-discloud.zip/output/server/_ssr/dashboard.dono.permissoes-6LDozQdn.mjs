import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, S as Search, _ as ShieldCheck, g as ShieldOff } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.permissoes-6LDozQdn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OwnerPermissoes() {
	const qc = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const membersQ = useQuery({
		queryKey: ["all-profiles-and-roles"],
		queryFn: async () => {
			const { data: profs } = await supabase.from("profiles").select("id, first_name, last_name, email");
			const { data: roles } = await supabase.from("user_roles").select("user_id, role");
			const byUser = /* @__PURE__ */ new Map();
			(roles ?? []).forEach((r) => {
				byUser.set(r.user_id, [...byUser.get(r.user_id) ?? [], r.role]);
			});
			return (profs ?? []).map((p) => ({
				...p,
				roles: byUser.get(p.id) ?? []
			}));
		}
	});
	const toggleAdmin = useMutation({
		mutationFn: async (args) => {
			if (args.add) {
				const { error } = await supabase.from("user_roles").insert({
					user_id: args.user_id,
					role: "admin"
				});
				if (error && error.code !== "23505") throw error;
			} else {
				const { error } = await supabase.from("user_roles").delete().eq("user_id", args.user_id).eq("role", "admin");
				if (error) throw error;
			}
			const { data: u } = await supabase.auth.getUser();
			await supabase.from("audit_log").insert({
				actor_id: u.user.id,
				action: args.add ? "role.grant" : "role.revoke",
				entity: "user_roles",
				entity_id: args.user_id,
				metadata: { role: "admin" }
			});
		},
		onSuccess: () => {
			toast.success("Permissão atualizada.");
			qc.invalidateQueries({ queryKey: ["all-profiles-and-roles"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const list = (membersQ.data ?? []).filter((m) => {
		if (!q) return true;
		const t = q.toLowerCase();
		return `${m.first_name ?? ""} ${m.last_name ?? ""} ${m.email}`.toLowerCase().includes(t);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-primary/5 p-4 text-sm text-muted-foreground ring-1 ring-primary/20",
				children: [
					"Apenas o ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-primary",
						children: "Dono"
					}),
					" pode promover ou remover administradores."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar membro",
					className: "input pl-9"
				})]
			}),
			membersQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-lg bg-surface ring-1 ring-border",
				children: [list.map((m) => {
					const isAdmin = m.roles.includes("admin");
					const isOwner = m.roles.includes("owner");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium",
							children: [
								m.first_name,
								" ",
								m.last_name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: m.email
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-primary/15 px-2 py-0.5 text-xs text-primary ring-1 ring-primary/30",
									children: "Dono"
								}),
								isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary ring-1 ring-primary/30",
									children: "Admin"
								}),
								!isOwner && (isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => toggleAdmin.mutate({
										user_id: m.id,
										add: false
									}),
									className: "inline-flex items-center gap-1 rounded-md bg-destructive/10 px-2.5 py-1.5 text-xs font-medium text-destructive ring-1 ring-destructive/30 hover:bg-destructive/20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, { className: "size-3.5" }), " Remover admin"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => toggleAdmin.mutate({
										user_id: m.id,
										add: true
									}),
									className: "inline-flex items-center gap-1 rounded-md bg-primary/10 px-2.5 py-1.5 text-xs font-medium text-primary ring-1 ring-primary/30 hover:bg-primary/20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" }), " Promover a admin"]
								}))
							]
						})]
					}, m.id);
				}), list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "p-4 text-sm text-muted-foreground",
					children: "Nenhum membro."
				})]
			})
		]
	});
}
//#endregion
export { OwnerPermissoes as component };
