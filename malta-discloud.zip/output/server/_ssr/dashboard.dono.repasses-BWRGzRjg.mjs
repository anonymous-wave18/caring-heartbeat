import { t as supabase } from "./client-D8gVtBRg.mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { H as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as formatBRL } from "./useSiteSettings-Do6dVqgS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.dono.repasses-BWRGzRjg.js
var import_jsx_runtime = require_jsx_runtime();
function RecrutadoresPage() {
	const q = useQuery({
		queryKey: ["recruiters-overview"],
		queryFn: async () => {
			const { data: members, error } = await supabase.from("profiles").select("id,first_name,last_name,email,status,recruited_by");
			if (error) throw error;
			const rows = members ?? [];
			const { data: payments } = await supabase.from("payments").select("user_id,amount,status,recruiter_admin_id");
			const byId = new Map(rows.map((m) => [m.id, m]));
			return Array.from(new Set(rows.map((m) => m.recruited_by).filter(Boolean))).map((rid) => {
				const rec = byId.get(rid);
				const recruited = rows.filter((m) => m.recruited_by === rid);
				const pays = (payments ?? []).filter((p) => p.recruiter_admin_id === rid || byId.get(p.user_id)?.recruited_by === rid);
				const paid = pays.filter((p) => p.status === "approved");
				const open = pays.filter((p) => p.status !== "approved");
				return {
					id: rid,
					name: rec ? `${rec.first_name ?? ""} ${rec.last_name ?? ""}`.trim() || rec.email : "—",
					email: rec?.email ?? "",
					total: recruited.length,
					approved: recruited.filter((m) => m.status === "approved").length,
					received: paid.reduce((s, p) => s + Number(p.amount ?? 0), 0),
					openCount: open.length,
					openAmount: open.reduce((s, p) => s + Number(p.amount ?? 0), 0)
				};
			}).sort((a, b) => b.total - a.total);
		}
	});
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	const data = q.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium",
			children: "Recrutadores"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Todos os membros pagam no PIX oficial do Dono. Aqui você acompanha quantos membros cada recrutador aprovou e quanto eles geraram."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg bg-surface ring-1 ring-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[720px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-surface-muted text-xs uppercase text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 text-left",
							children: "Recrutador"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 text-left",
							children: "Recrutados"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 text-left",
							children: "Aprovados"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 text-left",
							children: "Recebido"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 text-left",
							children: "Em aberto"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y divide-border",
					children: [data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "hover:bg-surface-muted/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2.5",
								children: [r.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: r.email
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5",
								children: r.total
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5",
								children: r.approved
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5 text-success",
								children: formatBRL(r.received)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2.5 text-warning",
								children: [formatBRL(r.openAmount), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-1 text-xs text-muted-foreground",
									children: [
										"(",
										r.openCount,
										")"
									]
								})]
							})
						]
					}, r.id)), data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-4 py-8 text-center text-muted-foreground",
						children: "Nenhum recrutador com membros ainda."
					}) })]
				})]
			})
		})]
	});
}
//#endregion
export { RecrutadoresPage as component };
