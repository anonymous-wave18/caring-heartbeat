import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, Q as FileText, c as Upload, ct as Clock, d as Trash2, ft as CircleCheck, ut as CircleX, z as MapPin } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as useFormConfig } from "./formConfig-6DIhtxEt.mjs";
import { n as maskDate, r as maskPhone, t as maskCPF } from "./masks-CicbQFDC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.formulario-WHj0C7Q_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FormularioPage() {
	const qc = useQueryClient();
	const cfg = useFormConfig().data;
	const userId = useQuery({
		queryKey: ["auth-user"],
		queryFn: async () => (await supabase.auth.getUser()).data.user
	}).data?.id;
	const cargosQ = useQuery({
		queryKey: ["cargos"],
		queryFn: async () => {
			const { data } = await supabase.from("cargos").select("id, name, slug, description").order("sort_order").order("name");
			return data ?? [];
		}
	});
	const formQ = useQuery({
		queryKey: ["my-form", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data } = await supabase.from("recruitment_forms").select("*").eq("user_id", userId).maybeSingle();
			return data;
		}
	});
	const docsQ = useQuery({
		queryKey: ["my-docs", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data } = await supabase.from("recruitment_documents").select("*").eq("user_id", userId).order("created_at");
			return data ?? [];
		}
	});
	const [form, setForm] = (0, import_react.useState)({
		cargo_desejado_id: "",
		full_name: "",
		birth_date: "",
		cpf: "",
		bank_name: "",
		bank_holder: "",
		discord_contact: "",
		discord_avatar_url: "",
		phone_self: "",
		phone_father: "",
		phone_mother: "",
		availability: "",
		experience: "",
		motivation: "",
		referred_by: "",
		location_lat: "",
		location_lng: "",
		location_captured_at: "",
		address_proof: ""
	});
	const [answers, setAnswers] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (formQ.data) {
			const d = formQ.data;
			setForm({
				cargo_desejado_id: d.cargo_desejado_id ?? "",
				full_name: d.full_name ?? "",
				birth_date: d.birth_date ?? "",
				cpf: d.cpf ?? "",
				bank_name: d.bank_name ?? "",
				bank_holder: d.bank_holder ?? "",
				discord_contact: d.discord_contact ?? "",
				discord_avatar_url: d.discord_avatar_url ?? "",
				phone_self: d.phone_self ?? "",
				phone_father: d.phone_father ?? "",
				phone_mother: d.phone_mother ?? "",
				availability: d.availability ?? "",
				experience: d.experience ?? "",
				motivation: d.motivation ?? "",
				referred_by: d.referred_by ?? "",
				location_lat: d.location_lat ?? "",
				location_lng: d.location_lng ?? "",
				location_captured_at: d.location_captured_at ?? "",
				address_proof: d.address_proof ?? ""
			});
			setAnswers(d.custom_answers ?? {});
		}
	}, [formQ.data]);
	const readOnly = formQ.data?.status === "submitted" || formQ.data?.status === "approved";
	const saveMut = useMutation({
		mutationFn: async (submit) => {
			if (!userId) throw new Error("no user");
			const F = cfg?.fields;
			if (submit) {
				for (const k of [
					"cargo_desejado_id",
					"full_name",
					"birth_date",
					"cpf",
					"bank_name",
					"bank_holder",
					"discord_contact",
					"discord_avatar_url",
					"phone_self",
					"phone_father",
					"phone_mother",
					"availability",
					"experience",
					"motivation",
					"referred_by"
				]) {
					const fc = F?.[k];
					if (fc?.hidden || !fc?.required) continue;
					if (!form[k]) throw new Error(`Preencha: ${fc.label}`);
				}
				if (F?.location && !F.location.hidden && F.location.required && !form.location_captured_at) throw new Error("Capture sua localização em tempo real.");
				const docs = docsQ.data ?? [];
				const missing = (cfg?.docs ?? []).filter((k) => k.required).filter((k) => !docs.some((d) => d.kind === k.key));
				if (missing.length) throw new Error(`Envie: ${missing.map((m) => m.label).join(", ")}`);
				for (const q of cfg?.customQuestions ?? []) {
					if (q.hidden || !q.required) continue;
					if (!answers[q.id]?.toString().trim()) throw new Error(`Responda: ${q.label}`);
				}
			}
			const payload = {
				user_id: userId,
				cargo_desejado_id: form.cargo_desejado_id || null,
				full_name: form.full_name || null,
				birth_date: form.birth_date || null,
				cpf: form.cpf || null,
				bank_name: form.bank_name || null,
				bank_holder: form.bank_holder || null,
				discord_contact: form.discord_contact || null,
				discord_avatar_url: form.discord_avatar_url || null,
				phone_self: form.phone_self || null,
				phone_father: form.phone_father || null,
				phone_mother: form.phone_mother || null,
				availability: form.availability || null,
				experience: form.experience || null,
				motivation: form.motivation || null,
				referred_by: form.referred_by || null,
				location_lat: form.location_lat === "" ? null : Number(form.location_lat),
				location_lng: form.location_lng === "" ? null : Number(form.location_lng),
				location_captured_at: form.location_captured_at || null,
				address_proof: form.address_proof || null,
				custom_answers: answers,
				status: submit ? "submitted" : "not_submitted",
				submitted_at: submit ? (/* @__PURE__ */ new Date()).toISOString() : null
			};
			const { error } = await supabase.from("recruitment_forms").upsert(payload, { onConflict: "user_id" });
			if (error) throw error;
		},
		onSuccess: (_d, submit) => {
			toast.success(submit ? "Formulário enviado para análise!" : "Rascunho salvo.");
			qc.invalidateQueries({ queryKey: ["my-form"] });
			qc.invalidateQueries({ queryKey: ["me-profile"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const uploadMut = useMutation({
		mutationFn: async ({ file, kind }) => {
			if (!userId) throw new Error("no user");
			const path = `${userId}/${kind}-${Date.now()}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
			const { error: upErr } = await supabase.storage.from("documents").upload(path, file, { upsert: false });
			if (upErr) throw upErr;
			const { error } = await supabase.from("recruitment_documents").insert({
				user_id: userId,
				form_id: formQ.data?.id ?? null,
				file_path: path,
				file_name: file.name,
				mime_type: file.type,
				size_bytes: file.size,
				kind
			});
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Documento enviado.");
			qc.invalidateQueries({ queryKey: ["my-docs"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const delDocMut = useMutation({
		mutationFn: async (doc) => {
			await supabase.storage.from("documents").remove([doc.file_path]);
			const { error } = await supabase.from("recruitment_documents").delete().eq("id", doc.id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Removido.");
			qc.invalidateQueries({ queryKey: ["my-docs"] });
		}
	});
	function captureLocation() {
		if (!navigator.geolocation) return toast.error("Geolocalização não suportada.");
		toast.loading("Capturando localização...", { id: "geo" });
		navigator.geolocation.getCurrentPosition((pos) => {
			setForm((f) => ({
				...f,
				location_lat: pos.coords.latitude,
				location_lng: pos.coords.longitude,
				location_captured_at: (/* @__PURE__ */ new Date()).toISOString()
			}));
			toast.success("Localização capturada.", { id: "geo" });
		}, (err) => toast.error(err.message, { id: "geo" }), {
			enableHighAccuracy: true,
			timeout: 15e3
		});
	}
	if (formQ.isLoading || !cfg) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	const F = cfg.fields;
	const show = (k) => !F[k]?.hidden;
	const req = (k) => F[k]?.required;
	const lbl = (k) => F[k]?.label ?? k;
	const status = formQ.data?.status ?? "not_submitted";
	const cargoNome = cargosQ.data?.find((c) => c.id === form.cargo_desejado_id)?.name ?? "(CARGO ADQUIRIDO)";
	const videoText = `Eu, ${form.full_name || "(nome completo)"}, do CPF ${form.cpf || "(número)"}, sou o novo ${cargoNome} da MALTA e concordo que qualquer tentativa de golpe estarei submetido a medidas externas, tais como boletim de ocorrência.`;
	const StatusBanner = () => {
		if (status === "approved") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }),
			tone: "ok",
			children: "Formulário aprovado. Você já tem acesso completo."
		});
		if (status === "submitted") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" }),
			tone: "warn",
			children: "Aguardando análise da administração."
		});
		if (status === "rejected") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-5" }),
			tone: "err",
			children: ["Formulário recusado. Ajuste os dados e reenvie.", formQ.data?.review_notes ? ` Motivo: ${formQ.data.review_notes}` : ""]
		});
		return null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium tracking-tight",
				children: cfg.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: cfg.subtitle
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {}),
			show("cargo_desejado_id") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "📌 Vaga desejada"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: lbl("cargo_desejado_id"),
					required: req("cargo_desejado_id"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						disabled: readOnly,
						className: "input",
						value: form.cargo_desejado_id,
						onChange: (e) => setForm({
							...form,
							cargo_desejado_id: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Selecione…"
						}), (cargosQ.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "👤 Dados pessoais"
					}),
					show("full_name") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: lbl("full_name"),
						required: req("full_name"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							disabled: readOnly,
							className: "input",
							value: form.full_name,
							onChange: (e) => setForm({
								...form,
								full_name: e.target.value.toUpperCase()
							}),
							placeholder: "NOME COMPLETO",
							onKeyDown: (e) => e.stopPropagation()
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							show("birth_date") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("birth_date"),
								required: req("birth_date"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.birth_date,
									onChange: (e) => setForm({
										...form,
										birth_date: maskDate(e.target.value)
									}),
									placeholder: "DD/MM/AAAA",
									inputMode: "numeric",
									maxLength: 10
								})
							}),
							show("cpf") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("cpf"),
								required: req("cpf"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.cpf,
									onChange: (e) => setForm({
										...form,
										cpf: maskCPF(e.target.value)
									}),
									placeholder: "000.000.000-00",
									inputMode: "numeric",
									maxLength: 14
								})
							}),
							show("bank_name") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("bank_name"),
								required: req("bank_name"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.bank_name,
									onChange: (e) => setForm({
										...form,
										bank_name: e.target.value
									})
								})
							}),
							show("bank_holder") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("bank_holder"),
								required: req("bank_holder"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.bank_holder,
									onChange: (e) => setForm({
										...form,
										bank_holder: e.target.value
									})
								})
							}),
							show("discord_contact") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("discord_contact"),
								required: req("discord_contact"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.discord_contact,
									onChange: (e) => setForm({
										...form,
										discord_contact: e.target.value
									})
								})
							}),
							show("discord_avatar_url") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: lbl("discord_avatar_url"),
								required: req("discord_avatar_url"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									disabled: readOnly,
									className: "input",
									value: form.discord_avatar_url,
									onChange: (e) => setForm({
										...form,
										discord_avatar_url: e.target.value
									}),
									placeholder: "https://…"
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "📞 Contato"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-3",
					children: [
						show("phone_self") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: lbl("phone_self"),
							required: req("phone_self"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								disabled: readOnly,
								className: "input",
								value: form.phone_self,
								onChange: (e) => setForm({
									...form,
									phone_self: maskPhone(e.target.value)
								}),
								placeholder: "(00) 00000-0000",
								inputMode: "tel",
								maxLength: 15
							})
						}),
						show("phone_father") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: lbl("phone_father"),
							required: req("phone_father"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								disabled: readOnly,
								className: "input",
								value: form.phone_father,
								onChange: (e) => setForm({
									...form,
									phone_father: maskPhone(e.target.value)
								}),
								placeholder: "(00) 00000-0000",
								inputMode: "tel",
								maxLength: 15
							})
						}),
						show("phone_mother") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: lbl("phone_mother"),
							required: req("phone_mother"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								disabled: readOnly,
								className: "input",
								value: form.phone_mother,
								onChange: (e) => setForm({
									...form,
									phone_mother: maskPhone(e.target.value)
								}),
								placeholder: "(00) 00000-0000",
								inputMode: "tel",
								maxLength: 15
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "📎 Documentos e verificações"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Envie cada arquivo no campo correspondente. Arquivos ficam privados, apenas o admin e o dono conseguem visualizar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-background/50 p-3 ring-1 ring-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Texto obrigatório para o vídeo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 text-sm italic",
							children: [
								"“",
								videoText,
								"”"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: cfg.docs.map((k) => {
							const existing = (docsQ.data ?? []).filter((d) => d.kind === k.key);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md bg-background/50 p-3 ring-1 ring-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-medium",
										children: [
											k.label,
											" ",
											k.required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-destructive",
												children: "*"
											})
										]
									}), k.hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: k.hint
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "inline-flex items-center gap-2 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90 cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }),
											" enviar",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: k.accept,
												className: "hidden",
												disabled: readOnly || uploadMut.isPending,
												onChange: (e) => {
													const f = e.target.files?.[0];
													if (f) uploadMut.mutate({
														file: f,
														kind: k.key
													});
													e.currentTarget.value = "";
												}
											})
										]
									})]
								}), existing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 divide-y divide-border",
									children: existing.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between py-1.5 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 text-muted-foreground" }), d.file_name]
										}), !readOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => delDocMut.mutate({
												id: d.id,
												file_path: d.file_path
											}),
											className: "text-muted-foreground hover:text-destructive",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
										})]
									}, d.id))
								})]
							}, k.key);
						})
					})
				]
			}),
			show("location") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-medium",
						children: [
							"📍 ",
							lbl("location"),
							req("location") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: " *"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Capturamos apenas as coordenadas no momento em que você clica. Autorize o navegador quando pedir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: readOnly,
							onClick: captureLocation,
							className: "inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Capturar localização atual"]
						}), form.location_captured_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							target: "_blank",
							rel: "noreferrer",
							href: `https://www.google.com/maps?q=${form.location_lat},${form.location_lng}`,
							className: "text-sm text-primary hover:underline",
							children: [
								Number(form.location_lat).toFixed(5),
								", ",
								Number(form.location_lng).toFixed(5),
								" — abrir no mapa"
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: "💬 Informações adicionais"
					}),
					show("availability") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: lbl("availability"),
						required: req("availability"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							disabled: readOnly,
							rows: 2,
							value: form.availability,
							onChange: (e) => setForm({
								...form,
								availability: e.target.value
							}),
							className: "input"
						})
					}),
					show("experience") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: lbl("experience"),
						required: req("experience"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							disabled: readOnly,
							rows: 3,
							value: form.experience,
							onChange: (e) => setForm({
								...form,
								experience: e.target.value
							}),
							className: "input"
						})
					}),
					show("motivation") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: lbl("motivation"),
						required: req("motivation"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							disabled: readOnly,
							rows: 3,
							value: form.motivation,
							onChange: (e) => setForm({
								...form,
								motivation: e.target.value
							}),
							className: "input"
						})
					}),
					show("referred_by") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: lbl("referred_by"),
						required: req("referred_by"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							disabled: readOnly,
							value: form.referred_by,
							onChange: (e) => setForm({
								...form,
								referred_by: e.target.value
							}),
							className: "input"
						})
					})
				]
			}),
			cfg.customQuestions.filter((q) => !q.hidden).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-medium",
					children: "➕ Perguntas adicionais"
				}), cfg.customQuestions.filter((q) => !q.hidden).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: q.label,
					required: q.required,
					children: q.type === "textarea" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						disabled: readOnly,
						rows: 3,
						className: "input",
						value: answers[q.id] ?? "",
						onChange: (e) => setAnswers({
							...answers,
							[q.id]: e.target.value
						})
					}) : q.type === "select" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						disabled: readOnly,
						className: "input",
						value: answers[q.id] ?? "",
						onChange: (e) => setAnswers({
							...answers,
							[q.id]: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Selecione…"
						}), (q.options ?? []).map((op) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: op,
							children: op
						}, op))]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: q.type === "number" ? "number" : "text",
						disabled: readOnly,
						className: "input",
						value: answers[q.id] ?? "",
						onChange: (e) => setAnswers({
							...answers,
							[q.id]: e.target.value
						})
					})
				}, q.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-destructive/10 p-4 text-sm text-destructive ring-1 ring-destructive/30",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold",
					children: "⚠️ ATENÇÃO"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 whitespace-pre-wrap",
					children: cfg.warning
				})]
			}),
			!readOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => saveMut.mutate(false),
					disabled: saveMut.isPending,
					className: "rounded-md bg-surface px-4 py-2 text-sm font-medium ring-1 ring-border hover:bg-surface-muted",
					children: "Salvar rascunho"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => saveMut.mutate(true),
					disabled: saveMut.isPending,
					className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:bg-primary/90",
					children: "Enviar para análise"
				})]
			})
		]
	});
}
function Field({ label, children, required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-sm font-medium text-foreground",
			children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-destructive",
				children: " *"
			})]
		}), children]
	});
}
function Banner({ children, icon, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-start gap-2 rounded-lg px-4 py-3 text-sm ring-1 ${tone === "ok" ? "bg-green-500/10 text-green-500 ring-green-500/30" : tone === "warn" ? "bg-amber-500/10 text-amber-500 ring-amber-500/30" : "bg-destructive/10 text-destructive ring-destructive/30"}`,
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children })]
	});
}
//#endregion
export { FormularioPage as component };
