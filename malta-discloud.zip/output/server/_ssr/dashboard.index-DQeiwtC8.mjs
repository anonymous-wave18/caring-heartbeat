import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as malta_fox_default } from "./malta-fox-DqjZc_D7.mjs";
import { Ct as ArrowRight, P as MessageSquare, Q as FileText, R as Megaphone, _ as ShieldCheck, ct as Clock, ft as CircleCheck, ot as CreditCard, ut as CircleX } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useRoles, t as computeRoleFlags } from "./useRoles-Cu15KWfN.mjs";
import { n as useSiteSettings, t as formatBRL } from "./useSiteSettings-Do6dVqgS.mjs";
import { t as Route } from "./dashboard.index-DwX1G7hP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.index-DQeiwtC8.js
var import_jsx_runtime = require_jsx_runtime();
function DashboardHome() {
	const { user } = Route.useRouteContext();
	const profileQuery = useQuery({
		queryKey: ["profile", user.id],
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).single();
			if (error) throw error;
			return data;
		}
	});
	const { isStaff } = computeRoleFlags(useRoles(user.id).data);
	const profile = profileQuery.data;
	if (!profile) return null;
	if (profile.status === "rejected") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RejectedState, {});
	const formApproved = profile.form_status === "approved";
	if (!isStaff && !formApproved) {
		if (profile.form_status === "submitted") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingState, {});
		if (profile.form_status === "rejected") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RejectedState, {});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedsFormState, { firstName: profile.first_name });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApprovedHome, {
		profile,
		isStaff,
		userId: user.id
	});
}
function NeedsFormState({ firstName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-medium tracking-tight",
				children: [
					"Olá",
					firstName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: firstName
					})] }) : null,
					"."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Complete seu cadastro para liberar o acesso completo."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: Clock,
						label: "Status",
						value: "Aguardando formulário"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: FileText,
						label: "Formulário",
						value: "Não enviado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: CreditCard,
						label: "Pagamento semanal",
						value: "Bloqueado"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
				to: "/dashboard/formulario",
				icon: FileText,
				title: "Preencha seu formulário",
				desc: "Assim que for aprovado, você libera pagamentos, chat completo e demais recursos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-surface p-6 ring-1 ring-border text-sm text-muted-foreground",
				children: "Enquanto o formulário não é enviado e aprovado pela administração, as áreas de pagamentos e chat permanecem bloqueadas."
			})
		]
	});
}
function PendingState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl rounded-2xl bg-surface p-10 text-center ring-1 ring-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mb-6 flex size-14 items-center justify-center rounded-full bg-warning/10 ring-1 ring-warning/40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-6 text-warning" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Aguardando aprovação"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-3 max-w-md text-sm text-muted-foreground",
				children: "Seu cadastro foi recebido e está sendo revisado pela administração da Malta. Você receberá acesso completo assim que for aprovado."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: malta_fox_default,
				alt: "",
				className: "mx-auto mt-8 size-40 opacity-70"
			})
		]
	});
}
function RejectedState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl rounded-2xl bg-surface p-10 text-center ring-1 ring-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mb-6 flex size-14 items-center justify-center rounded-full bg-destructive/10 ring-1 ring-destructive/40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-6 text-destructive" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "Cadastro não aprovado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-3 max-w-md text-sm text-muted-foreground",
				children: "Seu cadastro foi rejeitado pela administração. Entre em contato com um líder da Malta pelo Discord para mais informações."
			})
		]
	});
}
function ApprovedHome({ profile, isStaff, userId }) {
	useSiteSettings();
	const pendingCountQuery = useQuery({
		queryKey: ["pending-forms-count"],
		enabled: isStaff,
		queryFn: async () => {
			const { count } = await supabase.from("recruitment_forms").select("id", {
				count: "exact",
				head: true
			}).eq("status", "submitted");
			return count ?? 0;
		}
	});
	const nextPaymentQ = useQuery({
		queryKey: ["my-next-payment", userId],
		enabled: profile.form_status === "approved" || profile.status === "approved",
		queryFn: async () => {
			const { data } = await supabase.from("payments").select("*").eq("user_id", userId).in("status", [
				"pending",
				"submitted",
				"overdue"
			]).order("week_start", { ascending: false }).limit(1).maybeSingle();
			return data;
		}
	});
	const daysLeft = nextPaymentQ.data ? Math.ceil((new Date(nextPaymentQ.data.due_date).getTime() - Date.now()) / (1e3 * 60 * 60 * 24)) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-medium tracking-tight",
				children: [
					"Olá, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: profile.first_name
					}),
					"."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Bem-vindo ao painel da Malta."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: CircleCheck,
						label: "Status",
						value: "Ativo",
						tint: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: FileText,
						label: "Formulário",
						value: profile.form_status === "approved" || profile.status === "approved" ? "Aprovado" : profile.form_status === "submitted" ? "Em análise" : profile.form_status === "rejected" ? "Recusado" : "Não enviado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						icon: CreditCard,
						label: "Pagamento semanal",
						value: profile.form_status === "approved" || profile.status === "approved" ? nextPaymentQ.data ? `${daysLeft !== null && daysLeft >= 0 ? `${daysLeft} dias para pagar` : daysLeft !== null ? "Vencido" : "Aguardando"} · ${formatBRL(nextPaymentQ.data.amount)}` : "Em dia" : "Bloqueado"
					})
				]
			}),
			profile.form_status !== "approved" && profile.status !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
				to: "/dashboard/formulario",
				icon: FileText,
				title: "Complete seu formulário",
				desc: "Necessário para liberar pagamentos e chat completo."
			}),
			(profile.form_status === "approved" || profile.status === "approved") && nextPaymentQ.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-primary/5 p-6 ring-1 ring-primary/20 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-semibold text-primary uppercase tracking-wider flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4" }), " Pagamento Pendente"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium px-2 py-0.5 rounded-full bg-primary/10 text-primary ring-1 ring-primary/30",
						children: daysLeft !== null && daysLeft >= 0 ? `Vence em ${daysLeft} dias` : "Atrasado"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-bold tracking-tight",
						children: formatBRL(nextPaymentQ.data.amount)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground mt-1",
						children: ["Referente à semana de ", new Date(nextPaymentQ.data.week_start).toLocaleDateString("pt-BR")]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard/pagamentos",
						className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-all flex items-center gap-2",
						children: ["Ver PIX e enviar comprovante ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					(profile.form_status === "approved" || profile.status === "approved") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
						to: "/dashboard/pagamentos",
						icon: CreditCard,
						title: "Pagamentos",
						desc: "Envie comprovantes e veja próximas cobranças."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
						to: "/dashboard/chat",
						icon: MessageSquare,
						title: "Chat",
						desc: "Fale com a Malta em tempo real."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionCard, {
						to: "/dashboard/avisos",
						icon: Megaphone,
						title: "Avisos",
						desc: "Comunicados oficiais e notificações."
					})
				]
			}),
			isStaff && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/dashboard/admin/formularios",
				className: "group flex items-center justify-between rounded-xl bg-surface p-6 ring-1 ring-border transition-colors hover:ring-primary/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 text-primary" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium",
						children: "Formulários aguardando"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: "Revise novos candidatos."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary ring-1 ring-primary/30",
						children: [pendingCountQuery.data ?? 0, " pendentes"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" })]
				})]
			})
		]
	});
}
function ActionCard({ to, icon: Icon, title, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group flex items-center justify-between rounded-xl bg-surface p-5 ring-1 ring-border transition-colors hover:ring-primary/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-10 place-items-center rounded-lg bg-primary/10 ring-1 ring-primary/30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-primary" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground",
				children: desc
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" })]
	});
}
function Card({ icon: Icon, label, value, tint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-6 ring-1 ring-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium uppercase tracking-widest text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-4 ${tint === "success" ? "text-success" : "text-primary"}` })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 text-2xl font-medium tracking-tight",
			children: value
		})]
	});
}
//#endregion
export { DashboardHome as component };
