import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.index-DwX1G7hP.js
var $$splitComponentImporter = () => import("./dashboard.index-DQeiwtC8.mjs");
var Route = createFileRoute("/_authenticated/dashboard/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
