import { f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { U as LayoutDashboard, X as Globe, r as Users, v as ShieldAlert, y as Settings } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.master--3Tfp7WC.js
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/dashboard/master",
		label: "Overview",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/dashboard/master/organizations",
		label: "Organizações",
		icon: Globe,
		exact: false
	},
	{
		to: "/dashboard/master/users",
		label: "Global Users",
		icon: Users,
		exact: false
	},
	{
		to: "/dashboard/master/security",
		label: "Segurança",
		icon: ShieldAlert,
		exact: false
	},
	{
		to: "/dashboard/master/settings",
		label: "Global Config",
		icon: Settings,
		exact: false
	}
];
function MasterLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-9 shrink-0 place-items-center rounded-lg bg-primary/15 ring-1 ring-primary/30 sm:size-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-2xl font-medium tracking-tight sm:text-3xl",
						children: "Painel Master"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground sm:text-sm",
						children: "Gestão multi-organização."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 ring-1 ring-border sm:mx-0 sm:flex-wrap",
				children: TABS.map((t) => {
					const active = t.exact ? pathname === t.to : pathname.startsWith(t.to);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: t.to,
						className: `inline-flex shrink-0 items-center gap-2 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${active ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-3.5" }), t.label]
					}, t.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
		]
	});
}
//#endregion
export { MasterLayout as component };
