import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { St as ArrowUpRight, X as Globe, ot as CreditCard, r as Users } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.master.index-DQKMOK-x.js
var import_jsx_runtime = require_jsx_runtime();
function MasterOverview() {
	const statsQ = useQuery({
		queryKey: ["master-stats"],
		queryFn: async () => {
			const { data: orgs } = await supabase.from("organizations").select("*");
			const { count: users } = await supabase.from("profiles").select("*", {
				count: "exact",
				head: true
			});
			const sevenDaysAgo = (/* @__PURE__ */ new Date(Date.now() - 10080 * 60 * 1e3)).toISOString();
			const { data: rev } = await supabase.from("payments").select("amount,created_at").eq("status", "approved").gte("created_at", sevenDaysAgo);
			const weeklyRevenueCents = (rev ?? []).reduce((acc, r) => acc + Math.round(Number(r.amount ?? 0) * 100), 0);
			let estimatedRevenueCents = 0;
			let activeSubs = 0;
			for (const o of orgs ?? []) {
				if (o.status && !["active", "approved"].includes(o.status)) continue;
				activeSubs++;
				if (o.billing_model === "monthly_fixed") estimatedRevenueCents += Number(o.monthly_fee_cents ?? 0);
				else {
					const pct = Number(o.revshare_percent ?? 20);
					estimatedRevenueCents += Math.round(weeklyRevenueCents * (pct / 100) * 4.33);
				}
			}
			return {
				orgs: orgs?.length ?? 0,
				totalUsers: users ?? 0,
				activeSubs,
				mrr: estimatedRevenueCents / 100
			};
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Organizações",
					value: statsQ.data?.orgs ?? 0,
					icon: Globe,
					color: "text-blue-500"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Usuários Globais",
					value: statsQ.data?.totalUsers ?? 0,
					icon: Users,
					color: "text-primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Instâncias Ativas",
					value: statsQ.data?.activeSubs ?? 0,
					icon: CreditCard,
					color: "text-success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "MRR Estimado",
					value: new Intl.NumberFormat("pt-BR", {
						style: "currency",
						currency: "BRL"
					}).format(statsQ.data?.mrr ?? 0),
					icon: ArrowUpRight,
					color: "text-amber-500"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface p-6 ring-1 ring-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium mb-4",
				children: "Instâncias e Organizações"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg ring-1 ring-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-surface-muted/50 border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Organização"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Plano"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Slug"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterOrgRows, {})
					})]
				})
			})]
		})]
	});
}
function MasterOrgRows() {
	const navigate = useNavigate();
	const { data } = useQuery({
		queryKey: ["master-orgs"],
		queryFn: async () => {
			const { data } = await supabase.from("organizations").select("*");
			return data ?? [];
		}
	});
	if (!data?.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		colSpan: 5,
		className: "px-4 py-8 text-center text-muted-foreground",
		children: "Nenhuma organização encontrada."
	}) });
	return data.map((org) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "hover:bg-surface-muted/30",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 font-medium",
				children: org.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-muted-foreground text-xs",
				children: org.billing_model === "monthly_fixed" ? `Mensal fixo · ${new Intl.NumberFormat("pt-BR", {
					style: "currency",
					currency: "BRL"
				}).format((org.monthly_fee_cents ?? 0) / 100)}` : `Revshare · ${Number(org.revshare_percent ?? 20)}%/sem`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 font-mono text-xs",
				children: org.slug
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${org.status === "suspended" ? "bg-amber-500/10 text-amber-500 ring-amber-500/30" : org.status === "canceled" ? "bg-destructive/10 text-destructive ring-destructive/30" : "bg-success/10 text-success ring-success/30"}`,
					children: org.status === "suspended" ? "Suspenso" : org.status === "canceled" ? "Cancelado" : "Ativo"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "text-primary hover:underline cursor-pointer transition-transform hover:scale-105",
					onClick: () => navigate({ to: "/dashboard/master/organizations" }),
					children: "Configurar"
				})
			})
		]
	}, org.id));
}
function StatCard({ label, value, icon: Icon, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-5 ring-1 ring-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between mb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-4 ${color}` })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-2xl font-bold tracking-tight",
			children: value
		})]
	});
}
//#endregion
export { MasterOverview as component };
