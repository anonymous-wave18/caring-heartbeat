import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { G as Info, H as LoaderCircle, O as Plus, d as Trash2, j as Percent, rt as DollarSign, w as Save } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.master.organizations-CJ3mWrbl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BRL = (cents) => new Intl.NumberFormat("pt-BR", {
	style: "currency",
	currency: "BRL"
}).format((cents ?? 0) / 100);
function OrgsPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["orgs"],
		queryFn: async () => {
			const { data, error } = await supabase.from("organizations").select("*").order("created_at", { ascending: false });
			if (error) throw error;
			return (data ?? []).map((o) => ({
				...o,
				billing_model: o.billing_model || "weekly_revshare",
				revshare_percent: Number(o.revshare_percent ?? 20),
				monthly_fee_cents: Number(o.monthly_fee_cents ?? 0)
			}));
		}
	});
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		slug: "",
		owner_email: "",
		billing_model: "weekly_revshare",
		revshare_percent: 20,
		monthly_fee_brl: 0
	});
	const createMut = useMutation({
		mutationFn: async () => {
			if (!form.name.trim() || !form.slug.trim()) throw new Error("Nome e slug são obrigatórios");
			const payload = {
				name: form.name.trim(),
				slug: form.slug.trim().toLowerCase().replace(/\s+/g, "-"),
				owner_email: form.owner_email.trim() || null,
				billing_model: form.billing_model,
				revshare_percent: form.billing_model === "weekly_revshare" ? form.revshare_percent : 0,
				monthly_fee_cents: form.billing_model === "monthly_fixed" ? Math.round(form.monthly_fee_brl * 100) : 0,
				plan: form.billing_model === "weekly_revshare" ? "revshare" : "fixed"
			};
			const { error } = await supabase.from("organizations").insert(payload);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Organização criada");
			setForm({
				name: "",
				slug: "",
				owner_email: "",
				billing_model: "weekly_revshare",
				revshare_percent: 20,
				monthly_fee_brl: 0
			});
			qc.invalidateQueries({ queryKey: ["orgs"] });
			qc.invalidateQueries({ queryKey: ["master-orgs"] });
			qc.invalidateQueries({ queryKey: ["master-stats"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const updMut = useMutation({
		mutationFn: async (o) => {
			const { error } = await supabase.from("organizations").update({
				name: o.name,
				owner_email: o.owner_email,
				billing_model: o.billing_model,
				revshare_percent: o.billing_model === "weekly_revshare" ? o.revshare_percent : 0,
				monthly_fee_cents: o.billing_model === "monthly_fixed" ? o.monthly_fee_cents : 0,
				status: o.status,
				notes: o.notes,
				plan: o.billing_model === "weekly_revshare" ? "revshare" : "fixed"
			}).eq("id", o.id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Salvo");
			qc.invalidateQueries({ queryKey: ["orgs"] });
			qc.invalidateQueries({ queryKey: ["master-orgs"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const delMut = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("organizations").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Removida");
			qc.invalidateQueries({ queryKey: ["orgs"] });
			qc.invalidateQueries({ queryKey: ["master-orgs"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Percent, { className: "size-5" }),
					title: "Revshare Semanal",
					badge: "20% padrão",
					desc: "Cobrança semanal proporcional ao faturamento da organização. Por padrão, 20% do que os membros pagaram nos últimos 7 dias vai para a plataforma. Ideal para orgs em crescimento — a plataforma ganha junto."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5" }),
					title: "Mensal Fixo",
					badge: "valor fechado",
					desc: "Cobrança mensal com valor combinado, independente de quantos membros a organização tem. Ideal para orgs grandes e estáveis que preferem custo previsível."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-5 ring-1 ring-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-4 text-lg font-medium",
						children: "Nova organização"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Nome da organização"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "input w-full",
									placeholder: "Ex: Malta RJ",
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Slug (único, sem espaço)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "input w-full font-mono text-xs",
									placeholder: "malta-rj",
									value: form.slug,
									onChange: (e) => setForm({
										...form,
										slug: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Email do dono"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "input w-full",
									placeholder: "dono@exemplo.com",
									value: form.owner_email,
									onChange: (e) => setForm({
										...form,
										owner_email: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Modelo de cobrança"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "input w-full",
									value: form.billing_model,
									onChange: (e) => setForm({
										...form,
										billing_model: e.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "weekly_revshare",
										children: "Revshare semanal (%)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "monthly_fixed",
										children: "Mensal fixo (R$)"
									})]
								})]
							}),
							form.billing_model === "weekly_revshare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Percentual sobre o faturamento semanal (%)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									max: 100,
									step: "0.5",
									className: "input w-full",
									value: form.revshare_percent,
									onChange: (e) => setForm({
										...form,
										revshare_percent: Number(e.target.value)
									})
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-xs font-medium text-muted-foreground",
									children: "Valor mensal fixo (R$)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									step: "10",
									className: "input w-full",
									value: form.monthly_fee_brl,
									onChange: (e) => setForm({
										...form,
										monthly_fee_brl: Number(e.target.value)
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => createMut.mutate(),
						disabled: createMut.isPending,
						className: "mt-3 inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:bg-primary/90 hover:scale-[1.02] active:scale-95 disabled:opacity-50 cursor-pointer",
						children: [createMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Adicionar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 flex items-start gap-1.5 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 size-3.5 shrink-0" }), "O modelo pode ser trocado depois. A cobrança estimada aparece automaticamente na Overview."]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface ring-1 ring-border overflow-hidden",
				children: [
					q.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "inline size-4 animate-spin" })
					}),
					q.error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 text-center text-sm text-destructive",
						children: ["Erro: ", q.error.message]
					}),
					q.data && q.data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "Nenhuma organização."
					}),
					q.data && q.data.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrgRow, {
						org: o,
						onSave: (u) => updMut.mutate(u),
						onDelete: () => {
							if (confirm(`Remover ${o.name}?`)) delMut.mutate(o.id);
						}
					}, o.id))
				]
			})
		]
	});
}
function PlanCard({ icon, title, badge, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-5 ring-1 ring-border transition-all hover:ring-primary/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-9 place-items-center rounded-lg bg-primary/15 text-primary ring-1 ring-primary/30",
				children: icon
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] font-bold uppercase tracking-wider text-primary",
					children: badge
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs leading-relaxed text-muted-foreground",
			children: desc
		})]
	});
}
function OrgRow({ org, onSave, onDelete }) {
	const [o, setO] = (0, import_react.useState)(org);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-border p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2 sm:grid-cols-[1.2fr_1fr_1.2fr_150px_150px_130px_auto]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input",
					value: o.name,
					onChange: (e) => setO({
						...o,
						name: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input font-mono text-xs",
					value: o.slug,
					disabled: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input",
					value: o.owner_email ?? "",
					onChange: (e) => setO({
						...o,
						owner_email: e.target.value
					}),
					placeholder: "email do dono"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "input",
					value: o.billing_model,
					onChange: (e) => setO({
						...o,
						billing_model: e.target.value
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "weekly_revshare",
						children: "Revshare semanal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "monthly_fixed",
						children: "Mensal fixo"
					})]
				}),
				o.billing_model === "weekly_revshare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						max: 100,
						step: "0.5",
						className: "input w-full",
						value: o.revshare_percent,
						onChange: (e) => setO({
							...o,
							revshare_percent: Number(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "%"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "R$"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 0,
						step: "10",
						className: "input w-full",
						value: (o.monthly_fee_cents ?? 0) / 100,
						onChange: (e) => setO({
							...o,
							monthly_fee_cents: Math.round(Number(e.target.value) * 100)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "input",
					value: o.status,
					onChange: (e) => setO({
						...o,
						status: e.target.value
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "active",
							children: "Ativo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "suspended",
							children: "Suspenso"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "canceled",
							children: "Cancelado"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onSave(o),
						className: "rounded-md p-2 text-primary transition-all hover:bg-primary/10 hover:scale-110 cursor-pointer",
						title: "Salvar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onDelete,
						className: "rounded-md p-2 text-destructive transition-all hover:bg-destructive/10 hover:scale-110 cursor-pointer",
						title: "Remover",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-[11px] text-muted-foreground",
			children: o.billing_model === "weekly_revshare" ? `Cobrança semanal = ${o.revshare_percent}% do faturamento da org nos últimos 7 dias.` : `Cobrança mensal fixa de ${BRL(o.monthly_fee_cents)}.`
		})]
	});
}
//#endregion
export { OrgsPage as component };
