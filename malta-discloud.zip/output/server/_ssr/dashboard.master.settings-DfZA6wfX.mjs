import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, b as Settings2, w as Save } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.master.settings-DfZA6wfX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["platform-settings"],
		queryFn: async () => {
			const { data, error } = await supabase.from("platform_settings").select("*").eq("id", 1).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const [form, setForm] = (0, import_react.useState)({
		platform_name: "",
		logo_url: "",
		saas_fee_cents: 0
	});
	(0, import_react.useEffect)(() => {
		if (q.data) setForm({
			platform_name: q.data.platform_name ?? "",
			logo_url: q.data.logo_url ?? "",
			saas_fee_cents: q.data.saas_fee_cents ?? 0
		});
	}, [q.data]);
	const save = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("platform_settings").update({
				platform_name: form.platform_name,
				logo_url: form.logo_url || null,
				saas_fee_cents: Number(form.saas_fee_cents) || 0,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("id", 1);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Configurações salvas");
			qc.invalidateQueries({ queryKey: ["platform-settings"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-medium",
				children: "Configurações Globais da Plataforma"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface p-6 ring-1 ring-border space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mb-1 block text-sm font-medium",
					children: "Nome da plataforma"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input w-full",
					value: form.platform_name,
					onChange: (e) => setForm({
						...form,
						platform_name: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mb-1 block text-sm font-medium",
					children: "Logo URL"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "input w-full",
					value: form.logo_url,
					onChange: (e) => setForm({
						...form,
						logo_url: e.target.value
					}),
					placeholder: "https://…"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1 block text-sm font-medium",
						children: "Taxa SaaS (centavos por organização/mês)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: "input w-full",
						value: form.saas_fee_cents,
						onChange: (e) => setForm({
							...form,
							saas_fee_cents: Number(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Ex.: 4990 = R$ 49,90"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => save.mutate(),
					disabled: save.isPending,
					className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50",
					children: [save.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Salvar"]
				})
			]
		})]
	});
}
//#endregion
export { SettingsPage as component };
