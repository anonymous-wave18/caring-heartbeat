import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { H as LoaderCircle, S as Search } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.master.users-DPezkevt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UsersPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const query = useQuery({
		queryKey: ["master-users"],
		queryFn: async () => {
			const { data: profiles, error } = await supabase.from("profiles").select("id, first_name, last_name, email, avatar_url, is_staff, form_status, status, created_at").order("created_at", { ascending: false });
			if (error) throw error;
			const { data: roles } = await supabase.from("user_roles").select("user_id, role");
			const rMap = /* @__PURE__ */ new Map();
			(roles ?? []).forEach((r) => {
				const a = rMap.get(r.user_id) ?? [];
				a.push(r.role);
				rMap.set(r.user_id, a);
			});
			return (profiles ?? []).map((p) => ({
				...p,
				roles: rMap.get(p.id) ?? []
			}));
		}
	});
	const filtered = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		if (!s) return query.data ?? [];
		return (query.data ?? []).filter((u) => {
			const full = `${u.first_name ?? ""} ${u.last_name ?? ""} ${u.email ?? ""}`.toLowerCase();
			return s.split(/\s+/).every((t) => full.includes(t));
		});
	}, [q, query.data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "Buscar por nome ou email…",
				className: "input w-full pl-9"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface ring-1 ring-border overflow-hidden",
			children: [
				query.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-6 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "inline size-4 animate-spin" })
				}),
				query.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground px-4 py-2 border-b border-border",
					children: [
						filtered.length,
						" de ",
						query.data.length,
						" usuários"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-border",
					children: filtered.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 p-4 sm:grid-cols-[1fr_1fr_1fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-medium",
								children: [
									u.first_name || "—",
									" ",
									u.last_name || ""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: u.email
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Status: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: u.status || u.form_status || "—"
								})] }), u.is_staff && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-primary",
									children: "Staff"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1",
								children: u.roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary",
									children: r
								}, r))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground text-right",
								children: new Date(u.created_at).toLocaleDateString("pt-BR")
							})
						]
					}, u.id))
				})
			]
		})]
	});
}
//#endregion
export { UsersPage as component };
