import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, c as Upload, ct as Clock, ft as CircleCheck, pt as CircleAlert, st as Copy, vt as CalendarClock } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useSiteSettings, t as formatBRL } from "./useSiteSettings-Do6dVqgS.mjs";
import { i as maskPixKey } from "./masks-CicbQFDC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.pagamentos-Bk-6mTvc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PagamentosPage() {
	const qc = useQueryClient();
	const settingsQ = useSiteSettings();
	const userId = useQuery({
		queryKey: ["auth-user"],
		queryFn: async () => (await supabase.auth.getUser()).data.user
	}).data?.id;
	const paymentsQ = useQuery({
		queryKey: ["my-payments", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data } = await supabase.from("payments").select("*").eq("user_id", userId).order("week_start", { ascending: false });
			return data ?? [];
		}
	});
	useQuery({
		queryKey: ["my-proofs", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data } = await supabase.from("payment_proofs").select("*").eq("user_id", userId);
			return data ?? [];
		}
	});
	const generateCurrentMut = useMutation({
		mutationFn: async () => {
			if (!userId) return;
			const { error } = await supabase.rpc("ensure_current_payment", { _user_id: userId });
			if (error) throw error;
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["my-payments"] })
	});
	const uploadProof = useMutation({
		mutationFn: async (args) => {
			if (!userId) throw new Error("no user");
			const path = `${userId}/${args.paymentId}-${Date.now()}-${args.file.name.replace(/[^\w.\-]+/g, "_")}`;
			const { error: upErr } = await supabase.storage.from("payment-proofs").upload(path, args.file);
			if (upErr) throw upErr;
			const { error: insErr } = await supabase.from("payment_proofs").insert({
				payment_id: args.paymentId,
				user_id: userId,
				file_path: path,
				file_name: args.file.name
			});
			if (insErr) throw insErr;
			await supabase.from("payments").update({ status: "submitted" }).eq("id", args.paymentId);
		},
		onSuccess: () => {
			toast.success("Comprovante enviado. Aguarde a aprovação.");
			qc.invalidateQueries({ queryKey: ["my-payments"] });
			qc.invalidateQueries({ queryKey: ["my-proofs"] });
		},
		onError: (e) => toast.error(e.message)
	});
	if (settingsQ.isLoading || paymentsQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" });
	const settings = settingsQ.data;
	const payments = paymentsQ.data ?? [];
	const current = payments[0];
	const pix = settings?.pix_key ? {
		key: settings.pix_key,
		key_type: settings.pix_key_type,
		beneficiary: settings.pix_beneficiary
	} : null;
	const now = /* @__PURE__ */ new Date();
	const daysLeft = current ? Math.ceil((new Date(current.due_date).getTime() - now.getTime()) / (1e3 * 60 * 60 * 24)) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-medium tracking-tight",
				children: "Pagamentos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: ["Semanal — ", formatBRL(settings?.weekly_amount ?? 0)]
			})] }),
			!current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-6 ring-1 ring-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Nenhum pagamento gerado ainda para esta semana."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => generateCurrentMut.mutate(),
					className: "mt-3 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
					children: "Gerar cobrança da semana"
				})]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-hero p-6 ring-1 ring-primary/30 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wider text-primary/80",
								children: "Cobrança atual"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-2xl font-semibold",
								children: formatBRL(current.amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									"Semana ",
									current.week_start,
									" → ",
									current.week_end
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: current.status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-4 text-primary" }), current.status === "approved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-success",
							children: "Pago e aprovado."
						}) : daysLeft !== null && daysLeft >= 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Faltam ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
								className: "text-primary",
								children: [daysLeft, " dias"]
							}),
							" — vence em ",
							current.due_date
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-destructive",
							children: ["Vencido em ", current.due_date]
						})]
					}),
					pix && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-background/50 p-4 ring-1 ring-border space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wider text-muted-foreground",
								children: "Dados do PIX"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary ring-1 ring-primary/30",
								children: "PIX oficial"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 text-sm sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixField, {
									label: "Beneficiário",
									value: pix.beneficiary ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixField, {
									label: "Tipo",
									value: pix.key_type ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixField, {
									label: "Chave",
									value: maskPixKey(pix.key, pix.key_type),
									copyable: true,
									full: true
								})
							]
						})]
					}),
					(current.status === "pending" || current.status === "overdue") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadProofButton, {
						onFile: (f) => uploadProof.mutate({
							paymentId: current.id,
							file: f
						}),
						pending: uploadProof.isPending
					}),
					current.status === "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-warning",
						children: "Comprovante enviado. Aguardando aprovação da administração."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface ring-1 ring-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-border px-6 py-3 text-sm font-medium",
					children: "Histórico"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "divide-y divide-border",
					children: [payments.slice(current ? 1 : 0).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between px-6 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								p.week_start,
								" → ",
								p.week_end
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: formatBRL(p.amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: p.status })
						]
					}, p.id)), payments.length <= (current ? 1 : 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-6 py-4 text-sm text-muted-foreground",
						children: "Sem histórico."
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dashboard",
				className: "text-sm text-muted-foreground hover:text-foreground",
				children: "← voltar"
			})
		]
	});
}
function StatusPill({ status }) {
	const map = {
		pending: {
			label: "Aguardando pagamento",
			cls: "bg-amber-500/10 text-amber-500 ring-amber-500/30",
			Icon: Clock
		},
		submitted: {
			label: "Em análise",
			cls: "bg-blue-500/10 text-blue-400 ring-blue-500/30",
			Icon: Clock
		},
		approved: {
			label: "Aprovado",
			cls: "bg-green-500/10 text-green-500 ring-green-500/30",
			Icon: CircleCheck
		},
		overdue: {
			label: "Vencido",
			cls: "bg-destructive/10 text-destructive ring-destructive/30",
			Icon: CircleAlert
		}
	};
	const m = map[status] ?? map.pending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ring-1 ${m.cls}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.Icon, { className: "size-3" }), m.label]
	});
}
function PixField({ label, value, copyable, full }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: full ? "sm:col-span-2" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-0.5 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-sm",
				children: value
			}), copyable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => {
					navigator.clipboard.writeText(value);
					toast.success("Chave copiada.");
				},
				className: "rounded-md p-1 text-muted-foreground hover:text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
			})]
		})]
	});
}
function UploadProofButton({ onFile, pending }) {
	const [drag, setDrag] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		onDragOver: (e) => {
			e.preventDefault();
			setDrag(true);
		},
		onDragLeave: () => setDrag(false),
		onDrop: (e) => {
			e.preventDefault();
			setDrag(false);
			const f = e.dataTransfer.files?.[0];
			if (f) onFile(f);
		},
		className: `flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed p-6 text-sm transition-colors ${drag ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`,
		children: [
			pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 text-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Arraste o comprovante ou clique para enviar" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				className: "hidden",
				accept: "image/*,application/pdf",
				onChange: (e) => {
					const f = e.target.files?.[0];
					if (f) onFile(f);
					e.currentTarget.value = "";
				}
			})
		]
	});
}
//#endregion
export { PagamentosPage as component };
