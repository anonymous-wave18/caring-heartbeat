import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.perfil-ComLZDSb.js
var $$splitComponentImporter = () => import("./dashboard.perfil-MF9-e9JX.mjs");
var Route = createFileRoute("/_authenticated/dashboard/perfil")({
	validateSearch: (search) => objectType({ view_id: stringType().optional() }).parse(search),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
