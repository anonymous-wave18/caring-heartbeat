import { i as __toESM } from "../_runtime.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { H as LoaderCircle, I as MessageCircle, a as UserPlus, p as Sparkles, q as Heart, x as Send } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as useAvatarUrl } from "./useAvatarUrl-BybYyeJz.mjs";
import { n as fetchPublicProfiles, r as listPublicProfiles } from "./publicProfiles-RuvJBJ7q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard.social-CGLcPGoY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function displayName(p) {
	return `${p?.first_name ?? ""} ${p?.last_name ?? ""}`.trim() || p?.discord_username || p?.email?.split("@")[0] || "Usuário";
}
function SocialFeed() {
	const qc = useQueryClient();
	const meId = useQuery({
		queryKey: ["auth-user-id"],
		queryFn: async () => (await supabase.auth.getUser()).data.user?.id ?? null
	}).data;
	const [body, setBody] = (0, import_react.useState)("");
	const followingIdsQ = useQuery({
		queryKey: ["my-following-ids", meId],
		enabled: !!meId,
		queryFn: async () => {
			const { data } = await supabase.from("user_follows").select("following_id").eq("follower_id", meId);
			return (data ?? []).map((r) => r.following_id);
		}
	});
	const feedQ = useQuery({
		queryKey: [
			"social-feed",
			meId,
			followingIdsQ.data
		],
		enabled: !!meId && followingIdsQ.data !== void 0,
		queryFn: async () => {
			const authorIds = Array.from(new Set([meId, ...followingIdsQ.data ?? []]));
			const { data: posts } = await supabase.from("profile_posts").select("id, body, created_at, user_id").in("user_id", authorIds).order("created_at", { ascending: false }).limit(80);
			const rows = posts ?? [];
			const map = await fetchPublicProfiles(Array.from(new Set(rows.map((r) => r.user_id))));
			return rows.map((r) => ({
				...r,
				author: map.get(r.user_id) ?? null
			}));
		}
	});
	const suggestionsQ = useQuery({
		queryKey: [
			"social-suggestions",
			meId,
			followingIdsQ.data
		],
		enabled: !!meId && followingIdsQ.data !== void 0,
		queryFn: async () => {
			const excluded = new Set([meId, ...followingIdsQ.data ?? []]);
			return (await listPublicProfiles(24)).filter((p) => !excluded.has(p.id)).slice(0, 6);
		}
	});
	const createPostMut = useMutation({
		mutationFn: async () => {
			const t = body.trim();
			if (!t) throw new Error("Escreva algo.");
			if (t.length > 500) throw new Error("Máximo 500 caracteres.");
			if (!meId) throw new Error("Sessão expirada.");
			const { error } = await supabase.from("profile_posts").insert({
				user_id: meId,
				body: t
			});
			if (error) throw error;
		},
		onSuccess: () => {
			setBody("");
			toast.success("Publicado no seu feed!");
			qc.invalidateQueries({ queryKey: ["social-feed"] });
			qc.invalidateQueries({ queryKey: ["profile-posts", meId] });
		},
		onError: (e) => toast.error(e.message)
	});
	const followMut = useMutation({
		mutationFn: async (targetId) => {
			if (!meId) throw new Error("Sessão expirada.");
			const { error } = await supabase.from("user_follows").insert({
				follower_id: meId,
				following_id: targetId
			});
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Agora você está seguindo.");
			qc.invalidateQueries({ queryKey: ["my-following-ids", meId] });
			qc.invalidateQueries({ queryKey: ["social-suggestions"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1fr_300px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-medium tracking-tight",
					children: "Rede Social"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Feed de quem você segue e da comunidade Malta."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-xl bg-surface p-4 ring-1 ring-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (e) => {
							e.preventDefault();
							createPostMut.mutate();
						},
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: body,
							onChange: (e) => setBody(e.target.value),
							rows: 3,
							maxLength: 500,
							placeholder: "O que você quer compartilhar com a Malta?",
							className: "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary/60 focus:ring-2 ring-primary/30"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] text-muted-foreground",
								children: [body.length, "/500"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								disabled: createPostMut.isPending || !body.trim(),
								className: "inline-flex items-center gap-2 rounded-md bg-primary px-4 py-1.5 text-sm font-medium text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-colors cursor-pointer",
								children: [createPostMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), "Publicar"]
							})]
						})]
					})
				}),
				feedQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid place-items-center py-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
				}) : (feedQ.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-8 text-center ring-1 ring-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mx-auto size-8 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Seu feed está vazio. Siga membros nas sugestões ao lado ou publique algo pra começar."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: (feedQ.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedPost, {
						post: p,
						meId: meId ?? null
					}, p.id))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "space-y-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 ring-1 ring-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2 text-sm font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" }), "Sugestões pra seguir"]
				}), suggestionsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-muted-foreground" }) : (suggestionsQ.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Nenhuma sugestão no momento."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3",
					children: (suggestionsQ.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuggestionRow, {
						p,
						onFollow: () => followMut.mutate(p.id),
						pending: followMut.isPending
					}, p.id))
				})]
			})
		})]
	});
}
function AuthorAvatar({ path, name }) {
	const url = useAvatarUrl(path ?? null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setFailed(false), [url, path]);
	const init = (name.trim()[0] ?? "?").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "size-9 shrink-0 overflow-hidden rounded-full bg-surface-muted ring-1 ring-border grid place-items-center text-xs font-medium",
		children: url && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: name,
			className: "h-full w-full object-cover",
			onError: () => setFailed(true)
		}) : init
	});
}
function SuggestionRow({ p, onFollow, pending }) {
	const name = displayName(p);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/dashboard/perfil",
			search: { view_id: p.id },
			className: "flex items-center gap-3 min-w-0 flex-1 hover:opacity-80 transition-opacity",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorAvatar, {
				path: p.avatar_url,
				name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate text-sm font-medium",
					children: name
				}), p.discord_username && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "truncate text-[11px] text-muted-foreground",
					children: ["@", p.discord_username]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: onFollow,
			disabled: pending,
			className: "inline-flex items-center gap-1 rounded-md bg-primary px-2.5 py-1 text-[11px] font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50 cursor-pointer transition-colors",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3" }), " Seguir"]
		})]
	});
}
function FeedPost({ post, meId }) {
	const qc = useQueryClient();
	const [showComments, setShowComments] = (0, import_react.useState)(false);
	const [comment, setComment] = (0, import_react.useState)("");
	const author = post.author;
	const authorName = displayName(author);
	const likesQ = useQuery({
		queryKey: ["post-likes", post.id],
		queryFn: async () => {
			const { data } = await supabase.from("post_likes").select("user_id").eq("post_id", post.id);
			return data ?? [];
		}
	});
	const commentsCountQ = useQuery({
		queryKey: ["post-comments-count", post.id],
		queryFn: async () => {
			const { count } = await supabase.from("post_comments").select("*", {
				count: "exact",
				head: true
			}).eq("post_id", post.id);
			return count ?? 0;
		}
	});
	const commentsQ = useQuery({
		queryKey: ["post-comments", post.id],
		enabled: showComments,
		queryFn: async () => {
			const { data } = await supabase.from("post_comments").select("id, body, created_at, user_id").eq("post_id", post.id).order("created_at");
			const rows = data ?? [];
			const map = await fetchPublicProfiles(Array.from(new Set(rows.map((r) => r.user_id))));
			return rows.map((r) => ({
				...r,
				profile: map.get(r.user_id)
			}));
		}
	});
	const liked = !!(meId && likesQ.data?.some((l) => l.user_id === meId));
	const likeCount = likesQ.data?.length ?? 0;
	const likeMut = useMutation({
		mutationFn: async () => {
			if (!meId) throw new Error("Sessão expirada.");
			if (liked) {
				const { error } = await supabase.from("post_likes").delete().eq("post_id", post.id).eq("user_id", meId);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("post_likes").insert({
					post_id: post.id,
					user_id: meId
				});
				if (error) throw error;
			}
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["post-likes", post.id] }),
		onError: (e) => toast.error(e.message)
	});
	const commentMut = useMutation({
		mutationFn: async () => {
			const t = comment.trim();
			if (!t) throw new Error("Escreva um comentário.");
			if (!meId) throw new Error("Sessão expirada.");
			const { error } = await supabase.from("post_comments").insert({
				post_id: post.id,
				user_id: meId,
				body: t
			});
			if (error) throw error;
		},
		onSuccess: () => {
			setComment("");
			qc.invalidateQueries({ queryKey: ["post-comments", post.id] });
			qc.invalidateQueries({ queryKey: ["post-comments-count", post.id] });
		},
		onError: (e) => toast.error(e.message)
	});
	const relativeTime = (0, import_react.useMemo)(() => {
		const diff = Date.now() - new Date(post.created_at).getTime();
		const m = Math.floor(diff / 6e4);
		if (m < 1) return "agora";
		if (m < 60) return `${m}min`;
		const h = Math.floor(m / 60);
		if (h < 24) return `${h}h`;
		const d = Math.floor(h / 24);
		if (d < 7) return `${d}d`;
		return new Date(post.created_at).toLocaleDateString("pt-BR");
	}, [post.created_at]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface p-4 ring-1 ring-border space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex items-center gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dashboard/perfil",
					search: { view_id: post.user_id },
					className: "flex items-center gap-3 hover:opacity-80 transition-opacity",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorAvatar, {
						path: author?.avatar_url ?? null,
						name: authorName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-medium",
						children: authorName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-muted-foreground",
						children: relativeTime
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm whitespace-pre-wrap break-words",
				children: post.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 border-t border-border pt-2 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => likeMut.mutate(),
					disabled: likeMut.isPending,
					className: `inline-flex items-center gap-1.5 hover:text-foreground transition-colors cursor-pointer ${liked ? "text-red-500" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `size-4 ${liked ? "fill-current" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: likeCount })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShowComments((s) => !s),
					className: "inline-flex items-center gap-1.5 hover:text-foreground transition-colors cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: commentsCountQ.data ?? 0 })]
				})]
			}),
			showComments && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 border-t border-border pt-3",
				children: [(commentsQ.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorAvatar, {
						path: c.profile?.avatar_url ?? null,
						name: displayName(c.profile)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-surface-muted/40 px-3 py-1.5 flex-1 ring-1 ring-border/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-medium",
							children: displayName(c.profile)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "whitespace-pre-wrap break-words",
							children: c.body
						})]
					})]
				}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						commentMut.mutate();
					},
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: comment,
						onChange: (e) => setComment(e.target.value),
						maxLength: 300,
						placeholder: "Escreva um comentário…",
						className: "flex-1 rounded-md border border-border bg-background px-3 py-1.5 text-sm outline-none focus:border-primary/60 focus:ring-2 ring-primary/30"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: commentMut.isPending || !comment.trim(),
						className: "inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground disabled:opacity-50 hover:bg-primary/90 cursor-pointer transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" })
					})]
				})]
			})
		]
	});
}
//#endregion
export { SocialFeed as component };
