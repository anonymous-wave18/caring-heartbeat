import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { a as createServerRpc, c as logBotActivity, i as callBot, l as sanitizeMessage, o as getBotConfig, r as botSecretsConfigured, s as getTargetProfile, t as assertOwner } from "./discordBot.server-B3C0n2G3.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DZO41X7i.mjs";
import { a as numberType, c as unionType, i as literalType, n as booleanType, o as objectType, r as enumType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/discordBot.functions-CD5cXVoX.js
var snowflake = stringType().regex(/^[0-9]{15,25}$/, "ID do Discord inválido (apenas números, 15-25 dígitos).");
var optionalSnowflake = unionType([snowflake, literalType("")]).optional().nullable();
/** Status do bot: secrets presentes (booleano) + ping. Nunca devolve valores de segredo. */
var getBotStatus_createServerFn_handler = createServerRpc({
	id: "3ea81bdb10d8daa89adec9f438db664083b90185a95c973e8a227b000c8faf40",
	name: "getBotStatus",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => getBotStatus.__executeServer(opts));
var getBotStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(getBotStatus_createServerFn_handler, async ({ context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const secrets = botSecretsConfigured();
	if (!secrets.apiUrl || !secrets.sharedSecret) return {
		secrets,
		online: false,
		error: "Secrets do bot ausentes no servidor."
	};
	const res = await callBot("ping", {}, 6e3);
	return {
		secrets,
		online: res.ok,
		error: res.ok ? null : res.error
	};
});
var testBotConnection_createServerFn_handler = createServerRpc({
	id: "bdad539c038fa8a258655db007a4f09fbbf05552fcdd3656211f84d57a7e6b20",
	name: "testBotConnection",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => testBotConnection.__executeServer(opts));
var testBotConnection = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(testBotConnection_createServerFn_handler, async ({ context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
	const secrets = botSecretsConfigured();
	if (!secrets.apiUrl || !secrets.sharedSecret) {
		const error = `Secrets ausentes no servidor: ${[!secrets.apiUrl ? "DISCORD_BOT_API_URL" : null, !secrets.sharedSecret ? "DISCORD_BOT_SHARED_SECRET" : null].filter(Boolean).join(" e ")}.`;
		await logBotActivity(supabase, {
			actor_id: userId,
			action: "bot.connection_test",
			status: "error",
			detail: {
				error,
				latency_ms: 0
			}
		});
		return {
			ok: false,
			latencyMs: 0,
			error,
			checkedAt,
			secrets
		};
	}
	const res = await callBot("ping", {}, 8e3);
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.connection_test",
		status: res.ok ? "success" : "error",
		detail: {
			latency_ms: res.latencyMs,
			error: res.ok ? null : res.error
		}
	});
	return {
		ok: res.ok,
		latencyMs: res.latencyMs,
		error: res.ok ? null : res.error,
		checkedAt,
		secrets
	};
});
var saveBotSettings_createServerFn_handler = createServerRpc({
	id: "de2bfbc9e956b5d60cf4a81ba49771634e6130159987ed4e963ab5dfee479bb3",
	name: "saveBotSettings",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => saveBotSettings.__executeServer(opts));
var saveBotSettings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	guild_id: optionalSnowflake,
	default_member_role_id: optionalSnowflake,
	overdue_role_id: optionalSnowflake,
	removal_after_days: numberType().int().min(1).max(90),
	enabled: booleanType()
}).parse(data)).handler(saveBotSettings_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const norm = (v) => v && v.length ? v : null;
	const { error } = await supabase.from("discord_bot_settings").update({
		guild_id: norm(data.guild_id),
		default_member_role_id: norm(data.default_member_role_id),
		overdue_role_id: norm(data.overdue_role_id),
		removal_after_days: data.removal_after_days,
		enabled: data.enabled,
		updated_at: (/* @__PURE__ */ new Date()).toISOString(),
		updated_by: userId
	}).eq("id", true);
	if (error) throw new Error(error.message);
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.settings_updated",
		status: "success"
	});
	return { ok: true };
});
var saveRoleMap_createServerFn_handler = createServerRpc({
	id: "f18bd1d51f1e614f713933a7ed1986360314ddea0345f56d924e895dcb0f1073",
	name: "saveRoleMap",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => saveRoleMap.__executeServer(opts));
var saveRoleMap = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ entries: arrayType(objectType({
	cargo_id: stringType().uuid(),
	discord_role_id: stringType()
})).max(100) }).parse(data)).handler(saveRoleMap_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const toUpsert = [];
	const toDelete = [];
	for (const e of data.entries) {
		const v = e.discord_role_id.trim();
		if (!v) {
			toDelete.push(e.cargo_id);
			continue;
		}
		if (!snowflake.safeParse(v).success) throw new Error(`Cargo do Discord inválido: "${v}". Use apenas números.`);
		toUpsert.push({
			cargo_id: e.cargo_id,
			discord_role_id: v,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
	}
	if (toDelete.length) {
		const { error } = await supabase.from("discord_role_map").delete().in("cargo_id", toDelete);
		if (error) throw new Error(error.message);
	}
	if (toUpsert.length) {
		const { error } = await supabase.from("discord_role_map").upsert(toUpsert, { onConflict: "cargo_id" });
		if (error) throw new Error(error.message);
	}
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.role_map_updated",
		status: "success",
		detail: {
			mapped: toUpsert.length,
			cleared: toDelete.length
		}
	});
	return {
		ok: true,
		mapped: toUpsert.length,
		cleared: toDelete.length
	};
});
var saveBotMessages_createServerFn_handler = createServerRpc({
	id: "0b2a4a73a18967b2f279bfdd79b8d55ad8313d34abf4fed19ad0f8a4cb4ece29",
	name: "saveBotMessages",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => saveBotMessages.__executeServer(opts));
var saveBotMessages = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ messages: arrayType(objectType({
	key: enumType([
		"welcome",
		"payment_pending",
		"payment_overdue",
		"role_removed",
		"renewed"
	]),
	template: stringType().max(1800)
})).min(1).max(5) }).parse(data)).handler(saveBotMessages_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const rows = data.messages.map((m) => ({
		key: m.key,
		template: sanitizeMessage(m.template),
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}));
	const { error } = await supabase.from("discord_bot_messages").upsert(rows, { onConflict: "key" });
	if (error) throw new Error(error.message);
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.messages_updated",
		status: "success"
	});
	return { ok: true };
});
var assignDiscordRole_createServerFn_handler = createServerRpc({
	id: "440161562212790cf894ba6a603b6d216fa6e7efe73cb171171343ef5a451583",
	name: "assignDiscordRole",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => assignDiscordRole.__executeServer(opts));
var assignDiscordRole = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	cargo_id: stringType().uuid()
}).parse(data)).handler(assignDiscordRole_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const target = await getTargetProfile(supabase, data.user_id);
	const { settings, roleMap } = await getBotConfig(supabase);
	const roleId = roleMap.get(data.cargo_id);
	if (!roleId) throw new Error("Este cargo ainda não está mapeado para um cargo do Discord.");
	if (!settings?.guild_id) throw new Error("Configure o ID do servidor (Guild ID) antes.");
	const res = await callBot("assign_role", {
		guild_id: settings.guild_id,
		discord_id: target.discord_id,
		role_id: roleId
	});
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.role_assigned",
		target_user_id: target.id,
		discord_id: target.discord_id,
		status: res.ok ? "success" : "error",
		detail: {
			role_id: roleId,
			cargo_id: data.cargo_id,
			error: res.ok ? null : res.error
		}
	});
	if (!res.ok) throw new Error(res.error);
	return { ok: true };
});
var removeDiscordRole_createServerFn_handler = createServerRpc({
	id: "d45e34cbcdf5255df7f5745857b8c2202722bb3f9a4491d0e4ec61fd8bfacf0a",
	name: "removeDiscordRole",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => removeDiscordRole.__executeServer(opts));
var removeDiscordRole = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	cargo_id: stringType().uuid()
}).parse(data)).handler(removeDiscordRole_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const target = await getTargetProfile(supabase, data.user_id);
	const { settings, roleMap } = await getBotConfig(supabase);
	const roleId = roleMap.get(data.cargo_id);
	if (!roleId) throw new Error("Este cargo ainda não está mapeado para um cargo do Discord.");
	if (!settings?.guild_id) throw new Error("Configure o ID do servidor (Guild ID) antes.");
	const res = await callBot("remove_role", {
		guild_id: settings.guild_id,
		discord_id: target.discord_id,
		role_id: roleId
	});
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.role_removed",
		target_user_id: target.id,
		discord_id: target.discord_id,
		status: res.ok ? "success" : "error",
		detail: {
			role_id: roleId,
			cargo_id: data.cargo_id,
			error: res.ok ? null : res.error
		}
	});
	if (!res.ok) throw new Error(res.error);
	return { ok: true };
});
var sendDiscordDm_createServerFn_handler = createServerRpc({
	id: "9825a52e9ac7853994f3d71b9c094a3c5a03879ad044a7bf64262c76fa6635c3",
	name: "sendDiscordDm",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => sendDiscordDm.__executeServer(opts));
var sendDiscordDm = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({
	user_id: stringType().uuid(),
	message: stringType().trim().min(1).max(1800)
}).parse(data)).handler(sendDiscordDm_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const target = await getTargetProfile(supabase, data.user_id);
	const message = sanitizeMessage(data.message);
	if (!message) throw new Error("Mensagem vazia após a sanitização.");
	const res = await callBot("send_dm", {
		discord_id: target.discord_id,
		message
	});
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.dm_sent",
		target_user_id: target.id,
		discord_id: target.discord_id,
		status: res.ok ? "success" : "error",
		detail: {
			preview: message.slice(0, 200),
			error: res.ok ? null : res.error
		}
	});
	if (!res.ok) throw new Error(res.error);
	return { ok: true };
});
var syncDiscordUser_createServerFn_handler = createServerRpc({
	id: "4e85a1fb146ae1c6a476cf5547d5ad332a719fe3f9e5120e7b2525d00f260b08",
	name: "syncDiscordUser",
	filename: "src/lib/discordBot.functions.ts"
}, (opts) => syncDiscordUser.__executeServer(opts));
var syncDiscordUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ user_id: stringType().uuid() }).parse(data)).handler(syncDiscordUser_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	await assertOwner(supabase, userId);
	const target = await getTargetProfile(supabase, data.user_id);
	const { settings, roleMap } = await getBotConfig(supabase);
	if (!settings?.guild_id) throw new Error("Configure o ID do servidor (Guild ID) antes.");
	const { data: lastPayment } = await supabase.from("payments").select("status, due_date").eq("user_id", target.id).order("due_date", { ascending: false }).limit(1).maybeSingle();
	const res = await callBot("sync_user", {
		guild_id: settings.guild_id,
		discord_id: target.discord_id,
		role_id: target.cargo_id ? roleMap.get(target.cargo_id) ?? null : null,
		default_role_id: settings.default_member_role_id ?? null,
		overdue_role_id: settings.overdue_role_id ?? null,
		payment_status: lastPayment?.status ?? null
	});
	await logBotActivity(supabase, {
		actor_id: userId,
		action: "bot.user_synced",
		target_user_id: target.id,
		discord_id: target.discord_id,
		status: res.ok ? "success" : "error",
		detail: {
			payment_status: lastPayment?.status ?? null,
			error: res.ok ? null : res.error
		}
	});
	if (!res.ok) throw new Error(res.error);
	return { ok: true };
});
//#endregion
export { assignDiscordRole_createServerFn_handler, getBotStatus_createServerFn_handler, removeDiscordRole_createServerFn_handler, saveBotMessages_createServerFn_handler, saveBotSettings_createServerFn_handler, saveRoleMap_createServerFn_handler, sendDiscordDm_createServerFn_handler, syncDiscordUser_createServerFn_handler, testBotConnection_createServerFn_handler };
