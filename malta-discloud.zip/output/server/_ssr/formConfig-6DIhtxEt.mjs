import { t as supabase } from "./client-D8gVtBRg.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/formConfig-6DIhtxEt.js
var DEFAULT_FIELD_LABELS = {
	cargo_desejado_id: "Cargo pretendido",
	full_name: "Nome completo",
	birth_date: "Data de nascimento",
	cpf: "CPF",
	bank_name: "Banco utilizado",
	bank_holder: "Nome do titular do banco",
	discord_contact: "Discord (usuário)",
	discord_avatar_url: "URL da foto de perfil do Discord",
	phone_self: "Seu número",
	phone_father: "Número do pai",
	phone_mother: "Número da mãe",
	availability: "Disponibilidade (dias/horários)",
	experience: "Experiência anterior",
	motivation: "Motivação para entrar",
	referred_by: "Indicado por (opcional)",
	location: "Localização em tempo real",
	address_proof: "Comprovante de residência"
};
var DEFAULT_FORM_CONFIG = {
	title: "📝 Formulário de Documentos — MALTA",
	subtitle: "Preencha os dados e anexe todos os documentos solicitados.",
	warning: "O preenchimento incorreto, informações falsas ou qualquer tentativa de golpe resultarão em medidas externas, incluindo boletim de ocorrência, além de desclassificação imediata. ATENÇÃO: NÃO REEMBOLSAMOS.",
	fields: Object.fromEntries(Object.keys(DEFAULT_FIELD_LABELS).map((k) => [k, {
		label: DEFAULT_FIELD_LABELS[k],
		required: [
			"cargo_desejado_id",
			"full_name",
			"birth_date",
			"cpf",
			"bank_name",
			"bank_holder",
			"phone_self",
			"location"
		].includes(k),
		hidden: false
	}])),
	docs: [
		{
			key: "rg_front",
			label: "Foto do RG (frente)",
			accept: "image/*",
			required: true
		},
		{
			key: "rg_back",
			label: "Foto do RG (verso)",
			accept: "image/*",
			required: true
		},
		{
			key: "selfie_rg",
			label: "Selfie segurando o RG",
			accept: "image/*",
			required: true
		},
		{
			key: "address_proof",
			label: "Comprovante de residência",
			accept: "image/*,application/pdf",
			required: true,
			hint: "Conta de luz, água, internet ou similar (últimos 3 meses)."
		},
		{
			key: "discord_avatar",
			label: "Foto do perfil do Discord",
			accept: "image/*",
			required: true
		},
		{
			key: "video",
			label: "Vídeo obrigatório de compromisso",
			accept: "video/*",
			required: true,
			hint: "Leia o texto abaixo antes de gravar."
		},
		{
			key: "other",
			label: "Outros documentos (opcional)",
			accept: "*",
			required: false
		}
	],
	customQuestions: []
};
function mergeFormConfig(raw) {
	const r = raw ?? {};
	return {
		title: r.title ?? DEFAULT_FORM_CONFIG.title,
		subtitle: r.subtitle ?? DEFAULT_FORM_CONFIG.subtitle,
		warning: r.warning ?? DEFAULT_FORM_CONFIG.warning,
		fields: {
			...DEFAULT_FORM_CONFIG.fields,
			...r.fields ?? {}
		},
		docs: r.docs && r.docs.length ? r.docs : DEFAULT_FORM_CONFIG.docs,
		customQuestions: r.customQuestions ?? []
	};
}
function useFormConfig() {
	return useQuery({
		queryKey: ["form_config"],
		queryFn: async () => {
			const { data } = await supabase.from("site_settings").select("form_config").eq("id", 1).maybeSingle();
			return mergeFormConfig(data?.form_config);
		},
		staleTime: 6e4
	});
}
//#endregion
export { useFormConfig as i, DEFAULT_FORM_CONFIG as n, mergeFormConfig as r, DEFAULT_FIELD_LABELS as t };
