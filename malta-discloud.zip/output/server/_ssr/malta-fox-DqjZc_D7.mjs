//#region node_modules/.nitro/vite/services/ssr/assets/malta-fox-DqjZc_D7.js
var malta_fox_default = "/assets/malta-fox-DCGzdn13.png";
//#endregion
export { malta_fox_default as t };
