//#region node_modules/.nitro/vite/services/ssr/assets/masks-CicbQFDC.js
function maskCPF(v) {
	return v.replace(/\D/g, "").slice(0, 11).replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}
function maskPhone(v) {
	const d = v.replace(/\D/g, "").slice(0, 11);
	if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
	return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
}
function maskDate(v) {
	const d = v.replace(/\D/g, "").slice(0, 8);
	if (d.length <= 4) return d.replace(/(\d{2})(\d)/, "$1/$2");
	return d.replace(/(\d{2})(\d{2})(\d)/, "$1/$2/$3");
}
function maskPixKey(v, type) {
	if (type === "cpf") return maskCPF(v);
	if (type === "phone") return maskPhone(v);
	return v;
}
//#endregion
export { maskPixKey as i, maskDate as n, maskPhone as r, maskCPF as t };
