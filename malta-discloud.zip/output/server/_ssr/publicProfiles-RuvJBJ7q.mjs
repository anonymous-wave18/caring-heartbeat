import { t as supabase } from "./client-D8gVtBRg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/publicProfiles-RuvJBJ7q.js
/**
* Perfis "públicos" (sem PII). Após a blindagem de RLS em `profiles`, membros
* comuns não conseguem mais ler a tabela direto — usamos a RPC SECURITY DEFINER
* `get_profiles_basic`, que só devolve campos não sensíveis. O SELECT direto
* continua como merge para staff (nome/foto atualizados manualmente).
*/
async function fetchPublicProfiles(ids) {
	const key = Array.from(new Set(ids.filter(Boolean)));
	const map = /* @__PURE__ */ new Map();
	if (key.length === 0) return map;
	const rpc = await supabase.rpc("get_profiles_basic", { _ids: key });
	for (const r of rpc?.data ?? []) map.set(r.id, r);
	const { data: profs } = await supabase.from("profiles").select("id, first_name, last_name, avatar_url, cargo_id, discord_username, email").in("id", key);
	for (const p of profs ?? []) {
		const prev = map.get(p.id);
		map.set(p.id, {
			id: p.id,
			first_name: p.first_name ?? prev?.first_name ?? null,
			last_name: p.last_name ?? prev?.last_name ?? null,
			avatar_url: p.avatar_url ?? prev?.avatar_url ?? null,
			cargo_id: p.cargo_id ?? prev?.cargo_id ?? null,
			is_staff: prev?.is_staff ?? false,
			discord_username: p.discord_username ?? prev?.discord_username ?? null,
			created_at: prev?.created_at ?? null,
			email: p.email ?? null
		});
	}
	return map;
}
async function fetchPublicProfile(id) {
	return (await fetchPublicProfiles([id])).get(id) ?? null;
}
/** Diretório de membros aprovados (sugestões da rede social). */
async function listPublicProfiles(limit = 24) {
	const { data } = await supabase.rpc("list_public_profiles", { _limit: limit });
	return data ?? [];
}
//#endregion
export { fetchPublicProfiles as n, listPublicProfiles as r, fetchPublicProfile as t };
