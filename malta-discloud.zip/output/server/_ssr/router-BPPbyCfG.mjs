import { i as __toESM } from "../_runtime.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, j as redirect, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Route$30 } from "./auth-Bhx_TPJP.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$31 } from "./dashboard-CWL6q7Nv.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$32 } from "./dashboard.chat-D67vFfKF.mjs";
import { t as Route$33 } from "./dashboard.index-DwX1G7hP.mjs";
import { t as Route$34 } from "./dashboard.perfil-ComLZDSb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BPPbyCfG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-4cC5VA1A.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-6 flex size-14 items-center justify-center rounded-xl bg-primary/10 ring-1 ring-primary/30",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-lg font-semibold text-primary",
						children: "404"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight text-foreground",
					children: "Página não encontrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "O caminho que você tentou acessar não existe ou foi movido."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Voltar ao início"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "Algo deu errado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Tente novamente ou volte para o início."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Tentar novamente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Início"
					})]
				})
			]
		})
	});
}
var Route$29 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Malta Manager — Gestão profissional da Organização Malta" },
			{
				name: "description",
				content: "Malta Manager: plataforma oficial de gestão da Organização Malta. Cadastro, aprovação, mensalidades, comprovantes e histórico completo em um só lugar."
			},
			{
				name: "author",
				content: "Organização Malta"
			},
			{
				property: "og:title",
				content: "Malta Manager"
			},
			{
				property: "og:description",
				content: "A infraestrutura digital da Organização Malta. Substitua planilhas e formulários por uma plataforma profissional."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "theme-color",
				content: "#09090b"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Malta"
			}
		],
		links: [
			{
				rel: "manifest",
				href: "/manifest.json"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "shortcut icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "apple-touch-icon",
				href: "/favicon.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$29.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const { data: sub } = supabase.auth.onAuthStateChange((event) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			router.invalidate();
			if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
		});
		return () => sub.subscription.unsubscribe();
	}, [queryClient, router]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			theme: "dark",
			position: "top-right"
		})]
	});
}
var $$splitComponentImporter$28 = () => import("./route-Di7iQBCH.mjs");
var Route$28 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({
			to: "/auth",
			search: { mode: "login" }
		});
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./routes-Bt0UcLRK.mjs");
var Route$27 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Malta Manager — Gestão profissional da Organização Malta" }, {
		name: "description",
		content: "Plataforma oficial da Organização Malta para gestão de membros, mensalidades, comprovantes e aprovações. Substitua planilhas por infraestrutura profissional."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./dashboard.social-CGLcPGoY.mjs");
var Route$26 = createFileRoute("/_authenticated/dashboard/social")({
	head: () => ({ meta: [{ title: "Rede Social — Malta" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./dashboard.pagamentos-Bk-6mTvc.mjs");
var Route$25 = createFileRoute("/_authenticated/dashboard/pagamentos")({ component: lazyRouteComponent($$splitComponentImporter$25, "component") });
var $$splitComponentImporter$24 = () => import("./dashboard.master--3Tfp7WC.mjs");
var Route$24 = createFileRoute("/_authenticated/dashboard/master")({
	ssr: false,
	beforeLoad: async () => {
		const { data: userData } = await supabase.auth.getUser();
		if (!userData.user) throw redirect({
			to: "/auth",
			search: { mode: "login" }
		});
		const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userData.user.id);
		if (!((roles ?? []).some((r) => r.role === "owner") && ["candinofpx@gmail.com", "cry498434@gmail.com"].includes(userData.user.email || ""))) throw redirect({ to: "/dashboard" });
	},
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./dashboard.formulario-WHj0C7Q_.mjs");
var Route$23 = createFileRoute("/_authenticated/dashboard/formulario")({ component: lazyRouteComponent($$splitComponentImporter$23, "component") });
var $$splitComponentImporter$22 = () => import("./dashboard.dono-Bvty062r.mjs");
var Route$22 = createFileRoute("/_authenticated/dashboard/dono")({
	ssr: false,
	beforeLoad: async () => {
		const { data: userData } = await supabase.auth.getUser();
		if (!userData.user) throw redirect({
			to: "/auth",
			search: { mode: "login" }
		});
		const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userData.user.id);
		if (!(roles ?? []).some((r) => r.role === "owner")) throw redirect({ to: "/dashboard" });
	},
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./dashboard.avisos-DJZsYFPZ.mjs");
var Route$21 = createFileRoute("/_authenticated/dashboard/avisos")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("./dashboard.admin-DX5JtE7O.mjs");
var Route$20 = createFileRoute("/_authenticated/dashboard/admin")({
	ssr: false,
	beforeLoad: async () => {
		const { data: userData } = await supabase.auth.getUser();
		if (!userData.user) throw redirect({
			to: "/auth",
			search: { mode: "login" }
		});
		const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userData.user.id);
		if (!(roles ?? []).some((r) => r.role === "admin" || r.role === "owner")) throw redirect({ to: "/dashboard" });
	},
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./dashboard.master.index-DQKMOK-x.mjs");
var Route$19 = createFileRoute("/_authenticated/dashboard/master/")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("./dashboard.dono.index-B3mRcpKI.mjs");
var Route$18 = createFileRoute("/_authenticated/dashboard/dono/")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var $$splitComponentImporter$17 = () => import("./dashboard.admin.index-AFZW2nAH.mjs");
var Route$17 = createFileRoute("/_authenticated/dashboard/admin/")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./dashboard.master.users-DPezkevt.mjs");
var Route$16 = createFileRoute("/_authenticated/dashboard/master/users")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./dashboard.master.settings-DfZA6wfX.mjs");
var Route$15 = createFileRoute("/_authenticated/dashboard/master/settings")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./dashboard.master.security-DTzrg9ue.mjs");
var Route$14 = createFileRoute("/_authenticated/dashboard/master/security")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./dashboard.master.organizations-CJ3mWrbl.mjs");
var Route$13 = createFileRoute("/_authenticated/dashboard/master/organizations")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./dashboard.dono.repasses-BWRGzRjg.mjs");
var Route$12 = createFileRoute("/_authenticated/dashboard/dono/repasses")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./dashboard.dono.permissoes-6LDozQdn.mjs");
var Route$11 = createFileRoute("/_authenticated/dashboard/dono/permissoes")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./dashboard.dono.discord-bot-B8LXjFAr.mjs");
var Route$10 = createFileRoute("/_authenticated/dashboard/dono/discord-bot")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./dashboard.dono.database-kbpyujPv.mjs");
var Route$9 = createFileRoute("/_authenticated/dashboard/dono/database")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./dashboard.dono.auditoria-CKdVa1gE.mjs");
var Route$8 = createFileRoute("/_authenticated/dashboard/dono/auditoria")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./dashboard.admin.pagamentos-CGfFWXFI.mjs");
var Route$7 = createFileRoute("/_authenticated/dashboard/admin/pagamentos")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./dashboard.admin.membros-DKXfJ7eW.mjs");
var Route$6 = createFileRoute("/_authenticated/dashboard/admin/membros")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./dashboard.admin.formularios-PDvEG_8M.mjs");
var Route$5 = createFileRoute("/_authenticated/dashboard/admin/formularios")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./dashboard.admin.form-editor-DMgpgwYd.mjs");
var Route$4 = createFileRoute("/_authenticated/dashboard/admin/form-editor")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./dashboard.admin.feedback-Cm_nLSOI.mjs");
var Route$3 = createFileRoute("/_authenticated/dashboard/admin/feedback")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./dashboard.admin.documentos-DgZSv1Mn.mjs");
var Route$2 = createFileRoute("/_authenticated/dashboard/admin/documentos")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./dashboard.admin.cargos-C26e3BYf.mjs");
var Route$1 = createFileRoute("/_authenticated/dashboard/admin/cargos")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./dashboard.admin.avisos-BYhN2k3M.mjs");
var Route = createFileRoute("/_authenticated/dashboard/admin/avisos")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var AuthRoute = Route$30.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$29
});
var AuthenticatedRouteRoute = Route$28.update({
	id: "/_authenticated",
	getParentRoute: () => Route$29
});
var IndexRoute = Route$27.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$29
});
var AuthenticatedDashboardRoute = Route$31.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDashboardIndexRoute = Route$33.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardSocialRoute = Route$26.update({
	id: "/social",
	path: "/social",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardPerfilRoute = Route$34.update({
	id: "/perfil",
	path: "/perfil",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardPagamentosRoute = Route$25.update({
	id: "/pagamentos",
	path: "/pagamentos",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardMasterRoute = Route$24.update({
	id: "/master",
	path: "/master",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardFormularioRoute = Route$23.update({
	id: "/formulario",
	path: "/formulario",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardDonoRoute = Route$22.update({
	id: "/dono",
	path: "/dono",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardChatRoute = Route$32.update({
	id: "/chat",
	path: "/chat",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardAvisosRoute = Route$21.update({
	id: "/avisos",
	path: "/avisos",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardAdminRoute = Route$20.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedDashboardRoute
});
var AuthenticatedDashboardMasterIndexRoute = Route$19.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedDashboardMasterRoute
});
var AuthenticatedDashboardDonoIndexRoute = Route$18.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardAdminIndexRoute = Route$17.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardMasterUsersRoute = Route$16.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedDashboardMasterRoute
});
var AuthenticatedDashboardMasterSettingsRoute = Route$15.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedDashboardMasterRoute
});
var AuthenticatedDashboardMasterSecurityRoute = Route$14.update({
	id: "/security",
	path: "/security",
	getParentRoute: () => AuthenticatedDashboardMasterRoute
});
var AuthenticatedDashboardMasterOrganizationsRoute = Route$13.update({
	id: "/organizations",
	path: "/organizations",
	getParentRoute: () => AuthenticatedDashboardMasterRoute
});
var AuthenticatedDashboardDonoRepassesRoute = Route$12.update({
	id: "/repasses",
	path: "/repasses",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardDonoPermissoesRoute = Route$11.update({
	id: "/permissoes",
	path: "/permissoes",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardDonoDiscordBotRoute = Route$10.update({
	id: "/discord-bot",
	path: "/discord-bot",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardDonoDatabaseRoute = Route$9.update({
	id: "/database",
	path: "/database",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardDonoAuditoriaRoute = Route$8.update({
	id: "/auditoria",
	path: "/auditoria",
	getParentRoute: () => AuthenticatedDashboardDonoRoute
});
var AuthenticatedDashboardAdminPagamentosRoute = Route$7.update({
	id: "/pagamentos",
	path: "/pagamentos",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminMembrosRoute = Route$6.update({
	id: "/membros",
	path: "/membros",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminFormulariosRoute = Route$5.update({
	id: "/formularios",
	path: "/formularios",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminFormEditorRoute = Route$4.update({
	id: "/form-editor",
	path: "/form-editor",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminFeedbackRoute = Route$3.update({
	id: "/feedback",
	path: "/feedback",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminDocumentosRoute = Route$2.update({
	id: "/documentos",
	path: "/documentos",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminCargosRoute = Route$1.update({
	id: "/cargos",
	path: "/cargos",
	getParentRoute: () => AuthenticatedDashboardAdminRoute
});
var AuthenticatedDashboardAdminRouteChildren = {
	AuthenticatedDashboardAdminAvisosRoute: Route.update({
		id: "/avisos",
		path: "/avisos",
		getParentRoute: () => AuthenticatedDashboardAdminRoute
	}),
	AuthenticatedDashboardAdminCargosRoute,
	AuthenticatedDashboardAdminDocumentosRoute,
	AuthenticatedDashboardAdminFeedbackRoute,
	AuthenticatedDashboardAdminFormEditorRoute,
	AuthenticatedDashboardAdminFormulariosRoute,
	AuthenticatedDashboardAdminMembrosRoute,
	AuthenticatedDashboardAdminPagamentosRoute,
	AuthenticatedDashboardAdminIndexRoute
};
var AuthenticatedDashboardAdminRouteWithChildren = AuthenticatedDashboardAdminRoute._addFileChildren(AuthenticatedDashboardAdminRouteChildren);
var AuthenticatedDashboardDonoRouteChildren = {
	AuthenticatedDashboardDonoAuditoriaRoute,
	AuthenticatedDashboardDonoDatabaseRoute,
	AuthenticatedDashboardDonoDiscordBotRoute,
	AuthenticatedDashboardDonoPermissoesRoute,
	AuthenticatedDashboardDonoRepassesRoute,
	AuthenticatedDashboardDonoIndexRoute
};
var AuthenticatedDashboardDonoRouteWithChildren = AuthenticatedDashboardDonoRoute._addFileChildren(AuthenticatedDashboardDonoRouteChildren);
var AuthenticatedDashboardMasterRouteChildren = {
	AuthenticatedDashboardMasterOrganizationsRoute,
	AuthenticatedDashboardMasterSecurityRoute,
	AuthenticatedDashboardMasterSettingsRoute,
	AuthenticatedDashboardMasterUsersRoute,
	AuthenticatedDashboardMasterIndexRoute
};
var AuthenticatedDashboardRouteChildren = {
	AuthenticatedDashboardAdminRoute: AuthenticatedDashboardAdminRouteWithChildren,
	AuthenticatedDashboardAvisosRoute,
	AuthenticatedDashboardChatRoute,
	AuthenticatedDashboardDonoRoute: AuthenticatedDashboardDonoRouteWithChildren,
	AuthenticatedDashboardFormularioRoute,
	AuthenticatedDashboardMasterRoute: AuthenticatedDashboardMasterRoute._addFileChildren(AuthenticatedDashboardMasterRouteChildren),
	AuthenticatedDashboardPagamentosRoute,
	AuthenticatedDashboardPerfilRoute,
	AuthenticatedDashboardSocialRoute,
	AuthenticatedDashboardIndexRoute
};
var AuthenticatedRouteRouteChildren = { AuthenticatedDashboardRoute: AuthenticatedDashboardRoute._addFileChildren(AuthenticatedDashboardRouteChildren) };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AuthRoute
};
var routeTree = Route$29._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient({ defaultOptions: { queries: {
			staleTime: 3e4,
			gcTime: 5 * 6e4,
			refetchOnWindowFocus: false,
			refetchOnReconnect: "always",
			retry: 1
		} } }) },
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
