import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as malta_fox_default } from "./malta-fox-DqjZc_D7.mjs";
import { Ct as ArrowRight, ft as CircleCheck, ht as ChevronDown, lt as ClipboardList, t as Zap, xt as Bell } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bt0UcLRK.js
var import_jsx_runtime = require_jsx_runtime();
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground antialiased",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Benefits, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowItWorks, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCTA, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Nav() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-7 items-center justify-center rounded-md bg-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-3 rounded-full bg-background" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-base font-semibold tracking-tight sm:text-lg",
					children: "Malta Manager"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 sm:gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/auth",
					search: { mode: "login" },
					className: "rounded-md px-2 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground sm:px-3",
					children: "Entrar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/auth",
					search: { mode: "signup" },
					className: "rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground ring-1 ring-primary/60 transition-all hover:bg-primary-glow active:scale-[0.98] sm:px-4",
					children: "Cadastrar"
				})]
			})]
		})
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-16 sm:px-6 sm:py-24 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-10 sm:gap-16 lg:grid-cols-[1.2fr_0.8fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 sm:space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-widest text-muted-foreground",
							children: "Organização Malta"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "max-w-[20ch] text-balance text-3xl font-medium leading-tight tracking-tight sm:text-4xl md:text-5xl lg:text-6xl",
						children: [
							"A infraestrutura digital da",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "Organização Malta"
							}),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[52ch] text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg",
						children: "Substitua planilhas e formulários por uma plataforma profissional de gestão de membros. Transparência financeira e automação para a Malta."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth",
							search: { mode: "signup" },
							className: "inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground ring-1 ring-primary/60 transition-all hover:bg-primary-glow",
							children: ["Começar agora", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#como-funciona",
							className: "rounded-md bg-surface px-5 py-2.5 text-sm font-medium text-foreground ring-1 ring-border transition-colors hover:bg-surface-muted",
							children: "Como funciona"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-8 -z-10 rounded-full bg-primary/15 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative grid aspect-square w-full place-items-center rounded-3xl bg-surface ring-1 ring-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: malta_fox_default,
						alt: "Raposa Malta — mascote da Organização",
						width: 800,
						height: 800,
						className: "size-4/5 object-contain drop-shadow-[0_20px_60px_rgba(255,106,0,0.35)]"
					})
				})]
			})]
		})
	});
}
var benefits = [
	{
		icon: CircleCheck,
		title: "Pagamentos organizados",
		body: "Gestão automatizada de mensalidades com recibos e histórico transparente."
	},
	{
		icon: Zap,
		title: "Aprovações rápidas",
		body: "Fluxo otimizado para novos ingressos e validação de comprovantes em segundos."
	},
	{
		icon: ClipboardList,
		title: "Histórico completo",
		body: "Auditabilidade total de cada transação e mudança de status na organização."
	},
	{
		icon: Bell,
		title: "Notificações Discord",
		body: "Webhooks integrados para manter a comunidade informada em tempo real."
	}
];
function Benefits() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-surface/40 py-16 sm:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-10 sm:mb-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-primary sm:mb-4",
					children: "Benefícios"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xl font-medium tracking-tight sm:text-3xl md:text-4xl",
					children: "Tudo sob controle, em um só lugar."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: benefits.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-xl bg-background p-6 ring-1 ring-border transition-colors hover:ring-primary/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-9 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(b.icon, { className: "size-4 text-primary" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: b.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-pretty text-sm leading-relaxed text-muted-foreground",
							children: b.body
						})
					]
				}, b.title))
			})]
		})
	});
}
var steps = [
	{
		title: "Cadastro de Membro",
		body: "O interessado preenche os dados básicos e vincula sua identidade da Malta."
	},
	{
		title: "Aprovação Administrativa",
		body: "Líderes revisam a solicitação através de um painel intuitivo e ágil."
	},
	{
		title: "Acesso ao Ecossistema",
		body: "Liberação automática de permissões e ferramentas exclusivas da guilda."
	},
	{
		title: "Gestão e Pagamentos",
		body: "Acompanhamento mensal de status e envio de comprovantes via plataforma."
	}
];
function HowItWorks() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "como-funciona",
		className: "px-4 py-16 sm:px-6 sm:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-2 lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-8 text-2xl font-medium tracking-tight sm:mb-12 sm:text-3xl md:text-4xl",
					children: "Processo simplificado"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-10",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 font-mono text-sm font-medium tabular-nums text-primary",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "mb-2 font-medium",
							children: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-[42ch] text-sm text-muted-foreground",
							children: s.body
						})] })]
					}, s.title))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-[4/3] w-full overflow-hidden rounded-2xl bg-surface p-4 ring-1 ring-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full w-full flex-col rounded-lg bg-background ring-1 ring-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex h-10 items-center gap-2 border-b border-border px-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-muted" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-muted" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-muted" })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-1/3 rounded bg-muted" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-24 items-center justify-center rounded-lg bg-surface ring-1 ring-primary/25",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase tracking-widest text-primary",
											children: "Painel de Gestão"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 rounded bg-muted" })]
									})
								]
							})]
						})
					})
				})]
			})
		})
	});
}
var faq = [
	{
		q: "Como funciona a aprovação de novos membros?",
		a: "Após o cadastro, o administrador é notificado e revisa o perfil diretamente no painel de controle. O acesso completo é liberado assim que aprovado."
	},
	{
		q: "Posso enviar comprovantes de pagamento?",
		a: "Sim. Aceitamos PNG, JPG e PDF. Os comprovantes ficam no seu histórico e são validados pelos administradores."
	},
	{
		q: "O sistema envia avisos de vencimento?",
		a: "Sim, notificações automáticas via Discord e no próprio painel antes e após o vencimento."
	},
	{
		q: "Quem tem acesso aos meus dados?",
		a: "Apenas você e os administradores da Malta. Todos os dados ficam protegidos por regras de segurança em nível de banco."
	},
	{
		q: "É possível integrar com o Discord?",
		a: "Sim. Webhooks nativos disparam notificações em canais escolhidos para cadastros, pagamentos e avisos."
	}
];
function FAQ() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-surface/40 py-16 sm:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-8 text-center text-2xl font-medium tracking-tight sm:mb-12 sm:text-3xl md:text-4xl",
				children: "Perguntas Frequentes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-border",
				children: faq.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "flex cursor-pointer list-none items-center justify-between text-left font-medium text-foreground",
						children: [item.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted-foreground transition-transform group-open:rotate-180" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted-foreground",
						children: item.a
					})]
				}, item.q))
			})]
		})
	});
}
function FinalCTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "px-4 py-20 sm:px-6 sm:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-4xl overflow-hidden rounded-3xl bg-primary p-6 text-center sm:p-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.25),transparent_60%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 space-y-6 sm:space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-balance text-3xl font-medium tracking-tight text-primary-foreground sm:text-4xl md:text-5xl",
						children: "Pronto para organizar a Malta?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto max-w-[44ch] text-pretty text-base text-primary-foreground/85 sm:text-lg",
						children: "Junte-se aos membros que já utilizam o Malta Manager diariamente."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth",
							search: { mode: "signup" },
							className: "rounded-full bg-background px-6 py-3 text-sm font-semibold text-primary transition-transform hover:scale-105 sm:px-8 sm:text-base",
							children: "Cadastrar agora"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth",
							search: { mode: "login" },
							className: "rounded-full border border-primary-foreground/30 bg-black/10 px-6 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-black/20 sm:px-8 sm:text-base",
							children: "Já sou membro"
						})]
					})
				]
			})]
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border py-10 sm:py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 sm:px-6 md:flex-row",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-5 items-center justify-center rounded-sm bg-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-2 rounded-full bg-background" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Malta Manager"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://discord.gg/orgmalta",
						target: "_blank",
						rel: "noopener noreferrer",
						className: "text-xs text-muted-foreground transition-colors hover:text-foreground",
						children: "Discord"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground text-center",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Organização Malta.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Desenvolvido por ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-primary",
							children: "Cryand"
						}),
						"."
					]
				})
			]
		})
	});
}
//#endregion
export { Landing as component };
