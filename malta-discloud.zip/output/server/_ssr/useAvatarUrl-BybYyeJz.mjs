import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D8gVtBRg.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useAvatarUrl-BybYyeJz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var cache = /* @__PURE__ */ new Map();
function normalizeAvatarPath(path) {
	const clean = path.trim();
	if (!clean) return clean;
	if (clean.startsWith("http://") || clean.startsWith("https://") || clean.startsWith("blob:") || clean.startsWith("data:")) return clean;
	const withoutQuery = clean.split("?")[0].replace(/^\/+/, "");
	const markerIndex = withoutQuery.indexOf("/avatars/");
	if (markerIndex >= 0) return withoutQuery.slice(markerIndex + 9);
	if (withoutQuery.startsWith("avatars/")) return withoutQuery.slice(8);
	return withoutQuery;
}
function useAvatarUrl(path) {
	const normalizedPath = path ? normalizeAvatarPath(path) : null;
	const isFullUrl = !!normalizedPath && (normalizedPath.startsWith("http://") || normalizedPath.startsWith("https://") || normalizedPath.startsWith("blob:") || normalizedPath.startsWith("data:"));
	const [url, setUrl] = (0, import_react.useState)(() => {
		if (!normalizedPath) return null;
		if (isFullUrl) return normalizedPath;
		const c = cache.get(normalizedPath);
		return c && c.expiresAt > Date.now() ? c.url : null;
	});
	(0, import_react.useEffect)(() => {
		if (!normalizedPath) {
			setUrl(null);
			return;
		}
		if (isFullUrl) {
			setUrl(normalizedPath);
			return;
		}
		const cached = cache.get(normalizedPath);
		if (cached && cached.expiresAt > Date.now()) {
			setUrl(cached.url);
			return;
		}
		let cancelled = false;
		supabase.storage.from("avatars").createSignedUrl(normalizedPath, 3600).then(({ data, error }) => {
			if (cancelled) return;
			if (data?.signedUrl) {
				cache.set(normalizedPath, {
					url: data.signedUrl,
					expiresAt: Date.now() + 3300 * 1e3
				});
				setUrl(data.signedUrl);
				return;
			}
			if (error) {
				const { data: publicData } = supabase.storage.from("avatars").getPublicUrl(normalizedPath);
				setUrl(publicData.publicUrl || null);
			}
		});
		return () => {
			cancelled = true;
		};
	}, [normalizedPath, isFullUrl]);
	return url;
}
//#endregion
export { useAvatarUrl as t };
