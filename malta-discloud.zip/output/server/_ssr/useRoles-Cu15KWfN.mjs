import { t as supabase } from "./client-D8gVtBRg.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useRoles-Cu15KWfN.js
function useRoles(userId) {
	return useQuery({
		queryKey: ["roles", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId);
			if (error) throw error;
			return (data ?? []).map((r) => r.role);
		}
	});
}
function computeRoleFlags(roles) {
	const set = new Set(roles ?? []);
	return {
		isOwner: set.has("owner"),
		isStaff: set.has("owner") || set.has("admin"),
		primary: set.has("owner") ? "owner" : set.has("admin") ? "admin" : "member"
	};
}
//#endregion
export { useRoles as n, computeRoleFlags as t };
