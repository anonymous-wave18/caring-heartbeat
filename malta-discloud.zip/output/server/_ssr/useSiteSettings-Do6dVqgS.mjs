import { t as supabase } from "./client-D8gVtBRg.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useSiteSettings-Do6dVqgS.js
function useSiteSettings() {
	return useQuery({
		queryKey: ["site_settings"],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
}
function formatBRL(v) {
	const n = typeof v === "string" ? Number(v) : v ?? 0;
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL"
	}).format(n);
}
//#endregion
export { useSiteSettings as n, formatBRL as t };
