//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bn5bYiTq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth"
		],
		preloads: [
			"/assets/index-9_TV9Lc9.js",
			"/assets/jsx-runtime-C27Mmbu5.js",
			"/assets/useStore-CZcVHC41.js",
			"/assets/link-DvysJUnA.js",
			"/assets/matchContext-BemegkUg.js",
			"/assets/useRouter-C3rM-XLx.js",
			"/assets/utils-Dh2UFsYh.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/redirect-C-eRQtnH.js",
			"/assets/react-dom-BGozS2fx.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9_TV9Lc9.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DxjKbNWr.js",
			"/assets/createLucideIcon-CgQsGnsD.js",
			"/assets/arrow-right-DIQm28Rp.js",
			"/assets/bell-bRfhknxw.js",
			"/assets/chevron-down-Dh53Cu9c.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/malta-fox-u1dD8LCk.js"
		]
	},
	"/_authenticated": {
		filePath: "/dev-server/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/dashboard"],
		preloads: ["/assets/route-CGjv_PIP.js"]
	},
	"/auth": {
		filePath: "/dev-server/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C94GozlQ.js",
			"/assets/arrow-left-Djj_nb7V.js",
			"/assets/loader-circle-C1u2nneP.js",
			"/assets/malta-fox-u1dD8LCk.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.tsx",
		children: [
			"/_authenticated/dashboard/admin",
			"/_authenticated/dashboard/avisos",
			"/_authenticated/dashboard/chat",
			"/_authenticated/dashboard/dono",
			"/_authenticated/dashboard/formulario",
			"/_authenticated/dashboard/master",
			"/_authenticated/dashboard/pagamentos",
			"/_authenticated/dashboard/perfil",
			"/_authenticated/dashboard/social",
			"/_authenticated/dashboard/"
		],
		preloads: [
			"/assets/dashboard-pP0LmbjT.js",
			"/assets/useQuery-DKElqIXc.js",
			"/assets/useRouterState-DqdRkdCz.js",
			"/assets/createLucideIcon-CgQsGnsD.js",
			"/assets/bell-bRfhknxw.js",
			"/assets/credit-card-0YGM-cRo.js",
			"/assets/crown-CHbmVNRT.js",
			"/assets/file-text-6AtoPffW.js",
			"/assets/globe-BUyyEp3F.js",
			"/assets/layout-dashboard-DjSNbVPP.js",
			"/assets/loader-circle-C1u2nneP.js",
			"/assets/log-out-B6LTges-.js",
			"/assets/megaphone-B0jPr3On.js",
			"/assets/menu-G0Fub84W.js",
			"/assets/message-square-DpHjjFlg.js",
			"/assets/shield-check-BkKPZRT-.js",
			"/assets/sparkles-Bbdae7iX.js",
			"/assets/users-4ZYb9_cZ.js",
			"/assets/x-DtNyKRYb.js",
			"/assets/useAvatarUrl-B9gnHust.js",
			"/assets/useRoles-BWj53eMr.js"
		]
	},
	"/_authenticated/dashboard/admin": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.tsx",
		children: [
			"/_authenticated/dashboard/admin/avisos",
			"/_authenticated/dashboard/admin/cargos",
			"/_authenticated/dashboard/admin/documentos",
			"/_authenticated/dashboard/admin/feedback",
			"/_authenticated/dashboard/admin/form-editor",
			"/_authenticated/dashboard/admin/formularios",
			"/_authenticated/dashboard/admin/membros",
			"/_authenticated/dashboard/admin/pagamentos",
			"/_authenticated/dashboard/admin/"
		],
		preloads: ["/assets/dashboard.admin-BYv4_aHY.js", "/assets/settings-2-CGrW06gX.js"]
	},
	"/_authenticated/dashboard/avisos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.avisos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.avisos-BEqJyMO8.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/pin-ChZxHqoz.js"
		]
	},
	"/_authenticated/dashboard/chat": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.chat.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.chat-CS8Xu7ig.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/arrow-left-Djj_nb7V.js",
			"/assets/send-B0h4e530.js",
			"/assets/shield-DCGtAdDK.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/publicProfiles-BrEE0Mg2.js"
		]
	},
	"/_authenticated/dashboard/dono": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.tsx",
		children: [
			"/_authenticated/dashboard/dono/auditoria",
			"/_authenticated/dashboard/dono/database",
			"/_authenticated/dashboard/dono/discord-bot",
			"/_authenticated/dashboard/dono/permissoes",
			"/_authenticated/dashboard/dono/repasses",
			"/_authenticated/dashboard/dono/"
		],
		preloads: [
			"/assets/dashboard.dono-C8Z7J5hA.js",
			"/assets/bot-CDwSE5T1.js",
			"/assets/database-B-97DiuO.js",
			"/assets/settings-DYm6gAc3.js"
		]
	},
	"/_authenticated/dashboard/formulario": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.formulario.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.formulario-DqEWhP8m.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/circle-x-VvZrIjZ8.js",
			"/assets/clock-uhYAMG5o.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/upload-CPKsUoYX.js",
			"/assets/formConfig-C9bqbLhL.js",
			"/assets/masks-ZJYQMQcQ.js"
		]
	},
	"/_authenticated/dashboard/master": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.tsx",
		children: [
			"/_authenticated/dashboard/master/organizations",
			"/_authenticated/dashboard/master/security",
			"/_authenticated/dashboard/master/settings",
			"/_authenticated/dashboard/master/users",
			"/_authenticated/dashboard/master/"
		],
		preloads: ["/assets/dashboard.master-QNsefNHx.js", "/assets/settings-DYm6gAc3.js"]
	},
	"/_authenticated/dashboard/pagamentos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.pagamentos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.pagamentos-B5TxYXqx.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/circle-alert-58izOU0i.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/clock-uhYAMG5o.js",
			"/assets/upload-CPKsUoYX.js",
			"/assets/masks-ZJYQMQcQ.js",
			"/assets/useSiteSettings-k-dGa_mH.js"
		]
	},
	"/_authenticated/dashboard/perfil": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.perfil.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.perfil-BX1710_b.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/message-circle-L-33ki1U.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/send-B0h4e530.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/upload-CPKsUoYX.js",
			"/assets/publicProfiles-BrEE0Mg2.js"
		]
	},
	"/_authenticated/dashboard/social": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.social.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.social-B74lp0V6.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/message-circle-L-33ki1U.js",
			"/assets/send-B0h4e530.js",
			"/assets/user-plus-BkSOgZcS.js",
			"/assets/publicProfiles-BrEE0Mg2.js"
		]
	},
	"/_authenticated/dashboard/": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.index.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.index-DwiV-SWE.js",
			"/assets/arrow-right-DIQm28Rp.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/circle-x-VvZrIjZ8.js",
			"/assets/clock-uhYAMG5o.js",
			"/assets/malta-fox-u1dD8LCk.js",
			"/assets/useSiteSettings-k-dGa_mH.js"
		]
	},
	"/_authenticated/dashboard/admin/avisos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.avisos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.avisos-ChryONyp.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/pin-ChZxHqoz.js",
			"/assets/plus-5gOMkH_D.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/admin.functions-BOW_m_DA.js"
		]
	},
	"/_authenticated/dashboard/admin/cargos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.cargos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.cargos--gAu3YCH.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/check-CrDZetXF.js",
			"/assets/pencil-CFs_tpmH.js",
			"/assets/plus-5gOMkH_D.js",
			"/assets/trash-2-CU1Ye6Hg.js"
		]
	},
	"/_authenticated/dashboard/admin/documentos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.documentos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.documentos-Q1g20_5o.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/admin.functions-BOW_m_DA.js"
		]
	},
	"/_authenticated/dashboard/admin/feedback": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.feedback.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.feedback-BJ7c-x6h.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/circle-x-VvZrIjZ8.js",
			"/assets/trash-2-CU1Ye6Hg.js"
		]
	},
	"/_authenticated/dashboard/admin/form-editor": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.form-editor.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.form-editor-CS-oxKuP.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/plus-5gOMkH_D.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/formConfig-C9bqbLhL.js"
		]
	},
	"/_authenticated/dashboard/admin/formularios": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.formularios.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.formularios-XsJwDNfW.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/check-CrDZetXF.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/eye-Cn7vwqk6.js",
			"/assets/admin.functions-BOW_m_DA.js"
		]
	},
	"/_authenticated/dashboard/admin/membros": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.membros.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.membros-CyF_V4zg.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/search-s3C4vtuy.js"
		]
	},
	"/_authenticated/dashboard/admin/pagamentos": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.pagamentos.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.pagamentos-bIJWRE9x.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/check-CrDZetXF.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/admin.functions-BOW_m_DA.js",
			"/assets/useSiteSettings-k-dGa_mH.js"
		]
	},
	"/_authenticated/dashboard/dono/auditoria": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.auditoria.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.dono.auditoria-CydIAYi-.js",
			"/assets/chevron-down-Dh53Cu9c.js",
			"/assets/circle-alert-58izOU0i.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/circle-x-VvZrIjZ8.js",
			"/assets/clock-uhYAMG5o.js",
			"/assets/dollar-sign-CGauU7Ll.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/eye-Cn7vwqk6.js",
			"/assets/pencil-CFs_tpmH.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/send-B0h4e530.js",
			"/assets/trash-2-CU1Ye6Hg.js",
			"/assets/user-plus-BkSOgZcS.js"
		]
	},
	"/_authenticated/dashboard/dono/database": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.database.tsx",
		children: void 0,
		preloads: ["/assets/dashboard.dono.database-zofyl32e.js", "/assets/info-Be5vqIbQ.js"]
	},
	"/_authenticated/dashboard/dono/discord-bot": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.discord-bot.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.dono.discord-bot-ByLTmCRg.js",
			"/assets/dialog-2bWBlmhu.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/auth-middleware-Q7I-rUAt.js",
			"/assets/check-CrDZetXF.js",
			"/assets/chevron-down-Dh53Cu9c.js",
			"/assets/circle-alert-58izOU0i.js",
			"/assets/circle-check-CqbNFOPt.js",
			"/assets/circle-x-VvZrIjZ8.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/send-B0h4e530.js"
		]
	},
	"/_authenticated/dashboard/dono/permissoes": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.permissoes.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.dono.permissoes-_1EGacvW.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/search-s3C4vtuy.js"
		]
	},
	"/_authenticated/dashboard/dono/repasses": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.repasses.tsx",
		children: void 0,
		preloads: ["/assets/dashboard.dono.repasses-CKuKU8xJ.js", "/assets/useSiteSettings-k-dGa_mH.js"]
	},
	"/_authenticated/dashboard/master/organizations": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.organizations.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.master.organizations-DLdTAz6a.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/dollar-sign-CGauU7Ll.js",
			"/assets/info-Be5vqIbQ.js",
			"/assets/plus-5gOMkH_D.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/trash-2-CU1Ye6Hg.js"
		]
	},
	"/_authenticated/dashboard/master/security": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.security.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.master.security-DIis9q-z.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/shield-DCGtAdDK.js"
		]
	},
	"/_authenticated/dashboard/master/settings": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.master.settings-DHW4WCCn.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/settings-2-CGrW06gX.js"
		]
	},
	"/_authenticated/dashboard/master/users": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.users.tsx",
		children: void 0,
		preloads: ["/assets/dashboard.master.users-BoyZiI5E.js", "/assets/search-s3C4vtuy.js"]
	},
	"/_authenticated/dashboard/admin/": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.admin.index-DHrYAeJW.js",
			"/assets/dialog-2bWBlmhu.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/check-CrDZetXF.js",
			"/assets/download-Ceizt0fb.js",
			"/assets/file-check-C7LWKwqh.js",
			"/assets/search-s3C4vtuy.js",
			"/assets/trash-2-CU1Ye6Hg.js"
		]
	},
	"/_authenticated/dashboard/dono/": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.dono.index.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard.dono.index-BrOpHlm6.js",
			"/assets/useMutation-Bz5JZYmC.js",
			"/assets/file-check-C7LWKwqh.js",
			"/assets/save-BLFTnj-q.js",
			"/assets/useSiteSettings-k-dGa_mH.js"
		]
	},
	"/_authenticated/dashboard/master/": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.master.index.tsx",
		children: void 0,
		preloads: ["/assets/dashboard.master.index-CTV34MEz.js"]
	}
} });
//#endregion
export { tsrStartManifest };
