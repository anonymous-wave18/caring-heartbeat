globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"1a0c1-BR+5eMBUbFf9fjv0ZolqwNP8p6Q\"",
		"mtime": "2026-07-31T22:16:29.288Z",
		"size": 106689,
		"path": "../public/favicon.ico"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"1a0c1-BR+5eMBUbFf9fjv0ZolqwNP8p6Q\"",
		"mtime": "2026-07-31T22:16:29.288Z",
		"size": 106689,
		"path": "../public/favicon.png"
	},
	"/assets/arrow-left-Djj_nb7V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-AvFks8bOIJcisJjXxTLreah+RRQ\"",
		"mtime": "2026-07-31T22:16:26.206Z",
		"size": 165,
		"path": "../public/assets/arrow-left-Djj_nb7V.js"
	},
	"/assets/auth-C94GozlQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2391-9vKCJyQP17XYdwhG7x4+skMqihI\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 9105,
		"path": "../public/assets/auth-C94GozlQ.js"
	},
	"/assets/bell-bRfhknxw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-mfDwnE2aOfwG8cJD0wcdDrriyiU\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 290,
		"path": "../public/assets/bell-bRfhknxw.js"
	},
	"/assets/check-CrDZetXF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-Pa3k61UsWr7lCphfv7OnivnQ4fo\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 124,
		"path": "../public/assets/check-CrDZetXF.js"
	},
	"/assets/circle-alert-58izOU0i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-R2g9cClgl3YIL0bTIUfMVtV9QGw\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 250,
		"path": "../public/assets/circle-alert-58izOU0i.js"
	},
	"/assets/chevron-down-Dh53Cu9c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-L4PucWVef26GE9E3s+CG8Hrd37E\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 128,
		"path": "../public/assets/chevron-down-Dh53Cu9c.js"
	},
	"/assets/clock-uhYAMG5o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-IN4AxxHtCta034BPGu+d/i7rcOk\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 169,
		"path": "../public/assets/clock-uhYAMG5o.js"
	},
	"/assets/circle-check-CqbNFOPt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-FKcoz8/eFkYg9v28M5ATnEkqxNE\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 178,
		"path": "../public/assets/circle-check-CqbNFOPt.js"
	},
	"/assets/circle-x-VvZrIjZ8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-FS+ddfcTFtN/03MWvCvRjxxcQ1k\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 207,
		"path": "../public/assets/circle-x-VvZrIjZ8.js"
	},
	"/assets/createLucideIcon-CgQsGnsD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-tc3f1UwoevNSHFUTu909Kjpq0mI\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-CgQsGnsD.js"
	},
	"/assets/credit-card-0YGM-cRo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-5hqPsnMGgQciUJb1pmtjAieFBQY\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 207,
		"path": "../public/assets/credit-card-0YGM-cRo.js"
	},
	"/assets/crown-CHbmVNRT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a-6KJt/fq1dJCH4W7GeBJakpheJu0\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 362,
		"path": "../public/assets/crown-CHbmVNRT.js"
	},
	"/assets/dashboard.admin-BYv4_aHY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bde-BcH0gRot1G03JTNvNMLcokokxtE\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 3038,
		"path": "../public/assets/dashboard.admin-BYv4_aHY.js"
	},
	"/assets/dashboard.admin.avisos-ChryONyp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1154-FP6U8XG22EHjgElqYIo4AgoJiR8\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 4436,
		"path": "../public/assets/dashboard.admin.avisos-ChryONyp.js"
	},
	"/assets/dashboard-pP0LmbjT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20aa-bKN+1FF38VqHKG8/TVAHuGsW1gs\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 8362,
		"path": "../public/assets/dashboard-pP0LmbjT.js"
	},
	"/assets/dashboard.admin.cargos--gAu3YCH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c4c-Y8oftxeavH6hLb2m+ggsnBxTIg4\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 7244,
		"path": "../public/assets/dashboard.admin.cargos--gAu3YCH.js"
	},
	"/assets/auth-middleware-Q7I-rUAt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116b-7yuzfzdpVM/+Ysqg0ULVCELTplw\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 4459,
		"path": "../public/assets/auth-middleware-Q7I-rUAt.js"
	},
	"/assets/dashboard.admin.documentos-Q1g20_5o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d6-ErCDNECSF1R3yhiNOC8X7FSJlNs\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 5078,
		"path": "../public/assets/dashboard.admin.documentos-Q1g20_5o.js"
	},
	"/assets/admin.functions-BOW_m_DA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b3-YCVbfmnNH2nqTKyGctpUxaizE7g\"",
		"mtime": "2026-07-31T22:16:26.206Z",
		"size": 947,
		"path": "../public/assets/admin.functions-BOW_m_DA.js"
	},
	"/assets/dashboard.admin.feedback-BJ7c-x6h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"152f-ahHj6SIM6CZvs6dLmq6hxCh4IFs\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 5423,
		"path": "../public/assets/dashboard.admin.feedback-BJ7c-x6h.js"
	},
	"/manifest.json": {
		"type": "application/json",
		"etag": "\"245-yAl7MIO+8l2/KoBsAWDqjENnW/Y\"",
		"mtime": "2026-07-31T22:16:29.288Z",
		"size": 581,
		"path": "../public/manifest.json"
	},
	"/assets/bot-CDwSE5T1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-7suJpAsja8EcaqSPNKl7dXPP73A\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 328,
		"path": "../public/assets/bot-CDwSE5T1.js"
	},
	"/assets/arrow-right-DIQm28Rp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-4Xzvtp1gIGFV9tVfIfi+h2mQ2Dk\"",
		"mtime": "2026-07-31T22:16:26.207Z",
		"size": 165,
		"path": "../public/assets/arrow-right-DIQm28Rp.js"
	},
	"/assets/dashboard.admin.form-editor-CS-oxKuP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b65-47ugLVk0dj0ACw6T0ixaSm1YZb0\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 11109,
		"path": "../public/assets/dashboard.admin.form-editor-CS-oxKuP.js"
	},
	"/assets/dashboard.admin.formularios-XsJwDNfW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ae8-LT7y6YkLX9uZ78TQP589uMo+6Z4\"",
		"mtime": "2026-07-31T22:16:26.208Z",
		"size": 10984,
		"path": "../public/assets/dashboard.admin.formularios-XsJwDNfW.js"
	},
	"/assets/dashboard.admin.membros-CyF_V4zg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147a-+Oz+t8BHP5TY0vZes8EbXax7J5U\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 5242,
		"path": "../public/assets/dashboard.admin.membros-CyF_V4zg.js"
	},
	"/assets/dashboard.admin.pagamentos-bIJWRE9x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d6e-aSeenFYZ9njZF/4OnCAnfZ0Taos\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 7534,
		"path": "../public/assets/dashboard.admin.pagamentos-bIJWRE9x.js"
	},
	"/assets/dashboard.admin.index-DHrYAeJW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"682a0-S9md/5gOt0d6TV+gwLZVuRfwdmg\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 426656,
		"path": "../public/assets/dashboard.admin.index-DHrYAeJW.js"
	},
	"/assets/dashboard.avisos-BEqJyMO8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bff-JL8hRRjQ6zWzmGyuQL9QP/mGUOQ\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 3071,
		"path": "../public/assets/dashboard.avisos-BEqJyMO8.js"
	},
	"/assets/dashboard.chat-CS8Xu7ig.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48bd-x1g9dheTyN6LfeeGuQewBrdxyIM\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 18621,
		"path": "../public/assets/dashboard.chat-CS8Xu7ig.js"
	},
	"/assets/dashboard.dono-C8Z7J5hA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"93c-EUYjnyZxGPMWrjP4UhuD8U9A37E\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 2364,
		"path": "../public/assets/dashboard.dono-C8Z7J5hA.js"
	},
	"/assets/dashboard.dono.auditoria-CydIAYi-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2efb-udGX0whJo74GWTRbW7iwJXk5u/M\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 12027,
		"path": "../public/assets/dashboard.dono.auditoria-CydIAYi-.js"
	},
	"/assets/dashboard.dono.permissoes-_1EGacvW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fca-a3BFkqxD99TU7YkeQ1YyccrMjGw\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 4042,
		"path": "../public/assets/dashboard.dono.permissoes-_1EGacvW.js"
	},
	"/assets/dashboard.dono.index-BrOpHlm6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19b3-aYnPq3nBViF9YiT7MrUVdGwCiv4\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 6579,
		"path": "../public/assets/dashboard.dono.index-BrOpHlm6.js"
	},
	"/assets/dashboard.dono.database-zofyl32e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181e-CGnOowyQIPuhb5af8TAbVN4xGEs\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 6174,
		"path": "../public/assets/dashboard.dono.database-zofyl32e.js"
	},
	"/assets/dashboard.dono.repasses-CKuKU8xJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c39-/MfWo7td8F34bdoVMGHDo503seo\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 3129,
		"path": "../public/assets/dashboard.dono.repasses-CKuKU8xJ.js"
	},
	"/assets/dashboard.master.organizations-DLdTAz6a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2956-Q/OtGvPdEBL4NLEzbHmUS1VSY5Y\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 10582,
		"path": "../public/assets/dashboard.master.organizations-DLdTAz6a.js"
	},
	"/assets/dashboard.master-QNsefNHx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b7-dpaKU+bythH+nJZh4r+u3WYuplY\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 2231,
		"path": "../public/assets/dashboard.master-QNsefNHx.js"
	},
	"/assets/dashboard.master.users-BoyZiI5E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a66-5ieCIc3Ns8zIoYLy34bkZ62Dnec\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 2662,
		"path": "../public/assets/dashboard.master.users-BoyZiI5E.js"
	},
	"/assets/dashboard.index-DwiV-SWE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24c0-hUizmKgQYmdtabGQaDGY6wKfEOs\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 9408,
		"path": "../public/assets/dashboard.index-DwiV-SWE.js"
	},
	"/assets/dashboard.master.security-DIis9q-z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2d-PsVzGTJKdR9uuZm9wBHPv6u697s\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 2605,
		"path": "../public/assets/dashboard.master.security-DIis9q-z.js"
	},
	"/assets/dashboard.perfil-BX1710_b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"655f-PhLxNPLKT6f19TSi1jX+UlJwSyE\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 25951,
		"path": "../public/assets/dashboard.perfil-BX1710_b.js"
	},
	"/assets/dashboard.social-B74lp0V6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29c9-Td/A1C6sNc0MAhGfpcR/yQy4H3g\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 10697,
		"path": "../public/assets/dashboard.social-B74lp0V6.js"
	},
	"/assets/dashboard.master.settings-DHW4WCCn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"add-ppodEQ8wkhem0Nw0GL1ghgMGN/o\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 2781,
		"path": "../public/assets/dashboard.master.settings-DHW4WCCn.js"
	},
	"/assets/dashboard.master.index-CTV34MEz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11db-EYujatakmefokqmJJERjvT2+qDY\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 4571,
		"path": "../public/assets/dashboard.master.index-CTV34MEz.js"
	},
	"/assets/dashboard.dono.discord-bot-ByLTmCRg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d59-njmmIWauOT+XpxTA3fd5fkt8Tn0\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 81241,
		"path": "../public/assets/dashboard.dono.discord-bot-ByLTmCRg.js"
	},
	"/assets/dashboard.formulario-DqEWhP8m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4344-AKP0Oh/GXgFZ0gX0XxqP+XKC3mA\"",
		"mtime": "2026-07-31T22:16:26.209Z",
		"size": 17220,
		"path": "../public/assets/dashboard.formulario-DqEWhP8m.js"
	},
	"/assets/dashboard.pagamentos-B5TxYXqx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fbc-YgERIwhwiYQPCb7nMJIwp3hykQ4\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 8124,
		"path": "../public/assets/dashboard.pagamentos-B5TxYXqx.js"
	},
	"/assets/dollar-sign-CGauU7Ll.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db-HSaHr1UyerzSo5QuAPu3B9UpiF8\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 219,
		"path": "../public/assets/dollar-sign-CGauU7Ll.js"
	},
	"/assets/database-B-97DiuO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3-ewJkCo+L2/smab84Vvk5c49odA8\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 243,
		"path": "../public/assets/database-B-97DiuO.js"
	},
	"/assets/download-Ceizt0fb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-mMvQXXhE14KHnMhe31GhiuuW+HE\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 232,
		"path": "../public/assets/download-Ceizt0fb.js"
	},
	"/assets/eye-Cn7vwqk6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-ah3rBQjm7GKW0gixIhmkwLX8yaw\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 256,
		"path": "../public/assets/eye-Cn7vwqk6.js"
	},
	"/assets/dialog-2bWBlmhu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb93-EdrBjDdf4GN01zeN4y53DeiKr28\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 64403,
		"path": "../public/assets/dialog-2bWBlmhu.js"
	},
	"/assets/file-check-C7LWKwqh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-UL385ygiUeqtCiQV7kme+vdXVec\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 318,
		"path": "../public/assets/file-check-C7LWKwqh.js"
	},
	"/assets/file-text-6AtoPffW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-W8aD2zTrN7Aw3BDWl3Pll194N8M\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 385,
		"path": "../public/assets/file-text-6AtoPffW.js"
	},
	"/assets/globe-BUyyEp3F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f2-Vkdy6JyDbtJlJFCapomxHB+zNMc\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 242,
		"path": "../public/assets/globe-BUyyEp3F.js"
	},
	"/assets/info-Be5vqIbQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc-o8XK31LJ3YzHEKRiWmxbUAUu/2E\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 204,
		"path": "../public/assets/info-Be5vqIbQ.js"
	},
	"/assets/invariant-DEEwAagU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-eVh/3DMi1s3cxf4N/OJar+ew1jA\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 60,
		"path": "../public/assets/invariant-DEEwAagU.js"
	},
	"/assets/formConfig-C9bqbLhL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"964-z4W4Xwcaujt2EtXXUf/uD3I/8nI\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 2404,
		"path": "../public/assets/formConfig-C9bqbLhL.js"
	},
	"/assets/log-out-B6LTges-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-B6+CJ/RX7+guRYgDdu/uVMpHPV0\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 230,
		"path": "../public/assets/log-out-B6LTges-.js"
	},
	"/assets/malta-fox-u1dD8LCk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36-tvSWEFO6L+pqbpR7U5vrKqRY4sU\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 54,
		"path": "../public/assets/malta-fox-u1dD8LCk.js"
	},
	"/assets/jsx-runtime-C27Mmbu5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2157-K7z7JulAsA1EGRDTmPYOvz5HqGU\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 8535,
		"path": "../public/assets/jsx-runtime-C27Mmbu5.js"
	},
	"/assets/loader-circle-C1u2nneP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-DxLtqQZUvhn8UrMH9+S9EQP2QpA\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 144,
		"path": "../public/assets/loader-circle-C1u2nneP.js"
	},
	"/assets/layout-dashboard-DjSNbVPP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15f-fYUDvksle7ho9wjtV4D2X3C0cKA\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 351,
		"path": "../public/assets/layout-dashboard-DjSNbVPP.js"
	},
	"/assets/masks-ZJYQMQcQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24e-VwHCYNDlWXiK6wmKVt1GTRDBWX4\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 590,
		"path": "../public/assets/masks-ZJYQMQcQ.js"
	},
	"/assets/matchContext-BemegkUg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2-Mi20qSpKcp+Q1ynsLnKHIF3IS2I\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 162,
		"path": "../public/assets/matchContext-BemegkUg.js"
	},
	"/assets/megaphone-B0jPr3On.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15a-p+pzwaav76MeZPZdqm1BZ0RICWI\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 346,
		"path": "../public/assets/megaphone-B0jPr3On.js"
	},
	"/assets/link-DvysJUnA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116a-vDvyVVsaPc+WuAE1+uN4QVrYhjw\"",
		"mtime": "2026-07-31T22:16:26.210Z",
		"size": 4458,
		"path": "../public/assets/link-DvysJUnA.js"
	},
	"/assets/menu-G0Fub84W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-J9+L1TEE3cJdbrLqCPlP3Ur7K8k\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 189,
		"path": "../public/assets/menu-G0Fub84W.js"
	},
	"/assets/message-square-DpHjjFlg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-Ww81cS2VVipYT2fzq2isZNwXH4o\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 233,
		"path": "../public/assets/message-square-DpHjjFlg.js"
	},
	"/assets/message-circle-L-33ki1U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1be-fd+WXSfjW8ntXonb4g5Tm9xivZw\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 446,
		"path": "../public/assets/message-circle-L-33ki1U.js"
	},
	"/assets/index-9_TV9Lc9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97ebf-nYFT4z3bMYTxhkd+3GMTXpE7Y6A\"",
		"mtime": "2026-07-31T22:16:26.206Z",
		"size": 622271,
		"path": "../public/assets/index-9_TV9Lc9.js"
	},
	"/assets/malta-fox-DCGzdn13.png": {
		"type": "image/png",
		"etag": "\"b2f9b-XEmIDilF3wRiGzMfXM30GgdwwcE\"",
		"mtime": "2026-07-31T22:16:26.213Z",
		"size": 733083,
		"path": "../public/assets/malta-fox-DCGzdn13.png"
	},
	"/assets/pencil-CFs_tpmH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-wC0SDYZ6KhMGOq/ykJg0NgfIV3c\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 276,
		"path": "../public/assets/pencil-CFs_tpmH.js"
	},
	"/assets/publicProfiles-BrEE0Mg2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38f-itQeQeLf0h7uY/vgshd1LZjhurI\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 911,
		"path": "../public/assets/publicProfiles-BrEE0Mg2.js"
	},
	"/assets/pin-ChZxHqoz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15a-K+pksOnjHulAoflbaAcJPS+ALLE\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 346,
		"path": "../public/assets/pin-ChZxHqoz.js"
	},
	"/assets/react-dom-BGozS2fx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-0MZBIJvXSnBp/LkUj2JpcVxRM3E\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 3546,
		"path": "../public/assets/react-dom-BGozS2fx.js"
	},
	"/assets/plus-5gOMkH_D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-rv7T0sMBSQq/gfIetey9eN1MTdM\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 153,
		"path": "../public/assets/plus-5gOMkH_D.js"
	},
	"/assets/route-CGjv_PIP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-D+IPjAPXXkUO+ssRs3SZ/yG7gJA\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 141,
		"path": "../public/assets/route-CGjv_PIP.js"
	},
	"/assets/redirect-C-eRQtnH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22d-XWldT6wFIL00QHpfP609loBAcNQ\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 557,
		"path": "../public/assets/redirect-C-eRQtnH.js"
	},
	"/assets/routes-DxjKbNWr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30d8-pQ3VhePnvpefIg4bHYmWqBa6Z0U\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 12504,
		"path": "../public/assets/routes-DxjKbNWr.js"
	},
	"/assets/settings-2-CGrW06gX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fc-5dpPb4vCLa5CB1BWDqchufqbaSc\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 252,
		"path": "../public/assets/settings-2-CGrW06gX.js"
	},
	"/assets/search-s3C4vtuy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-vzqZYZuCpfLOrnSzJfSsqj3BQ54\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 174,
		"path": "../public/assets/search-s3C4vtuy.js"
	},
	"/assets/send-B0h4e530.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-z0WY3nRdYT9mtn0obJ/H7ujtkgY\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 290,
		"path": "../public/assets/send-B0h4e530.js"
	},
	"/assets/save-BLFTnj-q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147-EZZFE4xgJX6qqacz/F6Zn97FYcE\"",
		"mtime": "2026-07-31T22:16:26.211Z",
		"size": 327,
		"path": "../public/assets/save-BLFTnj-q.js"
	},
	"/assets/shield-DCGtAdDK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-R63EpNwa8dU9YGpcdUgP1sfsqCk\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 272,
		"path": "../public/assets/shield-DCGtAdDK.js"
	},
	"/assets/sparkles-Bbdae7iX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-+X9dIgO9/Y1VN44zW7vddoXxbOA\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 494,
		"path": "../public/assets/sparkles-Bbdae7iX.js"
	},
	"/assets/upload-CPKsUoYX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-6NI0F7rdx6mF0/m/rJjeondjrU4\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 230,
		"path": "../public/assets/upload-CPKsUoYX.js"
	},
	"/assets/useAvatarUrl-B9gnHust.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"440-CpbaydF38IhfZBCHas/2VsO9ha8\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 1088,
		"path": "../public/assets/useAvatarUrl-B9gnHust.js"
	},
	"/assets/settings-DYm6gAc3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7-s6YVrbvAat5Q4vQfBIoNR7jqbWk\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 487,
		"path": "../public/assets/settings-DYm6gAc3.js"
	},
	"/assets/useRoles-BWj53eMr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d2-sr1NNJ+3naB88mDLACMjl4WBdtM\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 466,
		"path": "../public/assets/useRoles-BWj53eMr.js"
	},
	"/assets/useMutation-Bz5JZYmC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ca-Ruk4sQYC/eZKV96X7bbdHjrNeL8\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 2250,
		"path": "../public/assets/useMutation-Bz5JZYmC.js"
	},
	"/assets/useQuery-DKElqIXc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"224e-n3wkPhELzvxfGgcxOByXsY/VK2M\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 8782,
		"path": "../public/assets/useQuery-DKElqIXc.js"
	},
	"/assets/styles-4cC5VA1A.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19c85-H+QNtGh1x5PFUTxsPsCFfGQfGbk\"",
		"mtime": "2026-07-31T22:16:26.213Z",
		"size": 105605,
		"path": "../public/assets/styles-4cC5VA1A.css"
	},
	"/assets/shield-check-BkKPZRT-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-+gFGoh5DhxmerkOt4jJ/sXexNlc\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 320,
		"path": "../public/assets/shield-check-BkKPZRT-.js"
	},
	"/assets/trash-2-CU1Ye6Hg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-PAfCwJH2E3ITpWv4OUqrJHbxr78\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 328,
		"path": "../public/assets/trash-2-CU1Ye6Hg.js"
	},
	"/assets/useRouter-C3rM-XLx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-sNDYlp+/4tsWduj6R7qy8rJ7CXc\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 151,
		"path": "../public/assets/useRouter-C3rM-XLx.js"
	},
	"/assets/useRouterState-DqdRkdCz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb-6ZOQawlxiSaxzjekeVGW9L0M3KQ\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 235,
		"path": "../public/assets/useRouterState-DqdRkdCz.js"
	},
	"/assets/useStore-CZcVHC41.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"481e-cT/x5r4gvIJnafbs5LLCcKIsfT0\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 18462,
		"path": "../public/assets/useStore-CZcVHC41.js"
	},
	"/assets/user-plus-BkSOgZcS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-i7Yv995eTSVaTh4ncP59sUP3WcY\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 310,
		"path": "../public/assets/user-plus-BkSOgZcS.js"
	},
	"/assets/x-DtNyKRYb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-ibOAIWrC9aklvuRMyNo/7R0IY2A\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 154,
		"path": "../public/assets/x-DtNyKRYb.js"
	},
	"/assets/users-4ZYb9_cZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-Mi2/1OMoydPO7F9VZqHymKhMBJg\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 306,
		"path": "../public/assets/users-4ZYb9_cZ.js"
	},
	"/assets/useSiteSettings-k-dGa_mH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a0-Jd847tvjHW3cz4e/Nl9RQu3A7aM\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 416,
		"path": "../public/assets/useSiteSettings-k-dGa_mH.js"
	},
	"/assets/utils-Dh2UFsYh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25e-P/sQ1YqFPUnKZj7LHj2qlHmAVKU\"",
		"mtime": "2026-07-31T22:16:26.212Z",
		"size": 606,
		"path": "../public/assets/utils-Dh2UFsYh.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_j21Qvj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
